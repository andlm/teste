package com.nexxera.pds.webservice.server;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.CRL;
import java.security.cert.CRLException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERPrintableString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.asn1.x509.PolicyInformation;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import com.nexxera.pds.entity.Contrato;
import com.nexxera.pds.entity.Contratoarquivo;
import com.nexxera.pds.entity.Contratoassinatura;
import com.nexxera.pds.entity.Contratoassinaturaservico;
import com.nexxera.pds.entity.enums.StatusTraking;
import com.nexxera.pds.entity.enums.TipoContrato;
import com.nexxera.pds.service.ContratoArquivoService;
import com.nexxera.pds.service.ContratoAssinaturaService;
import com.nexxera.pds.service.ContratoAssinaturaServicoService;
import com.nexxera.pds.service.ContratoService;
import com.nexxera.pds.utility.ResourceProperties;
import com.nexxera.pds.utility.SeamUtils;
import com.nexxera.pds.webservice.exception.PDSServerException;

public class ICPBrasilA1Server {
	
	public boolean validarCertificadoICPBrasilA1 (String certificado, String[] cadeiaDeCertificados) throws PDSServerException {
		System.setProperty("http.proxyHost", "192.168.100.1");
		System.setProperty("http.proxyPort", "3128");
		
		X509Certificate certificate = null;
		X509Certificate[] certificateChain = null;
		
		try {
			certificate = stringBase64ToX509Certificate(certificado);
			certificateChain = stringBase64ToX509CertificateChain(cadeiaDeCertificados);
			
			if (isICPBrasilA1Certificate(certificate)) {
				if (isCertificateKeyUsageEnabledForDigitalSignature(certificate)) {
					Calendar dataAtual = Calendar.getInstance();
					if (isNotCertificateOnExpirationDate(certificate, dataAtual)) {
						if (isNotCertificateInTheListOfRevokedCertificates(certificate, certificateChain)) {
							return true;
						}
					}
				}
			}
			
		} catch (Exception e) {
			throw new PDSServerException("Problema ao validar se o certificado � um ICP Brasil A1 V�lido", e.getCause().toString());
		}
		return false;
	}
	
	public boolean validarCPFDoCertificadoComNumeroDeIdentificacaoDoUsuarioEmpresa(String x509CertificateStringBase64, Long cdContratoAssinaturaServico) throws PDSServerException {
		X509Certificate certificate = null;
		
		try {
			certificate = stringBase64ToX509Certificate(x509CertificateStringBase64);
		} catch (Exception e) {
			throw new PDSServerException("Problema ao validar CPF do Certificado Selecionado", e.getCause().toString());
		}
		
		org.jboss.seam.contexts.Lifecycle.beginCall();
			Contratoassinaturaservico contratoassinaturaservico = SeamUtils.getComponent(ContratoAssinaturaServicoService.class).consultaContratoAssinaturaServicoPorCodigo(cdContratoAssinaturaServico);
		org.jboss.seam.contexts.Lifecycle.endCall();
		
		if(contratoassinaturaservico == null || contratoassinaturaservico.getCdContratoassinatura() == null){
			throw new PDSServerException("N�mero de ContratoAssinaturaServico Desconhecido!", "N�mero de ContratoAssinaturaServico: "+cdContratoAssinaturaServico+ " ou ContratoAssinatura Desconhecido!");
		}
		
		if (!contratoassinaturaservico.getCdContratoassinatura().getCdUsuario().getNuIdentificacao().equals(getCPF(certificate))) {
			throw new PDSServerException("CPF incompat�vel", "O CPF encontrado no certificado n�o � igual ao CPF da pessoa que deveria estar assinando o contrato");
		}
		
		return true;
	}
	
	public String enviarPdfDoContrato(Long cdContratoAssinaturaServico) throws PDSServerException {
		String pdfAssinarEmStringBase64 = null;
		byte[] pdfAssinar = null;
		try {
			org.jboss.seam.contexts.Lifecycle.beginCall();
		
				Contratoassinaturaservico contratoassinaturaservico = SeamUtils.getComponent(ContratoAssinaturaServicoService.class).consultaContratoAssinaturaServicoPorCodigo(cdContratoAssinaturaServico);
				
				Contratoarquivo contratoarquivo = SeamUtils.getComponent(ContratoArquivoService.class).consultaContratoArquivoPorContrato(contratoassinaturaservico.getCdContratoassinatura().getCdContrato());
				
				pdfAssinar = contratoarquivo.getBnArquivoSign();
		
			org.jboss.seam.contexts.Lifecycle.endCall();
		
		} catch (Exception e) {
			throw new PDSServerException("Problema ao enviar o Pdf do Contrato", e.getCause().toString());
		}
		
		if(pdfAssinar == null){
			throw new PDSServerException("Arquivo do Contrato n�o existe", "O arquivo (pdf) do contrato que se deseja assinar n�o existe na base de dados!");
		}
		
		try {
			pdfAssinarEmStringBase64 = ResourceProperties.criptografiaBase64(pdfAssinar);
		} catch (IOException e) {
			throw new PDSServerException("Problema ao enviar o Pdf do Contrato", e.getCause().toString());
		}
		
		return pdfAssinarEmStringBase64;
	}

	public boolean salvarPdfDoContratoAssinado(Long cdContratoAssinaturaServico, String pdfAssinadoEmBase64) throws PDSServerException {
		boolean pdfSalvoComSucesso = false;
		
		try {
			
			org.jboss.seam.contexts.Lifecycle.beginCall();
	
				Contratoassinaturaservico contratoassinaturaservico = SeamUtils.getComponent(ContratoAssinaturaServicoService.class).consultaContratoAssinaturaServicoPorCodigo(cdContratoAssinaturaServico);
				
				if(contratoassinaturaservico.getCdContratoassinatura().getFgStatustracking() == StatusTraking.ASSINADO){
					throw new Exception("Contrato j� assinado pelo usu�rio!");
				}
				
				Contratoarquivo contratoarquivo = SeamUtils.getComponent(ContratoArquivoService.class).consultaContratoArquivoPorContrato(contratoassinaturaservico.getCdContratoassinatura().getCdContrato());
			
				byte[] pdfAssinado = ResourceProperties.decriptografiaBase64ToByteArray(pdfAssinadoEmBase64);
				contratoarquivo.setBnArquivoSign(pdfAssinado);
			
				SeamUtils.getComponent(ContratoArquivoService.class).editar(contratoarquivo);
				
				contratoassinaturaservico.setFgServicoexecutado(true);
				SeamUtils.getComponent(ContratoAssinaturaServicoService.class).editar(contratoassinaturaservico);
				
				Contratoassinatura contratoassinatura = contratoassinaturaservico.getCdContratoassinatura();
				contratoassinatura.setDtExecucaoservico(new Date());
				contratoassinatura.setFgStatustracking(StatusTraking.ASSINADO);
				SeamUtils.getComponent(ContratoAssinaturaService.class).editar(contratoassinatura);
	
			org.jboss.seam.contexts.Lifecycle.endCall();
			
			pdfSalvoComSucesso = true;
			
		} catch (Exception e) {
			if(e.getCause() == null){
				throw new PDSServerException("Problema ao salvar o Pdf do Contrato Assinado", e.getMessage());	
			}else{
				throw new PDSServerException("Problema ao salvar o Pdf do Contrato Assinado", e.getCause().toString());
			}
		}
	
		return pdfSalvoComSucesso;
	}
	
	public void ativarProximoContratoAssinaturaDoWorkflowDoTrackingAAssinar(Long cdContratoAssinaturaServico) throws PDSServerException {
		try {
			
			org.jboss.seam.contexts.Lifecycle.beginCall();
				Contratoassinaturaservico contratoassinaturaservico = SeamUtils.getComponent(ContratoAssinaturaServicoService.class).consultaContratoAssinaturaServicoPorCodigo(cdContratoAssinaturaServico);
				List<Contratoassinatura> contratoassinaturas = SeamUtils.getComponent(ContratoAssinaturaService.class).consultaContratoassinaturasPorContrato(contratoassinaturaservico.getCdContratoassinatura().getCdContrato());
			org.jboss.seam.contexts.Lifecycle.endCall();
			
			int indiceDoAtualContratoAssinaturaDoTracking = 0;
			for (int i = 0; i < contratoassinaturas.size(); i++) {
				if (contratoassinaturas.get(i).getCdUsuario().equals(contratoassinaturaservico.getCdContratoassinatura().getCdUsuario())) {
					indiceDoAtualContratoAssinaturaDoTracking = i;
					break;
				}
			}
			
			int indiceDoUltimoContratoAssinaturaDoTracking = contratoassinaturas.size() - 1;
			if (indiceDoAtualContratoAssinaturaDoTracking < indiceDoUltimoContratoAssinaturaDoTracking) {
				int indiceDoProximoContratoAssinaturaDoTracking = indiceDoAtualContratoAssinaturaDoTracking + 1;
				atualizaStatusProximoContratoAssinaturaPendenteNoTracking(contratoassinaturas.get(indiceDoProximoContratoAssinaturaDoTracking));
			} else {
				encerraContratoDoTracking(contratoassinaturas.get(indiceDoAtualContratoAssinaturaDoTracking).getCdContrato());
			}
			
		} catch (Exception e) {
			throw new PDSServerException("Problema ao ativar proxima assinatura do WorkFlow do Tracking", e.getCause().toString());
		}
		
	}
	
	private void atualizaStatusProximoContratoAssinaturaPendenteNoTracking(Contratoassinatura proximoContratoassinatura) {
		proximoContratoassinatura.setFgStatustracking(StatusTraking.PENDENTE);
		
		org.jboss.seam.contexts.Lifecycle.beginCall();
			SeamUtils.getComponent(ContratoAssinaturaService.class).editar(proximoContratoassinatura);
		org.jboss.seam.contexts.Lifecycle.endCall();
	}

	private void encerraContratoDoTracking(Contrato cdContrato) {
		cdContrato.setFgStatus(TipoContrato.Assinado);
		
		org.jboss.seam.contexts.Lifecycle.beginCall();
			SeamUtils.getComponent(ContratoService.class).editar(cdContrato);
		org.jboss.seam.contexts.Lifecycle.endCall();
	}

	public X509Certificate stringBase64ToX509Certificate(String x509StringBase64) throws Exception {
		CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
		InputStream in = new ByteArrayInputStream(ResourceProperties.decriptografiaBase64ToByteArray(x509StringBase64));
		X509Certificate x509CertificateDepoisCriptografiaBase64 = (X509Certificate) certFactory.generateCertificate(in);
		return x509CertificateDepoisCriptografiaBase64;
	}
	
	public X509Certificate[] stringBase64ToX509CertificateChain(String[] certificateChain) throws Exception {
		List<X509Certificate> certificatesAliasList = new ArrayList<X509Certificate>();
		
		for (int i = 0; i < certificateChain.length; i++) {
			certificatesAliasList.add(stringBase64ToX509Certificate(certificateChain[i]));
		}
		
		return certificatesAliasList.toArray(new X509Certificate[certificatesAliasList.size()]);
	}
	
	public PrivateKey stringBase64ToPrivateKey(String privateKeyStringBase64) throws Exception {
		KeyFactory rSAKeyFactory = KeyFactory.getInstance("RSA");
		PrivateKey privateKey = rSAKeyFactory.generatePrivate(new PKCS8EncodedKeySpec(ResourceProperties.decriptografiaBase64ToByteArray(privateKeyStringBase64)));
		return privateKey;
	}
	
	public PrivateKey byteArrayDEREncodedToPrivateKey(byte[] privateKeyDEREncoded) throws Exception {
		KeyFactory rSAKeyFactory = KeyFactory.getInstance("RSA");
		PrivateKey privateKey = rSAKeyFactory.generatePrivate(new PKCS8EncodedKeySpec(privateKeyDEREncoded));
		return privateKey;
	}
	
	/**
	 * OID especificados pela ICP Brasil. Mais informa��e em:
	 * http://www.iti.gov.br/twiki/pub/Certificacao/AdeIcp/ADE_ICP-04.01.pdf
	 **/
	
	public static final DERObjectIdentifier	OID_PF_DADOS_TITULAR		= new DERObjectIdentifier("2.16.76.1.3.1");
	public static final DERObjectIdentifier	OID_PJ_RESPONSAVEL			= new DERObjectIdentifier("2.16.76.1.3.2");
	public static final DERObjectIdentifier	OID_PJ_CNPJ					= new DERObjectIdentifier("2.16.76.1.3.3");
	public static final DERObjectIdentifier	OID_PJ_DADOS_RESPONSAVEL	= new DERObjectIdentifier("2.16.76.1.3.4");
	public static final DERObjectIdentifier	OID_PF_ELEITORAL			= new DERObjectIdentifier("2.16.76.1.3.5");
	public static final DERObjectIdentifier	OID_PF_INSS					= new DERObjectIdentifier("2.16.76.1.3.6");
	public static final DERObjectIdentifier	OID_PJ_INSS					= new DERObjectIdentifier("2.16.76.1.3.7");
	public static final DERObjectIdentifier	OID_PJ_NOME_EMPRESARIAL		= new DERObjectIdentifier("2.16.76.1.3.8");
	
	@SuppressWarnings("rawtypes")
	public String getCPF(X509Certificate certificate) {
		String cpf = null;
		
		try {
			
			Collection col = X509ExtensionUtil.getSubjectAlternativeNames(certificate);
			
			for (Object obj : col) {
				
				if (obj instanceof ArrayList) {
					
					ArrayList lst = (ArrayList) obj;
					
					Object value = lst.get(1);
					
					if (value instanceof DERSequence) {
						
						/**
						 * DER Sequence ObjectIdentifier Tagged DER Octet String
						 */
						
						DERSequence seq = (DERSequence) value;
						
						DERObjectIdentifier oid = (DERObjectIdentifier) seq.getObjectAt(0);
						DERTaggedObject tagged = (DERTaggedObject) seq.getObjectAt(1);
						String info = null;
						
						DERObject derObj = tagged.getObject();
						
						if (derObj instanceof DEROctetString) {
							DEROctetString octet = (DEROctetString) derObj;
							info = new String(octet.getOctets());
						} else if (derObj instanceof DERPrintableString) {
							DERPrintableString octet = (DERPrintableString) derObj;
							info = new String(octet.getOctets());
						} else if (derObj instanceof DERUTF8String) {
							DERUTF8String str = (DERUTF8String) derObj;
							info = str.getString();
						}
						
						if (info != null && !info.isEmpty()) {
							if (oid.equals(OID_PF_DADOS_TITULAR) || oid.equals(OID_PJ_DADOS_RESPONSAVEL)) {
								String nascimento = info.substring(0, 8);
								System.out.println("Data Nascimento: " + new SimpleDateFormat("ddMMyyyy").parse(nascimento));
								cpf = info.substring(8, 19);
								System.out.println("CPF: " + cpf);
								String nis = info.substring(19, 30);
								System.out.println("NIS: " + nis);
								String rg = info.substring(30, 45);
								System.out.println("RG: " + rg);
								if (!rg.equals("000000000000000")) {
									String ufExp = info.substring(45, 50);
									System.out.println("Org�o Expedidor: " + ufExp);
								}
							} else if (oid.equals(OID_PF_INSS)) {
								String inss = info.substring(0, 12);
								System.out.println("INSS: " + inss);
							} else if (oid.equals(OID_PF_ELEITORAL)) {
								String titulo = info.substring(0, 12);
								System.out.println("Titulo de Eleitor: " + titulo);
								String zona = info.substring(12, 15);
								System.out.println("Zona Eleitoral: " + zona);
								String secao = info.substring(15, 19);
								System.out.println("Se��o: " + secao);
								if (!titulo.equals("000000000000")) {
									String municipio = info.substring(19, info.length());
									System.out.println("Municipio: " + municipio);
								}
							} else if (oid.equals(OID_PJ_RESPONSAVEL)) {
								System.out.println("Responsav�l: " + info);
							} else if (oid.equals(OID_PJ_CNPJ)) {
								System.out.println("CNPJ: " + info);
							} else if (oid.equals(OID_PJ_INSS)) {
								System.out.println("INSS: " + info);
							} else if (oid.equals(OID_PJ_NOME_EMPRESARIAL)) {
								System.out.println("NOME: " + info);
							}
						}
					} else {
						System.out.println("Valor desconhecido: " + value);
					}
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cpf;
	}
	
	public boolean isICPBrasilA1Certificate(X509Certificate cert) throws Exception {
		boolean isICPBrasilA1Certificate = false;
		
		/*
		 * OID value: 2.5.29.32
		 * 
		 * OID description: id-ce-certificatePolicies
		 * 
		 * This extension lists certificate policies, recognized by the issuing
		 * CA, that apply to the certificate, together with optional qualifier
		 * information pertaining to these certificate policies. Typically,
		 * different certificate policies will relate to different applications
		 * which may use the certified key.
		 */
		
		byte[] extensaoOID_2_5_29_32 = cert.getExtensionValue("2.5.29.32");
		if (extensaoOID_2_5_29_32 == null) {
			throw new Exception("Impossivel recuperar extens�o de OID 2.5.29.32/id-ce-certificatePolicies! O certificado selecionado n�o � um ICPBrasil A1!");
		}
		
		ASN1InputStream oInput = new ASN1InputStream(new ByteArrayInputStream(extensaoOID_2_5_29_32));
		
		if (oInput == null) {
			throw new Exception("Impossivel recuperar extens�o de OID 2.5.29.32/id-ce-certificatePolicies! O certificado selecionado n�o � um ICPBrasil A1!");
		} else {
			ASN1Sequence certPolicies = null;
			ASN1OctetString oOct = ASN1OctetString.getInstance(oInput.readObject());
			oInput = new ASN1InputStream(new ByteArrayInputStream(oOct.getOctets()));
			certPolicies = ASN1Sequence.getInstance(oInput.readObject());
			
			for (int i = 0; i < certPolicies.size(); i++) {
				PolicyInformation policy = new PolicyInformation((ASN1Sequence) certPolicies.getObjectAt(i));
				String directive = policy.getPolicyIdentifier().getId();
				if (cert.getBasicConstraints() != -1 || !directive.startsWith("2.16.76.1.2.1")) {
					continue;
				}
				isICPBrasilA1Certificate = true;
				break;
			}
			
			return isICPBrasilA1Certificate;
		}
	}
	
	public boolean isCertificateKeyUsageEnabledForDigitalSignature(X509Certificate certValidar) throws Exception {
		if (certValidar.getKeyUsage() != null) {
			if (!(certValidar.getKeyUsage()[0] && certValidar.getKeyUsage()[1])) {
				throw new Exception("O certificado '" + certValidar + "' nao tem habilita��o para assinatura digital.");
			}
		} else {
			throw new Exception("O certificado '" + certValidar + "' nao cont�m a extens�o KeyUsage, que informa para que ele pode ser usado.");
		}
		
		return true;
	}
	
	public boolean isNotCertificateOnExpirationDate(X509Certificate certValidar, Calendar dataAtual) throws Exception {
		Calendar notAfterDate = Calendar.getInstance();
		notAfterDate.setTime(certValidar.getNotAfter());
		if (dataAtual.after(notAfterDate)) {
			throw new Exception("O certificado '" + certValidar + "' nao � mais v�lido. O certificado venceu em " + notAfterDate.get(5) + "/" + (notAfterDate.get(2) + 1) + "/" + notAfterDate.get(1) + ".");
		}
		
		Calendar notBeforeDate = Calendar.getInstance();
		notBeforeDate.setTime(certValidar.getNotBefore());
		if (dataAtual.before(notBeforeDate)) {
			throw new Exception("O certificado '" + certValidar + "' ainda n�o � v�lido. O certificado ser� v�lido a partir de " + notBeforeDate.get(5) + "/" + (notBeforeDate.get(2) + 1) + "/" + notBeforeDate.get(1) + ".");
		}
		
		return true;
	}
	
	public boolean isNotCertificateInTheListOfRevokedCertificates(X509Certificate certValidar, X509Certificate[] certChainValidar) throws Exception {
		CRL[] certificadosRevogados = recuperarListaCertificadosRevogados(certChainValidar);
		for (CRL crl : certificadosRevogados) {
			if (crl.isRevoked(certValidar)) {
				throw new Exception("O certificado '" + certValidar + "' est� na lista de certificados revogados pela AC! ");
			}
		}
		return true;
	}
	
	public CRL[] recuperarListaCertificadosRevogados(X509Certificate[] cadeia) throws Exception {
		List<CRL> listaCRL = new ArrayList<CRL>();
		if ((cadeia == null) || (cadeia.length < 1)) {
			return null;
		}
		for (X509Certificate certCadeia : cadeia) {
			byte[] bytes = certCadeia.getExtensionValue(X509Extensions.CRLDistributionPoints.getId());
			
			if ((bytes == null) || (bytes.length < 1)) {
				throw new Exception("Nao foi poss�vel recuperar o campo contendo a lista de revoga��o de um do certificados informados: " + certCadeia.getSubjectX500Principal().getName());
			}
			
			DERObject derObject = null;
			try {
				ASN1InputStream asn1is = new ASN1InputStream(new ByteArrayInputStream(bytes));
				ASN1OctetString asn1os = ASN1OctetString.getInstance(asn1is.readObject());
				asn1is = new ASN1InputStream(new ByteArrayInputStream(asn1os.getOctets()));
				derObject = asn1is.readObject();
			} catch (IOException e) {
				throw new Exception("Nao foi poss�vel recuperar o campo contendo a lista de revoga��o de um do certificados informados: " + certCadeia.getSubjectX500Principal().getName());
			}
			
			List<URL> urls = null;
			try {
				urls = recuperarListaUrl(derObject);
			} catch (MalformedURLException e) {
				throw new Exception("O endere�o da lista de revoga��o do certificado '" + certCadeia.getSubjectX500Principal().getName() + "' nao � v�lido.");
			}
			
			if ((urls != null) && (!urls.isEmpty())) {
				StringBuffer erroRecuperarCRL = null;
				CRL crlEncontrado = null;
				for (URL enderecoUrl : urls) {
					byte[] bytesCRL = null;
					try {
						bytesCRL = recuperarArquivo(enderecoUrl);
					} catch (Throwable t) {
						if (erroRecuperarCRL == null) {
							erroRecuperarCRL = new StringBuffer();
						}
						erroRecuperarCRL.append(t.getLocalizedMessage());
					}
					
					if (bytesCRL != null) {
						try {
							Security.addProvider(new BouncyCastleProvider());
							CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
							crlEncontrado = certFactory.generateCRL(new ByteArrayInputStream(bytesCRL));
							listaCRL.add(crlEncontrado);
						} catch (CRLException e) {
							if (erroRecuperarCRL == null) {
								erroRecuperarCRL = new StringBuffer();
							}
							erroRecuperarCRL.append("Ocorreu um erro ao instanciar a lista de revoga��o:\n" + e.getLocalizedMessage());
						} catch (CertificateException e) {
							e.printStackTrace();
							throw new Exception("Ocorreu um erro ao instanciar a cadeia de certifi��o. " + e.getLocalizedMessage());
						}
						
					}
					
				}
				
				if (crlEncontrado == null) {
					String errMsg = "";
					if (erroRecuperarCRL != null) {
						errMsg = erroRecuperarCRL.toString();
					}
					throw new Exception("Nao foi poss�vel recuperar nenhuma lista de revoga��o para o certificado: '" + certCadeia.getSubjectX500Principal().getName() + "'.\n" + errMsg);
				}
			} else {
				throw new Exception("Nao foi poss�vel recuperar nenhum endere�o de lista de revoga��o para o certificado: " + certCadeia.getSubjectX500Principal().getName());
			}
			
		}
		
		return (CRL[]) listaCRL.toArray(new CRL[0]);
	}
	
	private byte[] recuperarArquivo(URL url) throws IOException {
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setReadTimeout(new Integer("30000").intValue());
		connection.setDoInput(true);
		connection.connect();
		
		int responseCode = connection.getResponseCode();
		InputStream connStream = connection.getInputStream();
		
		if (responseCode != 200) {
			throw new IOException("Erro HTTP " + responseCode + ". nao foi poss�vel recuperar lista de revoga��o no endere�o: " + url.toExternalForm());
		}
		
		ByteArrayOutputStream memoryStream = new ByteArrayOutputStream();
		
		byte[] lcrBuffer = new byte[10240];
		int lido;
		while ((lido = connStream.read(lcrBuffer)) > 0) {
			memoryStream.write(lcrBuffer, 0, lido);
		}
		
		connStream.close();
		connection.disconnect();
		
		return memoryStream.toByteArray();
	}
	
	private List<URL> recuperarListaUrl(DERObject derObject) throws MalformedURLException {
		if ((derObject instanceof DERSequence)) {
			List retorno = new ArrayList();
			DERSequence seq = (DERSequence) derObject;
			Enumeration enumeracao = seq.getObjects();
			
			while (enumeracao.hasMoreElements()) {
				DERObject nestedObj = (DERObject) enumeracao.nextElement();
				List appo = recuperarListaUrl(nestedObj);
				if (appo != null)
					retorno.addAll(appo);
			}
			return retorno;
		}
		
		if ((derObject instanceof DERTaggedObject)) {
			DERTaggedObject derTag = (DERTaggedObject) derObject;
			if ((derTag.isExplicit()) && (!derTag.isEmpty())) {
				DERObject nestedObj = derTag.getObject();
				List retorno = recuperarListaUrl(nestedObj);
				return retorno;
			}
			if ((derTag.getObject() instanceof DEROctetString)) {
				DEROctetString derOct = (DEROctetString) derTag.getObject();
				URL val = new URL(new String(derOct.getOctets()));
				List retorno = new ArrayList();
				retorno.add(val);
				
				return retorno;
			}
			DERObject nestedObj = derTag.getObject();
			List retorno = recuperarListaUrl(nestedObj);
			
			return retorno;
		}
		
		return null;
	}

}
