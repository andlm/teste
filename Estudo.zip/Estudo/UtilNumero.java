/*  1:   */ package br.com.virtuoso.prosaude.utils;
/*  2:   */ 
/*  3:   */ public class UtilNumero
/*  4:   */ {
/*  5: 9 */   public static final Double ZERO_DOUBLE = Double.valueOf(0.0D);
/*  6:   */   
/*  7:   */   public static Double toDoubleZeroSeNull(Double valor)
/*  8:   */   {
/*  9:12 */     return valor == null ? new Double("0.00") : valor;
/* 10:   */   }
/* 11:   */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilNumero
 * JD-Core Version:    0.7.0.1
 */