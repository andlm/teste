/*  1:   */ package br.com.virtuoso.prosaude.utils;
/*  2:   */ 
/*  3:   */ public class UtilReflexao
/*  4:   */ {
/*  5:   */   public static String getNomeClasse(Class classe)
/*  6:   */   {
/*  7:10 */     String className = classe.getName();
/*  8:11 */     return className.substring(className.lastIndexOf(".") + 1);
/*  9:   */   }
/* 10:   */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilReflexao
 * JD-Core Version:    0.7.0.1
 */