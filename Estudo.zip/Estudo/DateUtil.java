package com.nexxera.pds.utility;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Classe com utilitarios para datas.
 * 
 * @author isaac.souza
 */
public class DateUtil
{
   /**
    * Enum utilizado pelo metodo que retorna diferenca entre datas
    * 
    * @author isaac.souza
    */
   public enum Difference
   {
      MILLISECONDS, SECONDS, MINUTES, HOURS, DAYS;
   };

   /**
    * Retorna a diferenca entre duas datas. Sendo a diferenca entre a data menor e a data maior. O
    * tipo de diferenca que sera calculado e o tipo informado no parametro diff. Pode retornar
    * diferencas entre duas data de Dias, Horas, Minutos, Segundos e Milisegundos.
    * 
    * @param date1 data1 a ser utilizada na comparacao
    * @param date2 data2 a ser utilizada na comparacao
    * @param diff Tipo de diferenca que deve ser calculada.
    * @return
    */
   public static long getDifference(Calendar date1, Calendar date2, Difference diff)
   {
      if (date1 == null)
      {
         throw new IllegalArgumentException("date1 is null");
      }
      if (date2 == null)
      {
         throw new IllegalArgumentException("date2 is null");
      }
      
      long date1Milisegundos = date1.getTimeInMillis() + date1.get(Calendar.DST_OFFSET);
      long date2Milisegundos = date2.getTimeInMillis() + date2.get(Calendar.DST_OFFSET);

      long diferencaMilisegundos = date1.after(date2) ? date1Milisegundos - date2Milisegundos : date2Milisegundos - date1Milisegundos;

      switch (diff)
      {
         case DAYS:
            diferencaMilisegundos /= 24;
         case HOURS:
            diferencaMilisegundos /= 60;
         case MINUTES:
            diferencaMilisegundos /= 60;
         case SECONDS:
            diferencaMilisegundos /= 1000;
      }
      return diferencaMilisegundos;
   }

   /**
    * Retorna a diferenca entre duas datas. Sendo a diferenca entre a data menor e a data maior. O
    * tipo de diferenca que sera calculado e o tipo informado no parametro diff. Pode retornar
    * diferencas entre duas data de Dias, Horas, Minutos, Segundos e Milisegundos.
    * 
    * @param date1 data1 a ser utilizada na comparacao
    * @param date2 data2 a ser utilizada na comparacao
    * @param diff Tipo de diferenca que deve ser calculada.
    * @return
    */
   public static long getDifference(Date date1, Date date2, Difference diff)
   {
      return getDifference(getToCalendar(date1), getToCalendar(date2), diff);
   }

   /**
    * Converte um objeto do tipo java.util.Date para um java.util.Calendar
    * 
    * @param date Date a ser convertido
    * @return Calendar com mesmos dados do date enviado.
    */
   public static Calendar getToCalendar(Date date)
   {
      Calendar calendar = null;

      if (date == null)
      {
         throw new IllegalArgumentException("date is null");
      }

      calendar = Calendar.getInstance();
      calendar.setTime(date);
      return calendar;
   }

   /**
    * Converte um objeto do tipo java.util.Date para um javax.xml.datatype.XMLGregorianCalendar
    * 
    * @param date Date a ser convertido
    * @return XMLGregorianCalendar com mesmos dados do date enviado.
    */
   public static XMLGregorianCalendar getToXMLGregorianCalendar(Date date) throws DatatypeConfigurationException
   {
      XMLGregorianCalendar xmlGregorianCalendar = null;
      if (date == null)
      {
         throw new IllegalArgumentException("date is null");
      }
      GregorianCalendar gregorianCalendar = new GregorianCalendar();
      gregorianCalendar.setTime(date);

      xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);

      return xmlGregorianCalendar;
   }

   /**
    * Converte um objeto do tipo java.util.Calendar para um javax.xml.datatype.XMLGregorianCalendar
    * 
    * @param date Calendar a ser convertido
    * @return XMLGregorianCalendar com mesmos dados do date enviado.
    */
   public static XMLGregorianCalendar getToXMLGregorianCalendar(Calendar date) throws DatatypeConfigurationException
   {
      XMLGregorianCalendar xmlGregorianCalendar = null;
      if (date == null)
      {
         throw new IllegalArgumentException("date is null");
      }
      GregorianCalendar gregorianCalendar = null;
      if (date instanceof GregorianCalendar)
      {
         gregorianCalendar = (GregorianCalendar) date;
      }
      else
      {
         gregorianCalendar = new GregorianCalendar();
         gregorianCalendar.setTimeInMillis(date.getTimeInMillis());
      }

      xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);

      return xmlGregorianCalendar;
   }

   /**
    * Aplica na data um conjutos de valores referentes a "hora" da data.
    * 
    * @param date Calendar com a data a ter a hora aplicada.
    * @param hourOfDay Hora a ser aplciada na data
    * @param minute Minuto a ser aplciada na data
    * @param second Segundo a ser aplciada na data
    * @param millisecond Milisegundo a ser aplciada na data
    */
   public static void applyTime(Calendar date, int hourOfDay, int minute, int second, int millisecond)
   {
      if (date == null)
      {
         throw new IllegalArgumentException("date is null");
      }
      date.set(Calendar.HOUR_OF_DAY, hourOfDay);
      date.set(Calendar.MINUTE, minute);
      date.set(Calendar.SECOND, second);
      date.set(Calendar.MILLISECOND, millisecond);
   }

   /**
    * Aplica na data um conjutos de valores referentes a "hora" da data.
    * 
    * @param date data a ter a hora aplicada.
    * @param hourOfDay Hora a ser aplciada na data
    * @param minute Minuto a ser aplciada na data
    * @param second Segundo a ser aplciada na data
    * @param millisecond Milisegundo a ser aplciada na data
    * @return Retorna data com hora aplicada, pois a data original � "desconsiderada" na convers�o
    *         para Calendar.
    */
   public static Date applyTime(Date date, int hourOfDay, int minute, int second, int millisecond)
   {
      Calendar dateCalendar = getToCalendar(date);
      applyTime(dateCalendar, hourOfDay, minute, second, millisecond);
      return dateCalendar.getTime();
   }

   /**
    * Zera a hora da data, deixando como hora, o horario 00:00:00.000
    * 
    * @param date Calendar com a data a ter a hora zerada.
    */
   public static void clearTime(Calendar date)
   {
      applyTime(date, 0, 0, 0, 0);
   }

   /**
    * Zera a hora da data, deixando como hora, o horario 00:00:00.000
    * 
    * @param date data a ter a hora zerada.
    * @return Retorna data com hora zerada, pois a data original � "desconsiderada" na convers�o
    *         para Calendar.
    */
   public static Date clearTime(Date date)
   {
      Calendar dateCalendar = getToCalendar(date);
      clearTime(dateCalendar);
      return dateCalendar.getTime();
   }

   /**
    * Aplica a hora atual na data, deixando como hora, o horario corrente hh:mm:ss.mmmm
    * 
    * @param date Calendar com a data a ter a hora atual.
    */
   public static void applyCurrentTime(Calendar date)
   {
      Calendar currentDate = getToCalendar(new Date());
      applyTime(date, currentDate.get(Calendar.HOUR_OF_DAY), currentDate.get(Calendar.MINUTE), currentDate
         .get(Calendar.SECOND), currentDate.get(Calendar.MILLISECOND));
   }

   /**
    * Aplica a hora atual na data, deixando como hora, o horario corrente hh:mm:ss.mmmm
    * 
    * @param date data a ter a hora atual.
    * @return Retorna data com hora atual, pois a data original � "desconsiderada" na convers�o para
    *         Calendar.
    */
   public static Date applyCurrentTime(Date date)
   {
      Calendar dateCalendar = getToCalendar(date);
      applyCurrentTime(dateCalendar);
      return dateCalendar.getTime();
   }

   /**
    * Aplica a ultima hora possivel de um dia na data, deixando como hora, o horario corrente
    * 23:59:59.999
    * 
    * @param date Calendar com a data a ter a ultima hora possivel.
    */
   public static void applyLastTime(Calendar date)
   {
      applyTime(date, 23, 59, 59, 999);
   }

   /**
    * Aplica a ultima hora possivel de um dia na data, deixando como hora, o horario corrente
    * 23:59:59.999
    * 
    * @param date data a ter a ultima hora possivel.
    * @return Retorna data com ultima hora possivel, pois a data original � "desconsiderada" na
    *         convers�o para Calendar.
    */
   public static Date applyLastTime(Date date)
   {
      Calendar dateCalendar = getToCalendar(date);
      applyLastTime(dateCalendar);
      return dateCalendar.getTime();
   }

   /**
    * Verifica se a data informada cai em um fim de semana (Sabado e Domingo).
    * 
    * @param date Data a ser verificada se e fim de semana
    * @return True se for fim de semana e false se nao for.
    */
   public static boolean isWeekend(Date date)
   {
      return isWeekend(getToCalendar(date));
   }

   /**
    * Verifica se a data informada cai em um fim de semana (Sabado e Domingo).
    * 
    * @param date Data a ser verificada se e fim de semana
    * @return True se for fim de semana e false se nao for.
    */
   public static boolean isWeekend(Calendar date)
   {
      boolean weekend = false;

      if (date == null)
      {
         throw new IllegalArgumentException("date is null");
      }

      switch (date.get(Calendar.DAY_OF_WEEK))
      {
         case Calendar.SATURDAY:
            weekend = true;
            break;
         case Calendar.SUNDAY:
            weekend = true;
            break;
      }

      return weekend;
   }

   /**
    * Retorna o proximo dia util apartir da data informada. Dia util considera-se a proxima
    * "segunda" se a data informada for um sabado ou domingo. Caso nao seja sabado ou domingo,
    * retorna apenas data original
    * 
    * @param date data se verificada para que retorne proximo dia util
    * @return Data do proximo dia util ou data original caso esta nao seja sabado ou domingo.
    */
   public static Date getNextBusinessDay(Date date)
   {
      Calendar dateCalendar = getToCalendar(date);
      getNextBusinessDay(dateCalendar);
      return dateCalendar.getTime();
   }

   /**
    * Retorna o proximo dia util apartir da data informada. Dia util considera-se a proxima
    * "segunda" se a data informada for um sabado ou domingo. Caso nao seja sabado ou domingo,
    * retorna apenas data original
    * 
    * @param date data se verificada para que retorne proximo dia util
    */
   public static void getNextBusinessDay(Calendar date)
   {
      switch (date.get(Calendar.DAY_OF_WEEK))
      {
         case Calendar.SATURDAY:
            date.add(Calendar.DAY_OF_MONTH, 1);
         case Calendar.SUNDAY:
            date.add(Calendar.DAY_OF_MONTH, 1);
      }
   }

   /**
    * Adiciona na data o no campo informado o valor desejado. Ex.: adicionar um dia na data. add(new
    * Date(), Calendar.DAY_OF_MONTH, 1)
    * 
    * @param date Data a ter adicionado o valor
    * @param field Atributo a qual deseja-se adicionar o valor, deve-se utilizar as constants de
    *        java.util.Calendar
    * @param amount Valor a ser adicionado na data.
    * @return data com valor adicionado
    */
   public static Date add(Date date, int field, int amount)
   {
      Calendar calendar = getToCalendar(date);
      calendar.add(field, amount);
      return calendar.getTime();
   }

   /**
    * Retorna da data o campo desejado. Ex.: retornar o dia da data. get(new Date(),
    * Calendar.DAY_OF_MONTH)
    * 
    * @param date Data a qual deseja-se retorna o valor do campo
    * @param field Atributo a qual deseja-se retornar o valor, deve-se utilizar as constants de
    *        java.util.Calendar
    * @return valor do campo informado
    */
   public static int get(Date date, int field)
   {
      Calendar calendar = getToCalendar(date);
      return calendar.get(field);
   }

   /**
    * Verifica se data informada esta entre as duas desejadas
    * 
    * @param date data a ser verificada
    * @param initialDate data inicial para avaliacao
    * @param finalDate data final de avaliacao
    * @return True se date estiver entre initialDate e finalDate, false se nao estiver
    */
   public static boolean isBetween(Calendar date, Calendar initialDate, Calendar finalDate)
   {
      clearTime(initialDate);
      applyLastTime(finalDate);
      return (date.after(initialDate) && date.before(finalDate));
   }

   /**
    * Verifica se data informada esta entre as duas desejadas
    * 
    * @param date data a ser verificada
    * @param initialDate data inicial para avaliacao
    * @param finalDate data final de avaliacao
    * @return True se date estiver entre initialDate e finalDate, false se nao estiver
    */
   public static boolean isBetween(Date date, Date initialDate, Date finalDate)
   {
      return isBetween(getToCalendar(date), getToCalendar(initialDate), getToCalendar(finalDate));
   }
}
