/*  1:   */ package br.com.virtuoso.prosaude.utils.view;
/*  2:   */ 
/*  3:   */ public class DataTableModel
/*  4:   */ {
/*  5:   */   private String sEcho;
/*  6:   */   private int iTotalRecords;
/*  7:   */   private int iTotalDisplayRecords;
/*  8:   */   private Object[] aaData;
/*  9:   */   
/* 10:   */   public String getsEcho()
/* 11:   */   {
/* 12:15 */     return this.sEcho;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setsEcho(String sEcho)
/* 16:   */   {
/* 17:19 */     this.sEcho = sEcho;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int getiTotalRecords()
/* 21:   */   {
/* 22:23 */     return this.iTotalRecords;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setiTotalRecords(int iTotalRecords)
/* 26:   */   {
/* 27:27 */     this.iTotalRecords = iTotalRecords;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public int getiTotalDisplayRecords()
/* 31:   */   {
/* 32:31 */     return this.iTotalDisplayRecords;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setiTotalDisplayRecords(int iTotalDisplayRecords)
/* 36:   */   {
/* 37:35 */     this.iTotalDisplayRecords = iTotalDisplayRecords;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public Object[] getAaData()
/* 41:   */   {
/* 42:39 */     return this.aaData;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public void setAaData(Object[] aaData)
/* 46:   */   {
/* 47:43 */     this.aaData = aaData;
/* 48:   */   }
/* 49:   */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.view.DataTableModel
 * JD-Core Version:    0.7.0.1
 */