/*  1:   */ package br.com.virtuoso.prosaude.utils.hibernate;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class WhereAndOrHQL
/*  7:   */ {
/*  8:12 */   public static final String AND = new String("AND");
/*  9:13 */   public static final String OR = new String("OR");
/* 10:   */   private String operadorBooleano;
/* 11:   */   private List<Object> wheres;
/* 12:   */   
/* 13:   */   public WhereAndOrHQL(String operadorBooleano)
/* 14:   */   {
/* 15:19 */     this.operadorBooleano = operadorBooleano;
/* 16:20 */     this.wheres = new ArrayList(3);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void add(WhereHQL whereHQL)
/* 20:   */   {
/* 21:24 */     this.wheres.add(whereHQL);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void add(WhereAndOrHQL whereAndOrHQL)
/* 25:   */   {
/* 26:28 */     this.wheres.add(whereAndOrHQL);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void remove(WhereAndOrHQL whereAndOrHQL)
/* 30:   */   {
/* 31:32 */     this.wheres.remove(whereAndOrHQL);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public ProSaudeMap gerarHql(StringBuffer hql, Integer offset)
/* 35:   */   {
/* 36:36 */     ProSaudeMap mapSet = new ProSaudeMap();
/* 37:37 */     return gerarHql(hql, offset, mapSet);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public ProSaudeMap gerarHql(StringBuffer hql, Integer offset, ProSaudeMap mapSet)
/* 41:   */   {
/* 42:41 */     if (this.wheres.isEmpty()) {
/* 43:42 */       return mapSet;
/* 44:   */     }
/* 45:44 */     hql.append("(");
/* 46:45 */     for (int i = 0; i < this.wheres.size(); i++)
/* 47:   */     {
/* 48:46 */       if (i > 0) {
/* 49:47 */         hql.append(" " + this.operadorBooleano + " ");
/* 50:   */       }
/* 51:49 */       Object objeto = this.wheres.get(i);
/* 52:50 */       if ((objeto instanceof WhereHQL))
/* 53:   */       {
/* 54:51 */         WhereHQL whereHQL = (WhereHQL)objeto;
/* 55:52 */         hql.append(whereHQL.gerarHql(Integer.valueOf(mapSet.size() + offset.intValue())));
/* 56:53 */         if (whereHQL.isValorConsulta().booleanValue()) {
/* 57:54 */           mapSet.putAll(whereHQL.getValorConsulta().getHql(new StringBuffer(), Integer.valueOf(mapSet.size() + offset.intValue())));
/* 58:55 */         } else if (whereHQL.existeValor()) {
/* 59:56 */           mapSet.put(whereHQL.getIdentificadorSet(), whereHQL.getValor());
/* 60:   */         }
/* 61:   */       }
/* 62:   */       else
/* 63:   */       {
/* 64:59 */         WhereAndOrHQL whereAndOrHQL = (WhereAndOrHQL)objeto;
/* 65:60 */         mapSet.putAll(whereAndOrHQL.gerarHql(hql, Integer.valueOf(mapSet.size() + offset.intValue())));
/* 66:   */       }
/* 67:   */     }
/* 68:63 */     hql.append(")");
/* 69:64 */     return mapSet;
/* 70:   */   }
/* 71:   */   
/* 72:   */   public Boolean isEmpty()
/* 73:   */   {
/* 74:68 */     return Boolean.valueOf(this.wheres.isEmpty());
/* 75:   */   }
/* 76:   */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.hibernate.WhereAndOrHQL
 * JD-Core Version:    0.7.0.1
 */