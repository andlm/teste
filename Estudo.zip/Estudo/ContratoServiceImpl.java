package com.nexxera.pds.service;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.usermodel.Range;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.international.StatusMessage;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.nexxera.pds.entity.Anexoarquivo;
import com.nexxera.pds.entity.Contrato;
import com.nexxera.pds.entity.Contratoarquivo;
import com.nexxera.pds.entity.Usuarioempresa;
import com.nexxera.pds.entity.enums.TipoPerfil;
import com.nexxera.pds.service.exception.ServiceException;
import com.nexxera.pds.utility.ResourceProperties;
import com.nexxera.pds.utility.SeamUtils;
import com.nexxera.pds.utility.StringUtil;
import com.nexxera.pds.utility.StringUtils;
import com.nexxera.pds.utility.paginator.PaginatedList;



@Name("contratoService")
@AutoCreate
@Stateless
public class ContratoServiceImpl implements ContratoService {

	@PersistenceContext
	private EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.nexxera.pds.service.ContratoService#cadastrar(com.nexxera.pds.entity.Contrato)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public void cadastrar(Contrato contrato) throws ServiceException 
	{
		StringBuffer hqlQuery = new StringBuffer(
				"select a.cdContrato from Contrato a " +
				"where a.cdContrato is not null "
				+ (!StringUtil.isEmpty(contrato.getDsContrato()) ? "and UPPER(dsContrato) = UPPER(:dsContrato) " : " ")
			);
		
		Query query = em.createQuery(hqlQuery.toString());
		
		if (!StringUtil.isEmpty(contrato.getDsContrato())) query.setParameter("dsContrato", contrato.getDsContrato());
		
		List<Object[]> resultado = query.getResultList();
		
		if(resultado.size() > 0)
		{
			throw new ServiceException("#{messages['contrato.existe']}");
		}
		em.persist(contrato);
	}

	/* (non-Javadoc)
	 * @see com.nexxera.pds.service.ContratoService#deletar(com.nexxera.pds.entity.Contrato)
	 */
	@Override
	public void deletar(Contrato contrato) 
	{
		 em.remove(em.merge(contrato));
	}

	/* (non-Javadoc)
	 * @see com.nexxera.pds.service.ContratoService#editar(com.nexxera.pds.entity.Contrato)
	 */
	@Override
	public void editar(Contrato contrato) 
	{
		 em.merge(contrato);
	}

	/* (non-Javadoc)
	 * @see com.nexxera.pds.service.ContratoService#pesquisar(com.nexxera.pds.entity.Contrato, java.lang.Integer, java.lang.Integer)
	 */
	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public PaginatedList<Contrato> pesquisar(Contrato contrato, Integer inicio, Integer quantidade) 
	{
		Session session = (Session) em.getDelegate();
		Criteria criteriaPrincipal = session.createCriteria(contrato.getClass());
		Criteria criteriaContagem = session.createCriteria(contrato.getClass());
		criteriaPrincipal.addOrder(Order.desc("cdContrato"));
		
		if(contrato.getDsContrato() != null)
		{
			criteriaPrincipal.add(Restrictions.like("dsContrato", contrato.getDsContrato(), MatchMode.ANYWHERE));
			criteriaContagem.add(Restrictions.like("dsContrato", contrato.getDsContrato(), MatchMode.ANYWHERE));
		}
		
		@SuppressWarnings("unchecked")
		List<Contrato> resultado = criteriaPrincipal.setFirstResult(inicio).setMaxResults(quantidade).list();
		int totalSize = ((Number) criteriaContagem.setProjection(Projections.rowCount()).uniqueResult()).intValue();

		return new PaginatedList<Contrato>(resultado, totalSize);
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public PaginatedList<Contrato> pesquisaMonitoramento(Contrato contrato, Usuarioempresa usuarioEmpresa, Date dataInicial, Date dataFinal, Integer inicio, Integer quantidade)
	{
		
		Session session = (Session) em.getDelegate();
		Criteria criteriaPrincipal = session.createCriteria(contrato.getClass());
		criteriaPrincipal.createAlias("cdContratadacontratante", "cc");
		Criteria criteriaContagem = session.createCriteria(contrato.getClass());
		criteriaContagem.createAlias("cdContratadacontratante", "cc");
		/*StringBuffer hqlQuery = new StringBuffer();
		hqlQuery.append("from Contrato c ");
		
		Query query = em.createQuery(hqlQuery.toString());*/
		
		if (usuarioEmpresa.getCdPerfil() == TipoPerfil.MONITORAMENTO) {
			Criterion contratante = Restrictions.eq("cc.cdEmpresacontratante", usuarioEmpresa.getCdEmpresa());
			Criterion contratada = Restrictions.eq("cc.cdEmpresacontratada", usuarioEmpresa.getCdEmpresa());
			criteriaPrincipal.add(Restrictions.or(contratante, contratada));
			criteriaContagem.add(Restrictions.or(contratante, contratada));
			//hqlQuery.append(" where (c.cdContratadacontratante.cdEmpresacontratante = :cdEmpresa or c.cdContratadacontratante.ccdEmpresacontratada = :cdEmpresa)");
		}
		else if (usuarioEmpresa.getCdPerfil() == TipoPerfil.ADMINISTRADOR_NEXXERA)
		{
			Criterion contratante = Restrictions.eq("cc.cdEmpresacontratante", usuarioEmpresa.getCdEmpresa());
			Criterion contratada = Restrictions.eq("cc.cdEmpresacontratada", usuarioEmpresa.getCdEmpresa());
			criteriaPrincipal.add(Restrictions.or(contratante, contratada));
			criteriaContagem.add(Restrictions.or(contratante, contratada));
			//hqlQuery.append(" where (c.cdContratadacontratante.cdEmpresacontratante = :cdEmpresa or c.cdContratadacontratante.ccdEmpresacontratada = :cdEmpresa)");
		}else if (usuarioEmpresa.getCdPerfil() == TipoPerfil.ADMINISTRADOR_CLIENTE)
		{
			Criterion contratante = Restrictions.eq("cc.cdEmpresacontratante", usuarioEmpresa.getCdEmpresa());
			Criterion contratada = Restrictions.eq("cc.cdEmpresacontratada", usuarioEmpresa.getCdEmpresa());
			criteriaPrincipal.add(Restrictions.or(contratante, contratada));
			criteriaContagem.add(Restrictions.or(contratante, contratada));
			//hqlQuery.append(" where (c.cdContratadacontratante.cdEmpresacontratante = :cdEmpresa or c.cdContratadacontratante.ccdEmpresacontratada = :cdEmpresa)");
		}else{
			Criterion contratante = Restrictions.eq("cc.cdEmpresacontratante", usuarioEmpresa.getCdEmpresa());
			Criterion contratada = Restrictions.eq("cc.cdEmpresacontratada", usuarioEmpresa.getCdEmpresa());
			criteriaPrincipal.add(Restrictions.or(contratante, contratada));
			criteriaContagem.add(Restrictions.or(contratante, contratada));
			/*hqlQuery.append(" where (c.cdContratadacontratante.cdEmpresacontratante = :cdEmpresa or c.cdContratadacontratante.ccdEmpresacontratada = :cdEmpresa)");
			query.setParameter("cdEmpresa", usuarioEmpresa.getCdEmpresa());*/
		}
		
		if (contrato.getCdContratadacontratante().getCdEmpresacontratante() != null) {
			criteriaPrincipal.add(Restrictions.eq("cc.cdEmpresacontratante", contrato.getCdContratadacontratante().getCdEmpresacontratante()));
			criteriaContagem.add(Restrictions.eq("cc.cdEmpresacontratante", contrato.getCdContratadacontratante().getCdEmpresacontratante()));
			/*hqlQuery.append(" and c.cdContratadacontratante.cdEmpresacontratante = :cdEmpresacontratante"); 
			query.setParameter("cdEmpresacontratante", contrato.getCdContratadacontratante().getCdEmpresacontratante());*/
		}
		
		if (contrato.getCdContratadacontratante().getCdEmpresacontratada() != null) {
			criteriaPrincipal.add(Restrictions.eq("cc.cdEmpresacontratada", contrato.getCdContratadacontratante().getCdEmpresacontratada()));
			criteriaContagem.add(Restrictions.eq("cc.cdEmpresacontratada", contrato.getCdContratadacontratante().getCdEmpresacontratada()));
			/*hqlQuery.append(" and c.cdContratadacontratante.cdEmpresacontratada = :cdEmpresacontratada");
			query.setParameter("cdEmpresacontratada", contrato.getCdContratadacontratante().getCdEmpresacontratada());*/
		}
		
		if (contrato.getCdTipooperacao() != null) {
			criteriaPrincipal.add(Restrictions.eq("cdTipooperacao", contrato.getCdTipooperacao()));
			criteriaContagem.add(Restrictions.eq("cdTipooperacao", contrato.getCdTipooperacao()));
			/*hqlQuery.append(" and c.cdTipooperacao = :cdTipooperacao");
			query.setParameter("cdTipooperacao", contrato.getCdTipooperacao());*/
		}
		
		if (dataInicial != null && dataFinal != null) {
			criteriaPrincipal.add(Restrictions.ge("dtContrato", dataInicial));
			criteriaPrincipal.add(Restrictions.le("dtContrato", dataFinal));
			criteriaContagem.add(Restrictions.ge("dtContrato", dataInicial));
			criteriaContagem.add(Restrictions.le("dtContrato", dataFinal));
			/*hqlQuery.append(" and c.dtContrato between  :dataInicial and :dataFinal");
			query.setParameter("dataInicial", dataInicial);
			query.setParameter("dataFinal", dataFinal);*/
		}else{
			if (dataInicial != null && dataFinal == null) {
				criteriaPrincipal.add(Restrictions.ge("dtContrato", dataInicial));
				criteriaContagem.add(Restrictions.ge("dtContrato", dataInicial));
				/*hqlQuery.append(" and c.dtContrato = :dataInicial");
				query.setParameter("dataInicial", dataInicial);*/
			}
			
			if (dataInicial == null && dataFinal != null) {
				criteriaPrincipal.add(Restrictions.le("dtContrato", dataFinal));
				criteriaContagem.add(Restrictions.le("dtContrato", dataFinal));
				/*hqlQuery.append(" and c.dtContrato = :dataFinal");
				query.setParameter("dataFinal", dataFinal);*/
			}
		}
		
		if (contrato.getDsContrato() != null && contrato.getDsContrato().length() > 0) {
			criteriaPrincipal.add(Restrictions.ilike("dsContrato", contrato.getDsContrato(), MatchMode.ANYWHERE));
			criteriaContagem.add(Restrictions.ilike("dsContrato", contrato.getDsContrato(), MatchMode.ANYWHERE));
			/*hqlQuery.append(" and c.dsContrato like :dsContrato");
			query.setParameter("dsContrato", "%"+contrato.getDsContrato()+"%");*/
		}
		
		if (contrato.getDtLimitecontrato() != null) {
			criteriaPrincipal.add(Restrictions.eq("dtLimitecontrato", contrato.getDtLimitecontrato()));
			criteriaContagem.add(Restrictions.eq("dtLimitecontrato", contrato.getDtLimitecontrato()));
			/*hqlQuery.append(" and c.dtLimitecontrato = :dtLimitecontrato");
			query.setParameter("dtLimitecontrato", contrato.getDtLimitecontrato());*/
		}
		
		
		
		
		
		if (inicio != null && quantidade != null) {
			criteriaPrincipal.setFirstResult(inicio).setMaxResults(quantidade).list();
		}
		
		@SuppressWarnings("unchecked")
		List<Contrato> resultado = criteriaPrincipal.list();
		int totalSize = ((Number) criteriaContagem.setProjection(Projections.rowCount()).uniqueResult()).intValue();
		
		
		return new PaginatedList<Contrato>(resultado, totalSize);
	}
	
	public byte[] gerarRelatorioCsvContrato(Contrato contrato, Usuarioempresa usuarioEmpresa, Date dataInicial, Date dataFinal) throws ServiceException
	{
		
		List<Contrato> contratos = this.pesquisaMonitoramento(contrato, usuarioEmpresa, dataInicial, dataFinal, null, null);
		
		StringBuffer strRelatorio = new StringBuffer();
		strRelatorio.append(StatusMessage.getBundleMessage("label.monitoramento.tipooperacao", null)+";");
		strRelatorio.append(StatusMessage.getBundleMessage("label.monitoramento.documento", null)+";");
		strRelatorio.append(StatusMessage.getBundleMessage("label.monitoramento.datacriacao", null)+";");
		strRelatorio.append(StatusMessage.getBundleMessage("label.monitoramento.datalimite", null)+";");
		strRelatorio.append(StatusMessage.getBundleMessage("label.monitoramento.valor", null)+";");
		strRelatorio.append(StatusMessage.getBundleMessage("label.monitoramento.contratada", null)+";");
		strRelatorio.append(StatusMessage.getBundleMessage("label.monitoramento.contratante", null)+";");
		strRelatorio.append(StatusMessage.getBundleMessage("label.monitoramento.status", null)+"\n");
		
		for (Contrato contratoAtual : contratos) {
			strRelatorio.append(contratoAtual.getCdTipooperacao().getNmTipooperacao()+";");
			strRelatorio.append(contratoAtual.getDsContrato()+";");
			strRelatorio.append(this.formatDate(contratoAtual.getDtContrato(), "dd/MM/yyyy hh:mm")+";");
			strRelatorio.append(this.formatDate(contratoAtual.getDtLimitecontrato(), "dd/MM/yyyy hh:mm")+";");
			strRelatorio.append(contratoAtual.getVlContrato()+";");
			strRelatorio.append(contratoAtual.getCdContratadacontratante().getCdEmpresacontratada().getNmEmpresa()+";");
			strRelatorio.append(contratoAtual.getCdContratadacontratante().getCdEmpresacontratante().getNmEmpresa()+";");
			strRelatorio.append(contratoAtual.getFgStatus().getNome()+"\n");
		}
		
		ByteArrayOutputStream f = new ByteArrayOutputStream();
		
		byte[] buf = strRelatorio.toString().getBytes();
		try {
			f.write(buf);
		} catch (IOException e) {
			throw new ServiceException("#{messages['contrato.gerarcao_relatorio_csv.invalido']}");
		}
		byte b[] = f.toByteArray(); 
		return b;
	}

	/* (non-Javadoc)
	 * @see com.nexxera.pds.service.ContratoService#listarTodos()
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Contrato> listarTodos() 
	{
		return em.createQuery("from Contrato order by dsContrato").getResultList();
	}
	
	private String formatDate(Date date, String format)
	{
		return new SimpleDateFormat(format).format(date);
	}
	
	public void setEm(EntityManager em) {
		this.em = em;
	}
	
	public Contrato consultaContratoPorCodigo(Contrato contrato)
	{
		return em.find(contrato.getClass(), contrato.getCdContrato());
	}
	
	public static List<InputStream> 	anexosPDF       		= new ArrayList<InputStream>();
	public static List<Anexoarquivo> 	arquivoPDF				= null;
	public static final String 			EXTENSAO_ARQUIVO		= ".pdf";
	private static String 				pdfNome					= "";
	private static File 				confFolder;
	
	public void mainContrato(Contratoarquivo contratoarquivo,String textoContrato, 
							 Contratoarquivo arquivoOriginal,
						 	 List<Anexoarquivo> contratoAnexos) throws Exception
	{
		anexosPDF       			= new ArrayList<InputStream>();
		if (contratoAnexos!=null)
		{
			arquivoPDF=new ArrayList<Anexoarquivo>();
			for(Anexoarquivo contratoAnexo : contratoAnexos)
			{
				arquivoPDF.add(contratoAnexo);
			}
		}
		if (arquivoPDF.size()>0)
		{
			Collections.sort(arquivoPDF, new Comparator<Anexoarquivo>()
			{
				@Override
				public int compare(Anexoarquivo arquivo0, Anexoarquivo arquivo1) 
				{
					return arquivo0.getCdSequencia().compareTo(arquivo1.getCdSequencia());
				}
			});
			generateTEMPPDF(contratoarquivo,arquivoOriginal,textoContrato);
			for(Anexoarquivo arquivotemp: arquivoPDF)
			{
				if (arquivotemp!=null)
				{
					// necessita criar o arquivo (doc,txt,pdf)
					if (arquivotemp.getFile()==null)
						arquivotemp.setFile(createTempAnexos(arquivotemp.getNmArquivo(),arquivotemp.getBnArquivo()));
					generateTEMPPDF(arquivotemp, arquivotemp.getNmArquivo(), 
							arquivotemp.getDescricao(), arquivotemp.isNovo());
				}
			}
			unificaPDFs(contratoarquivo,arquivoOriginal, false);
		}
		anexosPDF       	= null;
		arquivoPDF			= null;
	}
	
	private static String getTempDir() 
	{
		return System.getProperty("java.io.tmpdir");
	}
	
	private File createTempAnexos(String p_strFile,byte[] arquivoAnexoContrato) throws IOException
	{
		pdfNome = "";
		pdfNome = StringUtils.getTimeName()+".upload"+getFileExtension(p_strFile);
    	confFolder = createTempDir(null);
		File fileAnexoContrato = createTempFile(confFolder, pdfNome,"");
		FileOutputStream fosfileAnexoContrato = new FileOutputStream(fileAnexoContrato);
		fosfileAnexoContrato.write(arquivoAnexoContrato);
		fosfileAnexoContrato.close();
		return new File(fileAnexoContrato.getAbsolutePath());
	}
	
	private static File createTempDir(String diretorio) 
	{ 
		File tempDir = null;
	    final String baseTempPath = getTempDir(); 
	    if (diretorio == null )
		{ 
	    	tempDir = new File(baseTempPath);
	    }
	    else
	    {
	    	tempDir = new File(baseTempPath, diretorio);
	    }
	    if (tempDir.exists() == false) 
		{ 
	        tempDir.mkdir(); 
	    } 
	    return tempDir; 
	}
	
	private static File createTempFile(File dir, String file, String diretorio)
	{
		file = diretorio+""+file;
		File tempFile = new File(dir, file.trim());
		return tempFile;
	}

	public String getFileExtension(String p_strFile)
	{
		int intIndex=p_strFile.lastIndexOf('.');
		return (intIndex!=-1?p_strFile.substring(intIndex+1):"");
	}

	private void generateTEMPPDF(Anexoarquivo arquivotemp,String p_strFile, String p_strDescricao, boolean novo) throws Exception
	{
		
		String strExtension=null;
		strExtension=getFileExtension(p_strFile);
		if (arquivotemp.getFile()!=null)
		{
			if (strExtension.toUpperCase().equals("TXT"))
			{
				BufferedReader input = null;
				input   = new BufferedReader (new FileReader(arquivotemp.getFile()));
				Document documento = new Document();
				pdfNome = "";
				pdfNome = StringUtils.getTimeName()+".uploadtxt";
		    	confFolder = createTempDir(null);
				File fileAnexoContrato = createTempFile(confFolder, pdfNome,"");
			    PdfWriter.getInstance(documento, new FileOutputStream(fileAnexoContrato));
			    documento.open();
			    for (int k = 0; k <= 3; ++k)
				{
					documento.add(new Paragraph(" "));
					k++;
				}
			    Paragraph par = new Paragraph(p_strDescricao);
				par.setAlignment(Element.ALIGN_LEFT);
				documento.add(par);
				String line = "";
				while(null != (line = input.readLine()))
				{
					Paragraph p = new Paragraph(line);
					p.setAlignment(Element.ALIGN_JUSTIFIED);
					documento.add(p);
				}
				documento.close();
				input.close();
				anexosPDF.add(new FileInputStream(fileAnexoContrato));
			}
			else if(strExtension.toUpperCase().equals("DOC"))
			{
				File arquivo = arquivotemp.getFile();
				java.io.InputStream inputStream = new FileInputStream( arquivo );
				HWPFDocument document = new HWPFDocument(inputStream);
				Range range = document.getRange();
				StringBuilder builder= new StringBuilder( range.text());
				File fileAnexoContrato =null;
				if ( builder != null )
				{
					Document documento = new Document();
					pdfNome = "";
					pdfNome = StringUtils.getTimeName()+".uploaddoc";
			    	confFolder = createTempDir(null);
					fileAnexoContrato = createTempFile(confFolder, pdfNome,"");
				    PdfWriter.getInstance(documento, new FileOutputStream(fileAnexoContrato));
				    documento.open();
				    for (int k = 0; k <= 3; ++k)
					{
						documento.add(new Paragraph(" "));
						k++;
					}
					Paragraph par = new Paragraph(p_strDescricao);
					par.setAlignment(Element.ALIGN_LEFT);
					documento.add(par);
					documento.add( new Paragraph(builder.toString()) );
					documento.close();
				}
				anexosPDF.add(new FileInputStream(fileAnexoContrato));
			}
			else if(strExtension.toUpperCase().equals("PDF"))
			{
				anexosPDF.add(new FileInputStream(arquivotemp.getFile()));
			}
		}
	}


	private void generateTEMPPDF(Contratoarquivo contratoarquivo,Contratoarquivo arquivoOriginal,String textoContrato)	throws Exception
	{
		contratoarquivo.setNmArquivo(StringUtils.getTimeName()+arquivoOriginal.getNmArquivo());
		pdfNome = "";
		pdfNome = contratoarquivo.getNmArquivo();
    	confFolder = createTempDir(null);
		Document doc = new Document();
		File filePDFContrato = createTempFile(confFolder, pdfNome,"");
	    PdfWriter.getInstance(doc, new FileOutputStream(filePDFContrato));
	    doc.open();
	    doc.add( new Paragraph(textoContrato.toString()));
	    doc.close();
		anexosPDF.add(new FileInputStream(filePDFContrato));
	}

	private void unificaPDFs(Contratoarquivo contratoarquivo,Contratoarquivo arquivoOriginal,boolean p_blnPaginacao) throws Exception
	{
		Document contratoPDF       	= new Document(PageSize.A4,20,20,20,20);
		List<PdfReader> readers 	= new ArrayList<PdfReader>();
		Iterator<InputStream> iteratorPDFs = anexosPDF.iterator();
		while (iteratorPDFs.hasNext())
		{
		   InputStream pdf     = iteratorPDFs.next();
		   PdfReader pdfReader = new PdfReader(pdf);
		   readers.add(pdfReader);
		   pdfReader=null;
		}
		pdfNome = "";
		pdfNome = StringUtils.getTimeName()+arquivoOriginal.getNmArquivo();
		contratoarquivo.setNmArquivo(pdfNome);
		File filePDFContrato = createTempFile(confFolder, pdfNome,"");
		OutputStream outputStream = new FileOutputStream(filePDFContrato);
		PdfWriter writer = PdfWriter.getInstance(contratoPDF, outputStream);
		contratoPDF.open();
		PdfContentByte cb = null;
		cb=writer.getDirectContent();
		PdfImportedPage page			= null;
		int paginaCorrente  			= 0;
		int paginaCorrenteAux 			= 0;
		int quantidadePaginas  			= 0;
		Iterator<PdfReader> iteratorPDFReader = readers.iterator();
		while (iteratorPDFReader.hasNext())
		{
		   PdfReader pdfReader = iteratorPDFReader.next();
		   if (pdfReader!=null)
		   	quantidadePaginas+=pdfReader.getNumberOfPages();
		}
		paginaCorrente=0;
		for(Anexoarquivo objArquivo: arquivoPDF)
		{
			String strExtension=null;
			strExtension=getFileExtension(objArquivo.getNmArquivo());
			if((strExtension.toUpperCase().equals("JPG") ||
					strExtension.toUpperCase().equals("JPEG"))
					|| 		strExtension.toUpperCase().equals("PNG"))
			{
				if (objArquivo.getBnArquivo()!=null)
				{
					paginaCorrente++;
					quantidadePaginas+=paginaCorrente;
				}
				paginaCorrente=0;
			}
		}
		paginaCorrente=0;
		paginaCorrenteAux=0;
		iteratorPDFReader =null;
		iteratorPDFReader = readers.iterator();
		while (iteratorPDFReader.hasNext())
		{
		   PdfReader pdfReader = iteratorPDFReader.next();
		   while (paginaCorrente < pdfReader.getNumberOfPages())
		   {
		       contratoPDF.newPage();
		       paginaCorrente++;
		       paginaCorrenteAux++;
		       page = writer.getImportedPage(pdfReader,paginaCorrente);
		       cb.addTemplate(page, 0, 0);
		       EndPage(writer, contratoPDF,paginaCorrenteAux,quantidadePaginas);
		       
		   }
		   paginaCorrente = 0;
		   //contador++;
		}
		paginaCorrente=paginaCorrenteAux;
		for(Anexoarquivo objArquivo: arquivoPDF)
		{
			String strExtension=null;
			strExtension=getFileExtension(objArquivo.getNmArquivo());
			if((strExtension.toUpperCase().equals("JPG") ||
					strExtension.toUpperCase().equals("JPEG"))
						||	strExtension.toUpperCase().equals("PNG"))
			{
				if (objArquivo.getBnArquivo()!=null)
				{
					contratoPDF.newPage();
					paginaCorrente++;
					for (int k = 0; k <= 3; ++k)
					{
						contratoPDF.add(new Paragraph(" "));
						k++;
					}
					Paragraph par = new Paragraph(objArquivo.getDescricao());
					par.setAlignment(Element.ALIGN_LEFT);
					contratoPDF.add(par);
					Image img = Image.getInstance(objArquivo.getBnArquivo());
					img.setAlignment(Element.ALIGN_CENTER);

					//gira a imagem 180 graus sentido anti-hor�rio 
					if (objArquivo.isRotacao())
						img.setRotationDegrees (180.0f);

					contratoPDF.add(img);
					EndPage(writer, contratoPDF,paginaCorrente,quantidadePaginas);
				}
			}
		}
		outputStream.flush();
		contratoPDF.close();
		outputStream.close();
		if (contratoPDF.isOpen())
		       contratoPDF.close();
		if (outputStream != null)
		       outputStream.close();
		
		writer=null;
		readers=null;
		cb=null;
		outputStream=null;
		contratoPDF=null;
		
		byte[] bytes = getBytesFromFile(new File(filePDFContrato.getAbsolutePath()));
		contratoarquivo.setBnArquivo(bytes);
		contratoarquivo.setBnArquivoSign(bytes);
		SeamUtils.getComponent(ContratoArquivoService.class).cadastrar(contratoarquivo);
	}
	
	private byte[] getBytesFromFile(File file) throws FileNotFoundException,IOException
    {
	   	InputStream is = null;
	    is = new FileInputStream(file);
	    long length = file.length();
	   	if (length < Integer.MAX_VALUE) 
	   	{
    		byte[] bytes = new byte[(int)length];
    		int offset = 0;
    		int numRead = 0;
    		try 
    		{
    			while (offset < bytes.length && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
    				offset += numRead;
    			}
    		} catch (IOException e1) {
    			e1.printStackTrace();
    		}
    		if (offset < bytes.length) 
    				throw new IOException("Could not completely read file "+file.getName());
			is.close();
    		byte[] a = new byte[(int)length];
    		for (int i = 0; i < (int)length; i++) 
    		{
    			a[i] = bytes[i];
    		}
    		return a;
    	}
    	return null;
    }

	private static void EndPage(PdfWriter writer, Document contratoPDF,
								int paginaCorrente, int quantidadePaginas) throws Exception
	{
		Rectangle page = contratoPDF.getPageSize();
		File arquivoimg = new File(
			ResourceProperties.getPropertie("diretorio.root")+
				ResourceProperties.getPropertie("diretorio.contrato")+
					ResourceProperties.SEPARATOR_FILE+
	                   	"nexx_logo.png");
		if (arquivoimg.exists())
	   {
			Image img = Image.getInstance(arquivoimg.getAbsolutePath());
			PdfPTable cabecalho = new PdfPTable(2);
	       cabecalho.getDefaultCell().setBackgroundColor(Color.WHITE);
	       if (img!=null)
	       	cabecalho.addCell(new Phrase(new Chunk(img, 0, 0)));
	       else
	       	cabecalho.addCell(new Phrase("Contrato sem imagem"));
	       NumberFormat numero = NumberFormat.getInstance();
	       numero.setParseIntegerOnly(true);
	       numero.setMinimumIntegerDigits(3);
	       numero.setMaximumIntegerDigits(3);
	       PdfPCell cell = new PdfPCell();
			cell.setPhrase(new Phrase("P�gina: "+numero.format(paginaCorrente).replace(".","").trim() 
										 + " de " + numero.format(quantidadePaginas).replace(".","").trim()));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cabecalho.addCell(cell);
	       
	       PdfContentByte cb = writer.getDirectContent();
	       cb.saveState();
	       cabecalho.setTotalWidth(contratoPDF.right() - contratoPDF.left());
	       cabecalho.writeSelectedRows(0, -1, contratoPDF.leftMargin(),
	               page.height() - (2* contratoPDF.topMargin()+5) + cabecalho.getTotalHeight(), cb);
	       cabecalho=null;
	       img=null;
	       cell=null;
	       cb=null;
	       
	   }
		else
		{
	       PdfPTable cabecalho = new PdfPTable(2);
	       cabecalho.getDefaultCell().setBackgroundColor(Color.WHITE);
	       cabecalho.addCell(new Phrase("Contrato sem imagem"));
	       
	       NumberFormat numero = NumberFormat.getInstance();
	       numero.setParseIntegerOnly(true);
	       numero.setMinimumIntegerDigits(3);
	       numero.setMaximumIntegerDigits(3);
	       
	       PdfPCell cell = new PdfPCell();
			cell.setPhrase(new Phrase("P�gina: "+numero.format(paginaCorrente).replace(".","").trim() 
										 + " de " + numero.format(quantidadePaginas).replace(".","").trim()));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cabecalho.addCell(cell);
	       
	       PdfContentByte cb = writer.getDirectContent();
	       cb.saveState();
	       cabecalho.setTotalWidth(contratoPDF.right() - contratoPDF.left());
	       cabecalho.writeSelectedRows(0, -1, contratoPDF.leftMargin(),
	               page.height() - (2* contratoPDF.topMargin()+5) + cabecalho.getTotalHeight(), cb);
		
	       cabecalho=null;
	       cell=null;
	       cb=null;
		}
		arquivoimg=null;
		PdfPTable rodape 	= new PdfPTable(3);
		PdfPCell cell 		= new PdfPCell();
		cell.setBorder(0);
		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
		rodape.addCell(cell);
		DateFormat sf = new SimpleDateFormat("dd/MM/yyyy");
		Date data = new Date();
		cell = new PdfPCell(new Phrase(sf.format(data)));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
		cell.setBorder(0);
		rodape.addCell(cell);
		cell = new PdfPCell(new Phrase(""));
		cell.setBorder(0);
		rodape.addCell(cell);
		rodape.setTotalWidth(page.width() - contratoPDF.leftMargin()
		      - contratoPDF.rightMargin());
		rodape.writeSelectedRows(0, -1, contratoPDF.leftMargin(), contratoPDF
		      .bottomMargin(), writer.getDirectContent());
		rodape=null;
	   cell=null;
	}


}
