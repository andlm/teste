package com.nexxera.pds.utility;

import java.io.Serializable;

/**
 * Classe que auxilia na cria��o de CRUDs "OnePage", mantendo o estado de
 * variaveis de apoio dos tr�s "modos" desse tipo de CRUD.
 * 
 * @author Israel Fonseca
 * 
 */
public class CRUDController implements Serializable {

	private static final long serialVersionUID = 4999285302761195330L;

	private boolean cadastrar = false;
	private boolean editar = false;
	private boolean pesquisar = true;

	public void modoCadastrar() {
		cadastrar = true;
		editar = false;
		pesquisar = false;
	}

	public void modoEditar() {
		cadastrar = false;
		editar = true;
		pesquisar = false;
	}

	public void modoPesquisar() {
		cadastrar = false;
		editar = false;
		pesquisar = true;
	}

	/*
	 * Getters e Setters
	 */

	public boolean isCadastrar() {
		return cadastrar;
	}

	public boolean isEditar() {
		return editar;
	}

	public boolean isPesquisar() {
		return pesquisar;
	}

}