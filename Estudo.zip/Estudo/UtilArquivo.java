/*  1:   */ package br.com.virtuoso.prosaude.utils;
/*  2:   */ 
/*  3:   */ import br.com.caelum.vraptor.interceptor.download.Download;
/*  4:   */ import br.com.caelum.vraptor.interceptor.download.InputStreamDownload;
/*  5:   */ import br.com.caelum.vraptor.ioc.Component;
/*  6:   */ import br.com.virtuoso.prosaude.models.tabela.TabArquivoLinha;
/*  7:   */ import java.io.ByteArrayInputStream;
/*  8:   */ import java.util.Collection;
/*  9:   */ 
/* 10:   */ @Component
/* 11:   */ public class UtilArquivo
/* 12:   */ {
/* 13:   */   public Download makeTxt(Collection<TabArquivoLinha> arquivoLinhas, String nomeArquivo, boolean doDownload)
/* 14:   */   {
/* 15:18 */     StringBuffer arquivo = new StringBuffer();
/* 16:19 */     for (TabArquivoLinha linha : arquivoLinhas) {
/* 17:20 */       arquivo.append(linha.getLinha());
/* 18:   */     }
/* 19:22 */     byte[] conteudoBytes = arquivo.toString().getBytes();
/* 20:23 */     ByteArrayInputStream conteudoStream = new ByteArrayInputStream(conteudoBytes);
/* 21:24 */     return new InputStreamDownload(conteudoStream, "text/plain", nomeArquivo, doDownload, conteudoBytes.length);
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilArquivo
 * JD-Core Version:    0.7.0.1
 */