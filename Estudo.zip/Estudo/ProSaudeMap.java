/*  1:   */ package br.com.virtuoso.prosaude.utils.hibernate;
/*  2:   */ 
/*  3:   */ import java.util.LinkedHashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public class ProSaudeMap<K, V>
/*  7:   */   extends LinkedHashMap<K, V>
/*  8:   */   implements Map<K, V>
/*  9:   */ {
/* 10:   */   public ProSaudeMap() {}
/* 11:   */   
/* 12:   */   public ProSaudeMap(int initialCapacity)
/* 13:   */   {
/* 14:17 */     super(initialCapacity);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setAll(Map m)
/* 18:   */   {
/* 19:21 */     if ((m == null) || (this == m) || (m.isEmpty())) {
/* 20:22 */       return;
/* 21:   */     }
/* 22:24 */     for (K key : keySet())
/* 23:   */     {
/* 24:25 */       Object valor = get(key);
/* 25:26 */       if (valor != null) {
/* 26:29 */         set(key, get(key));
/* 27:   */       }
/* 28:   */     }
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void set(K key, V value)
/* 32:   */   {
/* 33:34 */     remove(key);
/* 34:35 */     put(key, value);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Long getLong(Object key)
/* 38:   */   {
/* 39:39 */     return (Long)get(key);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public Long getLongZeroSeNull(Object key)
/* 43:   */   {
/* 44:43 */     Long retorno = (Long)get(key);
/* 45:44 */     return Long.valueOf(retorno == null ? 0L : retorno.longValue());
/* 46:   */   }
/* 47:   */   
/* 48:   */   public String getString(Object key)
/* 49:   */   {
/* 50:48 */     return (String)get(key);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public String getStringBrancoSeNull(Object key)
/* 54:   */   {
/* 55:52 */     String retorno = (String)get(key);
/* 56:53 */     return retorno == null ? "" : retorno;
/* 57:   */   }
/* 58:   */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.hibernate.ProSaudeMap
 * JD-Core Version:    0.7.0.1
 */