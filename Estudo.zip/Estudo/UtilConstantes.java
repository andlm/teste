package br.com.virtuoso.prosaude.utils;

public class UtilConstantes
{
  public static final String SIM = "s";
  public static final String NAO = "n";
}


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilConstantes
 * JD-Core Version:    0.7.0.1
 */