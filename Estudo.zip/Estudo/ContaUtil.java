public class ContaUtil {
    
    public static void atualizarContaSalesforce(Id accountId) {
        Account conta = ConsultarCPFCNPJPorConta(accountId);
        getService(conta);
    }
    
    private static void getService(Account conta) 
    {
        if (conta!=null) {
        	
            WS_ConsultaDadosClientes.Registros_element_response registrosResponse = null;

            try  {
                // se os dois estão preenchidos
                boolean bFlClienteNaoEncontradoSAP = true;
                if (!String.isBlank(conta.CNPJ_KNA1_STCD1__c) && !String.isBlank(conta.Codigo_do_Cliente_KNA1_KUNNR__c)) {
                    registrosResponse  = null;
                    registrosResponse  = ConsultarDadosClientePorCodigoECPFCNPJ(conta.Codigo_do_Cliente_KNA1_KUNNR__c, conta.CNPJ_KNA1_STCD1__c);
                    if (registrosResponse!=null) {
                     
                        System.debug('ContaController::getService(1)::conta........'+registrosResponse.Action);
						
                        if (String.isBlank(registrosResponse.Action)) {
                            bFlClienteNaoEncontradoSAP = false;
                            atualizarConta(conta,registrosResponse);
                        }
                    }
                    
                    // se por acaso está preenchido os dois e voltou nulo porque o código está errado, consulta cnpj
                    if(bFlClienteNaoEncontradoSAP) {
                        if (!String.isBlank(conta.CNPJ_KNA1_STCD1__c)) {
                            registrosResponse = null;
                            registrosResponse = ConsultarDadosClientePorCPFCNPJ(conta.CNPJ_KNA1_STCD1__c);
                            if (registrosResponse!=null) {
                                
                                System.debug('ContaController::getService(2)::conta........'+registrosResponse.Action);
						
                                if (String.isBlank(registrosResponse.Action)){
                                    bFlClienteNaoEncontradoSAP = false;
                                    atualizarConta(conta,registrosResponse);
                                }
                            }
                        }
                    }
                    
                    // se por acaso está preenchido os dois e voltou nulo porque o cnpj está errado, consulta código
                    if(bFlClienteNaoEncontradoSAP) {
                    	if (!String.isBlank(conta.Codigo_do_Cliente_KNA1_KUNNR__c)) {
                            registrosResponse = null;
                            registrosResponse = ConsultarDadosClientePorCodigo(conta.Codigo_do_Cliente_KNA1_KUNNR__c);
                            if (registrosResponse!=null) {
                                
                                System.debug('ContaController::getService(3)::conta........'+registrosResponse.Action);
						
                                if (String.isBlank(registrosResponse.Action)) {
                                    bFlClienteNaoEncontradoSAP = false;
                                    atualizarConta(conta,registrosResponse);
                                }
                            }
                        }
                    }
                } else {
                    if (!String.isBlank(conta.CNPJ_KNA1_STCD1__c)) {
                        registrosResponse  = null;
                        registrosResponse = ConsultarDadosClientePorCPFCNPJ(conta.CNPJ_KNA1_STCD1__c);
                        if (registrosResponse!=null) {
                            
                            System.debug('ContaController::getService(4)::conta........'+registrosResponse.Action);
						
                            if (String.isBlank(registrosResponse.Action)) {
                            	atualizarConta(conta,registrosResponse);
                            }
                        }
                    } else {
                        if (!String.isBlank(conta.Codigo_do_Cliente_KNA1_KUNNR__c)) {
                            registrosResponse  = null;
                            registrosResponse = ConsultarDadosClientePorCodigo(conta.Codigo_do_Cliente_KNA1_KUNNR__c);
                            if (registrosResponse!=null) {
                                
                                System.debug('ContaController::getService(5)::conta........'+registrosResponse.Action);
                                if (String.isBlank(registrosResponse.Action)) {
                                	atualizarConta(conta,registrosResponse);
                                }
                            }
                        }
                    }
                }
            } catch(Exception e) {
                System.debug('ContaController::getService(5)........Erro');
                System.debug(e);
            }
        }
    }
    
    private static void atualizarConta(Account conta, WS_ConsultaDadosClientes.Registros_element_response registrosResponse) {
        conta = convertSAPObjetoParaConta(conta,registrosResponse);
        String strJSON = JSON.serialize(conta);
		system.debug('ContaController::atualizarConta(0)::conta(JSON) - ' + strJSON);
        update(conta);
        
        excluirVolumeVenda(conta);
        
        incluirVolumeVenda(conta,registrosResponse);
    }
    
    private static void excluirVolumeVenda(Account conta){
        List<Volume_de_vendas__c> listaVolumeVendasContaExcluir = ConsultarVolumeVendasPorConta(conta.Id);
        if ( !listaVolumeVendasContaExcluir.isEmpty()){
        	delete listaVolumeVendasContaExcluir;
        }
    }
    
    private static void incluirVolumeVenda(Account conta, WS_ConsultaDadosClientes.Registros_element_response registrosResponse) {
    
    	List<Volume_de_vendas__c> listaVolumeVendasConta = new List<Volume_de_vendas__c>();
 		for(WS_ConsultaDadosClientes.VolumeVendasAnuais volume : registrosResponse.VolumeVendasAnuais){
            listaVolumeVendasConta.add(inserirVolumeVendas(conta, volume));
        }
        
        if ( !listaVolumeVendasConta.isEmpty()){
        	insert(listaVolumeVendasConta);
        }
    }
    
    private static void incluirConta(Account conta, WS_ConsultaDadosClientes.Registros_element_response registrosResponse) {
        conta = convertSAPObjetoParaConta(conta,registrosResponse);
        insert(conta);
    }
    
    private static Account convertSAPObjetoParaConta(Account conta, WS_ConsultaDadosClientes.Registros_element_response registrosResponse) {
        conta.Grp_Contas_Cliente_KNA1_KTOKD__c = registrosResponse.GrpContasCliente;           
        conta.Codigo_do_Cliente_KNA1_KUNNR__c  = registrosResponse.CodCliente;          
        conta.Empresa__c = registrosResponse.Empresa;                    
        conta.Organizacao_de_vendas_VBAK_VKORG__c = registrosResponse.OrgVendas;                  
        conta.Canal_de_distribuicao_VBAK_VTWEG__c = registrosResponse.CanalDistrib;               
        conta.Setor_de_atividade_VBAK_SPART__c = registrosResponse.SetorAtividade;             
        conta.Name = registrosResponse.Nome1 + ' ' + registrosResponse.Nome2;                      
                            
        conta.Complemento_billingAddress__c = registrosResponse.Supl;                       
                           
             
        // Endereço de cobrança
        conta.BillingStreet = registrosResponse.RuaNumero1 + ' ' + registrosResponse.RuaNumero2;
        conta.Nr_morada_apto_sala_ADRC_ROOMNUMBER__c = registrosResponse.Numero; 
        conta.bairro_billingBairro_ADDR1_DATA_CITY2__c = registrosResponse.Bairro;  
        conta.BillingCity = registrosResponse.Cidade; 
        conta.Regiao_pais_uf_provinc_condad_KNA1_REGIO__c = registrosResponse.Regiao; 
        conta.BillingCountry = registrosResponse.Pais;
        conta.BillingState = registrosResponse.Regiao; 
        conta.BillingPostalCode=registrosResponse.CodigoPostal; 
        conta.Cx_Postal_KNA1_PFACH__c = registrosResponse.CodigoPostal;  

		// Endereço de faturamento e de Entrega
		conta.ShippingStreet=registrosResponse.RuaNumero1 + ' ' + registrosResponse.RuaNumero2;
        conta.ShippingCity=registrosResponse.Cidade; 
        conta.ShippingState= registrosResponse.Regiao; 
        conta.ShippingPostalCode=registrosResponse.CodigoPostal; 
        conta.ShippingCountry=registrosResponse.Pais;        
                            
        conta.Coddomic_fisc_loc_p_c_imposto_KNA1_TXJCD__c = registrosResponse.DomicilioFiscal;            
        conta.Zn_transp_p_a_q_ouda_q_e_forn_KNA1_LZONE__c = registrosResponse.ZonaTransporte;             
        conta.Phone = registrosResponse.Telefone;                   
        conta.Telefone_celular_SZA1_MOB_NUMBER__c = registrosResponse.TelCelular;                 
        conta.Fax = registrosResponse.Fax;                        
        conta.Endereco_de_E_mail_ADR6_SMTP_ADDR__c = String.isBlank(registrosResponse.EMail) ? '' : registrosResponse.EMail.replace( '#', '@' );  
        
     	System.debug('ContaController::registrosResponse.EMail.......: ' + registrosResponse.EMail);
		System.debug('ContaController::conta.Endereco_de_E_mail_ADR6_SMTP_ADDR__.......: ' + conta.Endereco_de_E_mail_ADR6_SMTP_ADDR__c);
        
        conta.CNPJ_KNA1_STCD1__c = registrosResponse.CNPJ;                       
        conta.IE_Inscricao_Estadual_KNA1_STCD3__c = registrosResponse.IE;                         
        conta.RG_Reg_Geral_Insc_Munic_P_PJ_KNA1_STCD4__c = registrosResponse.RGInscEstadual;             
        conta.Categoria_CFOP_do_cliente_KNA1_CFOPC__c = registrosResponse.CtgCFOP;                    
        conta.Suframa__c = registrosResponse.Suframa;                    
        conta.Natureza_Jur_dica__c = String.isBlank(registrosResponse.NaturzJurid) ? 0.00 : Decimal.valueOf(registrosResponse.NaturzJurid.trim());                
        conta.Direito_fiscal_ICMS_KNA1_TXLW2__c = registrosResponse.ContrICMS;   
        
        if (null != formataData(registrosResponse.DataNascimento))
            conta.Data_de_nascimento_KNVK_GBDAT__c = formataData(registrosResponse.DataNascimento);
        
        conta.Ponto_de_descarga__c = registrosResponse.PontoDescarga;  
        conta.Ponto_de_descarga_default__c = formataPontoDescargaDefault(registrosResponse);
        conta.Calend_rio_f_brica_cliente__c = registrosResponse.CalendarioFabrica;      
        conta.Cta_reconcil_na_contab_gr_KNB1_AKONT__c = registrosResponse.CtaConcil;                  
        conta.Grupo_de_adm_tesouraria_KNB1_FDGRV__c = registrosResponse.GrpAdminTesour;             
        conta.Forma_de_pagamento__c = registrosResponse.FormaPagamento; 
        conta.Registro_de_vendas_KNVV_BZIRK__c = registrosResponse.RegVendas;                  
        conta.Escrit_de_vendas_KNVV_VKBUR__c = registrosResponse.EscritVendas;               
        conta.Grupo_de_vendas_KNVV_VKGRP__c = registrosResponse.GrpVendas; 
        conta.Grupo_Cliente_KNVV_KDGRP__c = registrosResponse.GrpClientes;                
        conta.CurrencyIsoCode = registrosResponse.Moeda;                      
        conta.Grupo_de_pre_o__c = registrosResponse.GrpPreco;    
        conta.Lista_preco_sap__c = registrosResponse.ListaPrecos;                
        conta.condi_o_de_expedi_o__c = registrosResponse.CondExpedicao;              
        conta.Incoterms__c = registrosResponse.Incoterms;                  
        conta.Cond_pagamento_faturamento__c = registrosResponse.CondPagamentoFat;           
        
        conta.Email_do_destinat_rio__c = formataEmailDestinatario(registrosResponse);    
        //System.debug('ContaController::registrosResponse.EmailDestinatario(WS).......: ' + registrosResponse.EmailDestinatario);
		//System.debug('ContaController::registrosResponse.EmailDestinatario(SL).......: ' + formataEmailDestinatario(registrosResponse));
        System.debug('ContaController::conta.Email_do_destinat_rio__c.......: ' + conta.Email_do_destinat_rio__c);
        
        conta.Limite_de_credito__c = FormatValues.currencyBRL(registrosResponse.LimiteCredito, 2);
        conta.Disponibilidade_de_cr_dito__c = FormatValues.currencyBRL(registrosResponse.CreditoDisponivel, 2); 
        
        conta.Percentual_de_utilizacao__c = String.isBlank(registrosResponse.GrauUtilizacao) ? 0.00 : Decimal.valueOf(registrosResponse.GrauUtilizacao.trim())/100;              
        
        conta.Nr_internac_localizacao2_KNA1_BBSNR__c = String.isBlank(registrosResponse.LocalizacaoGeografica) ? 0.00 : Decimal.valueOf(registrosResponse.LocalizacaoGeografica.trim());         
        conta.Segmento__c = registrosResponse.Segmento;                   
        conta.Descri_o_do_segmento__c = registrosResponse.DescSegmento; 

        conta.Descri_o_de_condi_es_de_pagamento__c =registrosResponse.DescCondPagamento;
        conta.Condicao_de_Pagamento__c = registrosResponse.CondPagamento;
       	
        conta.Direito_fiscal_ICMS_KNA1_TXLW2__c = registrosResponse.ContrICMS;   
        conta.Descri_o_de_contribui_o_ICMS__c = registrosResponse.DescContrICMS;
		
		conta.CNAE__c = registrosResponse.CNAE;
		conta.Descri_o_de_CNAE__c = registrosResponse.DescCNAE;
		
		conta.Forma_de_pagamento__c = registrosResponse.FormaPagamento;
		conta.Descri_o_de_forma_de_pagamento__c = registrosResponse.DescFormaPagamento;
        
		conta.Escrit_de_vendas_KNVV_VKBUR__c = registrosResponse.EscritVendas;   
        conta.Descri_o_de_escritura_o_de_vendas__c = registrosResponse.DescEscritVendas;
        
        return conta;
    }

    private static Volume_de_vendas__c inserirVolumeVendas(Account conta, WS_ConsultaDadosClientes.VolumeVendasAnuais volume) {
        
        Volume_de_vendas__c volumeVenda = new Volume_de_vendas__c();
        if (conta !=null) 
        {
            volumeVenda.Ano__c = volume.Ano;
            volumeVenda.Conta__c = conta.Id;
            volumeVenda.CurrencyIsoCode = conta.CurrencyIsoCode;
            volumeVenda.Quantidade_faturada__c = volume.Quantidade; 
            volumeVenda.Volume_de_vendas__c	 = String.isBlank(volume.Faturamento) ? 0.00 : Decimal.valueOf(volume.Faturamento.trim());   
        }
        
        return volumeVenda;
    }
    
    private static String formataEmailDestinatario(WS_ConsultaDadosClientes.Registros_element_response registrosResponse) {
        
		string [] arrAddress = null;
		string sNovoEmailDestinatario= '';
		if (!String.isBlank(registrosResponse.EmailDestinatario)) {
			string sWSEmailDestinatario= registrosResponse.EmailDestinatario.replace( '#', '@' );
			arrAddress = sWSEmailDestinatario.split(';',0);
			for (String sEmailDestinatario: arrAddress) {
				if (validateEmail(sEmailDestinatario)){
					sNovoEmailDestinatario = sNovoEmailDestinatario + sEmailDestinatario;
                    break;
				}
			}
		}
		return sNovoEmailDestinatario;
    }
	
	public static Boolean validateEmail(String email) {
		Boolean res = true;
		String emailRegex = '^[a-zA-Z0-9._|\\\\%#~`=?&/$^*!}{+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$'; // source: <a href="http://www.regular-expressions.info/email.html" target="_blank" rel="nofollow">http://www.regular-expressions.info/email.html</a>
		Pattern MyPattern = Pattern.compile(emailRegex);
		Matcher MyMatcher = MyPattern.matcher(email);
		if (!MyMatcher.matches()) 
			res = false;
		return res;	
	}
    
    private static boolean formataPontoDescargaDefault(WS_ConsultaDadosClientes.Registros_element_response registrosResponse) {
        if (!String.isBlank(registrosResponse.PontoDescargaDefault)) 
            if (registrosResponse.PontoDescargaDefault.toUpperCase().trim().equals('X') ) 
            	return Boolean.valueOf('true');
        return Boolean.valueOf('false');     
    }
    
    private static Integer[] ParsedDate (String DateString) {
        String month = null;
        String year = null;
        String day = null;
        
        Integer[] arr=new Integer[3];

        for(Integer i = 0; i < DateString.length(); i++) {
            if(i<4) {
                year = DateString.substring(0,4);
            } 
            if(i>=4 && i<=5) {
                month = DateString.substring(4,6);
            } 
            if(i>=6 && i<=7) {
                day = DateString.substring(6,8);
            }   
        }
        
        arr[0]=Integer.valueOf(year);
        arr[1]=Integer.valueOf(month);
        arr[2]=Integer.valueOf(day);
        return arr;
    }
    
    private static Date formataData(String DateString) {
        try {
           Integer[] strDate= ParsedDate(DateString);
           Integer day 	= integer.valueOf(strDate[2]);
		   if (day==0) return null;	
           
           Integer month 	= integer.valueOf(strDate[1]);
           if (month==0) return null;
    
           Integer year 	= integer.valueOf(strDate[0]);
           if (year==0) return null;
           
           Date d = Date.newInstance(year, month, day);
           return d;
        }catch (Exception e) {
            return null;
        }
    }
    
    private static List<Volume_de_vendas__c> ConsultarVolumeVendasPorConta(Id accountId) {
        try{
        	return [select Id from Volume_de_vendas__c where Conta__r.Id = :accountId];
        } catch(QueryException e) {
            System.debug('ContaController::ConsultarVolumeVendasPorConta.......: ' + e.getMessage());
            return null;
        }
    }
    
    private static Account ConsultarCPFCNPJECodigoClientePorConta(Id accountId) {
        try{
        	return [select Id, CNPJ_KNA1_STCD1__c, Codigo_do_Cliente_KNA1_KUNNR__c from Account where Id= :accountId limit 1];
        } catch(QueryException e) {
            System.debug('ContaController::ConsultarCPFCNPJECodigoClientePorConta.......: ' + e.getMessage());
            return null;
        }
    }
    
    /*private static Condicoes_de_pagamento__c ConsultarCondicaoPgtoPorCodigoSAP(String sCondPagamento) {
        try{
        	return [select Name from Condicoes_de_pagamento__c  where Condi_o_de_pagamento__c=:sCondPagamento limit 1];
        } catch(QueryException e) {
            System.debug('ContaController::ConsultarCondicaoPgtoPorCodigoSAP.......: ' + e.getMessage());
            return null;
        }
    }

    */
    
    private static Account ConsultarCPFCNPJPorConta(Id accountId) {
        try{
        	return [select Id, CNPJ_KNA1_STCD1__c, Codigo_do_Cliente_KNA1_KUNNR__c from Account where Id= :accountId limit 1];
        } catch(QueryException e) {
            System.debug('ContaController::ConsultarCPFCNPJPorConta.......: ' + e.getMessage());
            return null;
        }
    }
    
    private static Account ConsultarCodigoClientePorConta(Id accountId) {
        try{
        	return [select Id, Codigo_do_Cliente_KNA1_KUNNR__c from Account where Id = :accountId limit 1];
        } catch(QueryException e) {
            System.debug('ContaController::ConsultarCodigoClientePorConta.......: ' + e.getMessage());
            return null;
        }
    }
    
    private static WS_ConsultaDadosClientes.Registros_element_response ConsultarDadosClientePorCodigo(String sCodigoCliente) {
        List<WS_ConsultaDadosClientes.Registros_element_response> registrosResponse = ConsultarDadosClientesPorCodigo(sCodigoCliente);
        return ( registrosResponse.isEmpty() ? null : registrosResponse.get(0)) ;
    }
    
    private static WS_ConsultaDadosClientes.Registros_element_response ConsultarDadosClientePorCPFCNPJ(String sCPFCNPJ) {
        List<WS_ConsultaDadosClientes.Registros_element_response> registrosResponse = ConsultarDadosClientesPorCPFCNPJ(sCPFCNPJ);
        return ( registrosResponse.isEmpty() ? null : registrosResponse.get(0)) ;
    }
    
    private static WS_ConsultaDadosClientes.Registros_element_response ConsultarDadosClientePorCodigoECPFCNPJ(String sCodigoCliente, String sCPFCNPJ) {
        List<WS_ConsultaDadosClientes.Registros_element_response> registrosResponse = ConsultarDadosClientesPorCodigoECPFCNPJ(sCodigoCliente,sCPFCNPJ);
        return registrosResponse.isEmpty() ? null : registrosResponse.get(0) ;
    }
    
    private static List<WS_ConsultaDadosClientes.Registros_element_response> ConsultarDadosClientesPorCodigo(String sCodigoCliente) {
        WS_ConsultaDadosClientes.Registros_element registro = new WS_ConsultaDadosClientes.Registros_element();
        registro.CodigoCliente = sCodigoCliente;
    	return ConsultarDadosClientesPorRegistro(registro);
    }
    
    private static List<WS_ConsultaDadosClientes.Registros_element_response> ConsultarDadosClientesPorCPFCNPJ(String sCPFCNPJ) {
        WS_ConsultaDadosClientes.Registros_element registro = new WS_ConsultaDadosClientes.Registros_element();
        registro.CPF_CNPJ = sCPFCNPJ;
    	return ConsultarDadosClientesPorRegistro(registro);
    }
    
    private static List<WS_ConsultaDadosClientes.Registros_element_response> ConsultarDadosClientesPorCodigoECPFCNPJ(String sCodigoCliente, String sCPFCNPJ) {
        WS_ConsultaDadosClientes.Registros_element registro = new WS_ConsultaDadosClientes.Registros_element();
        registro.CodigoCliente = sCodigoCliente;
        registro.CPF_CNPJ = sCPFCNPJ;
    	return ContaUtil.ConsultarDadosClientesPorRegistro(registro);   
    }
  
    private static List<WS_ConsultaDadosClientes.Registros_element_response> ConsultarDadosClientesPorRegistro(WS_ConsultaDadosClientes.Registros_element registro) {
        try{
            WS_ConsultaDadosClientes.HTTPS_Port port = new WS_ConsultaDadosClientes.HTTPS_Port();
            List<WS_ConsultaDadosClientes.Registros_element> registros = new List<WS_ConsultaDadosClientes.Registros_element>(); 
            registros.add(registro);
            List<WS_ConsultaDadosClientes.Registros_element_response> registrosResponse = new List<WS_ConsultaDadosClientes.Registros_element_response>();
            
            registrosResponse = port.SI_SALESFORCE_REQUEST_ConsultaCliente_out_sync(registros);
            System.debug('ContaController::WS_ConsultaDadosClientes........: ' + registrosResponse);
        return registrosResponse;
        } catch(CalloutException ex) {
            System.debug('ContaController.WS_ConsultaDadosClientes...: ' + ex);
            return null;
        }
    }
}