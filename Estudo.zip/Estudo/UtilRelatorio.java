/*  1:   */ package br.com.virtuoso.prosaude.utils;
/*  2:   */ 
/*  3:   */ import br.com.caelum.vraptor.interceptor.download.Download;
/*  4:   */ import br.com.caelum.vraptor.interceptor.download.InputStreamDownload;
/*  5:   */ import br.com.caelum.vraptor.ioc.Component;
/*  6:   */ import java.io.ByteArrayInputStream;
/*  7:   */ import java.io.ByteArrayOutputStream;
/*  8:   */ import java.util.Collection;
/*  9:   */ import java.util.HashMap;
/* 10:   */ import java.util.Map;
/* 11:   */ import javax.servlet.ServletContext;
/* 12:   */ import net.sf.jasperreports.engine.JRExporter;
/* 13:   */ import net.sf.jasperreports.engine.JRExporterParameter;
/* 14:   */ import net.sf.jasperreports.engine.JasperFillManager;
/* 15:   */ import net.sf.jasperreports.engine.JasperPrint;
/* 16:   */ import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
/* 17:   */ import net.sf.jasperreports.engine.export.JRPdfExporter;
/* 18:   */ 
/* 19:   */ @Component
/* 20:   */ public class UtilRelatorio
/* 21:   */ {
/* 22:   */   private final String jasperDir;
/* 23:   */   private final String contextDir;
/* 24:   */   
/* 25:   */   public UtilRelatorio(ServletContext servletContext)
/* 26:   */   {
/* 27:33 */     this.contextDir = servletContext.getRealPath("/");
/* 28:34 */     String temp = servletContext.getInitParameter("vraptor.utilRelatorio");
/* 29:35 */     temp = temp == null ? "WEB-INF/jasper/" : temp.trim();
/* 30:36 */     if (!temp.endsWith("/")) {
/* 31:37 */       temp = temp.concat("/");
/* 32:   */     }
/* 33:38 */     this.jasperDir = (temp.startsWith("/") ? temp : this.contextDir.concat(temp));
/* 34:   */   }
/* 35:   */   
/* 36:   */   public Download makePdf(String jasperFile, Collection<?> dataSource, String fileName, boolean doDownload)
/* 37:   */   {
/* 38:56 */     return makePdf(jasperFile, dataSource, fileName, doDownload, new HashMap());
/* 39:   */   }
/* 40:   */   
/* 41:   */   public Download makePdf(String jasperFile, Collection<?> dataSource, String fileName, boolean doDownload, Map<String, Object> parametros)
/* 42:   */   {
/* 43:74 */     jasperFile = this.jasperDir + jasperFile;
/* 44:75 */     parametros.put("JASPER_PATH", this.jasperDir);
/* 45:76 */     parametros.put("CONTEXT_PATH", this.contextDir);
/* 46:   */     try
/* 47:   */     {
/* 48:78 */       JasperPrint print = JasperFillManager.fillReport(jasperFile, parametros, new JRBeanCollectionDataSource(dataSource));
/* 49:   */       
/* 50:80 */       JRExporter exporter = new JRPdfExporter();
/* 51:   */       
/* 52:82 */       ByteArrayOutputStream exported = new ByteArrayOutputStream();
/* 53:   */       
/* 54:84 */       exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, exported);
/* 55:85 */       exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
/* 56:   */       
/* 57:87 */       exporter.exportReport();
/* 58:   */       
/* 59:89 */       byte[] content = exported.toByteArray();
/* 60:   */       
/* 61:91 */       return new InputStreamDownload(new ByteArrayInputStream(content), "application/pdf", fileName, doDownload, content.length);
/* 62:   */     }
/* 63:   */     catch (Exception e)
/* 64:   */     {
/* 65:94 */       throw new RuntimeException(e);
/* 66:   */     }
/* 67:   */   }
/* 68:   */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilRelatorio
 * JD-Core Version:    0.7.0.1
 */