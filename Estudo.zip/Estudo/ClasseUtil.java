package br.medcorp.arquitetura.utils;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public class ClasseUtil {

	public static Class<?> getClasseGenerica(Class<?> classe, int arg){
		Type type = classe.getGenericSuperclass();
		while(!(type instanceof ParameterizedType )){
			type = ((Class<?>) type).getGenericSuperclass();
		}
		return (Class<?>) ((ParameterizedType) type).getActualTypeArguments()[arg];
	}
	
}
