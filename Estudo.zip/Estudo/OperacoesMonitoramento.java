package com.nexxera.pds.entity.enums;

public enum OperacoesMonitoramento {

	VISUALIZAR("Visualizar"),
	TRACKING("Tracking");
	
	private String nome;
	
	private OperacoesMonitoramento(String nome) {
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
}
