/*   1:    */ package br.com.virtuoso.prosaude.utils.hibernate;
/*   2:    */ 
/*   3:    */ public class WhereHQL
/*   4:    */ {
/*   5:  9 */   public static final String MAIOR = new String(">");
/*   6: 10 */   public static final String MAIOR_IGUAL = new String(">=");
/*   7: 11 */   public static final String MENOR = new String("<");
/*   8: 12 */   public static final String MENOR_IGUAL = new String("<=");
/*   9: 13 */   public static final String IGUAL = new String("=");
/*  10: 14 */   public static final String DIFERENTE = new String("!=");
/*  11: 15 */   public static final String LIKE = new String("LIKE");
/*  12: 16 */   public static final String LIKE_LEFT = new String("LIKE_LEFT");
/*  13: 17 */   public static final String LIKE_RIGHT = new String("LIKE_RIGHT");
/*  14: 18 */   public static final String LIKE_BOTH = new String("LIKE_BOTH");
/*  15: 19 */   public static final String ENTRE = new String("BETWEEN");
/*  16: 20 */   public static final String IN = new String("IN");
/*  17: 21 */   public static final String NOT_IN = new String("NOT IN");
/*  18: 22 */   public static final String IS_NULL = new String("IS NULL");
/*  19: 23 */   public static final String IS_NOT_NULL = new String("IS NOT NULL");
/*  20: 24 */   public static final String EXISTS = new String("EXISTS");
/*  21: 25 */   public static final String NOT_EXISTS = new String("NOT EXISTS");
/*  22:    */   private Integer id;
/*  23:    */   private String atributo;
/*  24:    */   private Object valor;
/*  25:    */   private String operadorLogico;
/*  26:    */   private String subSelect;
/*  27: 32 */   private Boolean valorEhOutroAtributo = Boolean.valueOf(false);
/*  28:    */   
/*  29:    */   public WhereHQL(String atributo, Object valor, String operadorLogico, Boolean valorEhOutroAtributo)
/*  30:    */   {
/*  31: 35 */     this(atributo, valor, operadorLogico);
/*  32: 36 */     this.valorEhOutroAtributo = valorEhOutroAtributo;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public WhereHQL(String atributo, Object valor, String operadorLogico)
/*  36:    */   {
/*  37: 40 */     this.atributo = atributo;
/*  38: 41 */     this.valor = valor;
/*  39: 42 */     this.operadorLogico = operadorLogico;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public WhereHQL(String operadorLogico, Object subSelect)
/*  43:    */   {
/*  44: 46 */     this.subSelect = subSelect.toString();
/*  45: 47 */     this.operadorLogico = operadorLogico;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public WhereHQL(String atributo, String operadorLogico)
/*  49:    */   {
/*  50: 51 */     this.atributo = atributo;
/*  51: 52 */     this.operadorLogico = operadorLogico;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public String gerarHql(Integer id)
/*  55:    */   {
/*  56: 56 */     this.id = id;
/*  57: 57 */     String retorno = "";
/*  58: 58 */     if (this.operadorLogico == null) {
/*  59: 59 */       retorno = this.atributo;
/*  60: 60 */     } else if (((this.operadorLogico.equals(IN)) || (this.operadorLogico.equals(NOT_IN))) && (!Consulta.class.equals(this.valor.getClass()))) {
/*  61: 61 */       retorno = this.atributo + " " + this.operadorLogico + " (:condicao" + id + ") ";
/*  62: 62 */     } else if (((this.operadorLogico.equals(IN)) || (this.operadorLogico.equals(NOT_IN))) && (Consulta.class.equals(this.valor.getClass()))) {
/*  63: 63 */       retorno = this.atributo + " " + this.operadorLogico + " (" + ((Consulta)this.valor).getHql(id) + ") ";
/*  64: 64 */     } else if ((this.operadorLogico.equals(IS_NULL)) || (this.operadorLogico.equals(IS_NOT_NULL))) {
/*  65: 65 */       retorno = this.atributo + " " + this.operadorLogico + " ";
/*  66: 66 */     } else if (this.valorEhOutroAtributo.booleanValue())
/*  67:    */     {
/*  68: 67 */       if (isValorConsulta().booleanValue())
/*  69:    */       {
/*  70: 68 */         if ((this.operadorLogico.equals(EXISTS)) || (this.operadorLogico.equals(NOT_EXISTS))) {
/*  71: 69 */           retorno = this.operadorLogico + " (" + ((Consulta)this.valor).getHql(id) + ") ";
/*  72:    */         } else {
/*  73: 71 */           retorno = this.atributo + " " + this.operadorLogico + " (" + ((Consulta)this.valor).getHql(id) + ") ";
/*  74:    */         }
/*  75:    */       }
/*  76:    */       else {
/*  77: 74 */         retorno = this.atributo + " " + this.operadorLogico + " " + this.valor.toString() + " ";
/*  78:    */       }
/*  79:    */     }
/*  80:    */     else {
/*  81: 77 */       retorno = this.atributo + " " + this.operadorLogico + " :condicao" + id + " ";
/*  82:    */     }
/*  83: 79 */     return retorno;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public String getIdentificadorSet()
/*  87:    */   {
/*  88: 83 */     return "condicao" + this.id;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public Object getValor()
/*  92:    */   {
/*  93: 87 */     return this.valor;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public boolean existeValor()
/*  97:    */   {
/*  98: 91 */     if (this.operadorLogico == null) {
/*  99: 92 */       return false;
/* 100:    */     }
/* 101: 94 */     return (!this.operadorLogico.equals(IS_NULL)) && (!this.operadorLogico.equals(IS_NOT_NULL)) && (!this.operadorLogico.equals(EXISTS)) && (!this.operadorLogico.equals(NOT_EXISTS)) && (!this.valorEhOutroAtributo.booleanValue());
/* 102:    */   }
/* 103:    */   
/* 104:    */   public Boolean isValorConsulta()
/* 105:    */   {
/* 106: 99 */     return Boolean.valueOf(this.valor instanceof Consulta);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public Consulta getValorConsulta()
/* 110:    */   {
/* 111:103 */     return (Consulta)this.valor;
/* 112:    */   }
/* 113:    */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.hibernate.WhereHQL
 * JD-Core Version:    0.7.0.1
 */