package br.prosaude.arquitetura.core;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashGenerator {

	public static String generateMD5Hash(String string) {
		MessageDigest m = null;
		String senha = null;

		try {
			m = MessageDigest.getInstance("MD5");
			m.update(string.getBytes(), 0, string.length());
			senha = new BigInteger(1, m.digest()).toString(16).toString();
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e.getMessage(), e);
		}

		return senha;
	}

	public static String generateSHA1Hash(String string) {
		MessageDigest m = null;
		String senha = null;

		System.out.println("string " + string);

		try {
			m = MessageDigest.getInstance("SHA-1");
			m.update(string.getBytes(), 0, string.length());
			senha = new BigInteger(1, m.digest()).toString(16).toString();
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e.getMessage(), e);
		}

		return senha;
	}
	
	public double generateRandom(){
		return Math.random();
	}
	
	

	/*
	 * public static void main(String[] args) {
	 * System.out.println(generateSHA1Hash("admin"));
	 * System.out.println(generateMD5Hash("tutor"));
	 * System.out.println(generateMD5Hash("conte"));
	 * System.out.println(generateMD5Hash("aluno"));
	 * System.out.println(generateMD5Hash("coord")); }
	 */
}
