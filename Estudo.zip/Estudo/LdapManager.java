package com.nexxera.pds.utility;

import java.util.ArrayList;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;

import com.nexxera.ldap.Critical;
import com.nexxera.ldap.NexxLDAPException;
import com.nexxera.ldap.bean.UserBean;
import com.nexxera.ldap.business.bo.LDAPPersistence;

public class LdapManager {

	private Properties props;
	
	public LdapManager() {
		props = new Properties();
	}
	
	public LDAPPersistence getLdapPersistenceRemote() throws NexxLDAPException {
	    LDAPPersistence ldapPersistenceRemote = null;
	    
	    //Solicitar a Cria��o da Credencial de Aplica��o
	    props.put(Context.SECURITY_PRINCIPAL,      ResourceProperties.getPropertie(ResourceProperties.SECURITY_PRINCIPAL));
	    props.put(Context.SECURITY_CREDENTIALS,    ResourceProperties.getPropertie(ResourceProperties.SECURITY_CREDENTIALS));
	    props.put(Context.INITIAL_CONTEXT_FACTORY, ResourceProperties.getPropertie(ResourceProperties.INITIAL_CONTEXT_FACTORY));
	    props.put(Context.PROVIDER_URL,            ResourceProperties.getPropertie(ResourceProperties.PROVIDER_URL));

	    try {
	    	Context contextLdap = new InitialContext(props);
	    	ldapPersistenceRemote = (LDAPPersistence) contextLdap.lookup("nexxldap3/LDAPPersistence/remote");
	    } catch (Exception e) {
	    	e.printStackTrace();
	    	throw new NexxLDAPException(new Critical());
	    }

	    return ldapPersistenceRemote;
	}
	
	public void adicionarUsuario(UserBean user) throws NexxLDAPException {
		user.setUid(user.getUid());
	    this.getLdapPersistenceRemote().createUserToOwnGroup(user);
	}
	
	public void adicionarUsuarioGrupo(UserBean user) throws NexxLDAPException {
		user.setUid(removerDominio(user.getUid()));
		this.getLdapPersistenceRemote().addUserToOwnGroup(user);
	}
	   
	public void removerUsuario(String uidEmail) throws NexxLDAPException {
		this.getLdapPersistenceRemote().removeUser(removerDominio(uidEmail));
	}
   
	public UserBean buscarUsuario(String uidEmail) throws NexxLDAPException {	
		return this.getLdapPersistenceRemote().findUser(removerDominio(uidEmail));
	}
	
	public boolean usuarioExisteLdap(String uidEmail) throws NexxLDAPException {
		if(this.getLdapPersistenceRemote().findUser(removerDominio(uidEmail)) != null)
			return true;
		return false;
	}

	public void alterarSenhaUsuario(String uidEmail, String newPassword) throws NexxLDAPException {
		this.getLdapPersistenceRemote().overwriteUserPassword(removerDominio(uidEmail), newPassword);
	}
	
	public void alterarSenhaUsuario(String uidEmail,String oldPassword, String newPassword) throws NexxLDAPException {
		this.getLdapPersistenceRemote().changeUserPassword(removerDominio(uidEmail), oldPassword, newPassword);
	}
	
//	@Deprecated
//	public void alterarUsuario(UserBean userBean) throws NexxLDAPException {
//		this.getLdapPersistenceRemote().changeUser(userBean);
//	}
	
	public static String removerDominio(String uidEmail){
		String novoUidEmail = "";
		
		ArrayList<String> listaDominios = new ArrayList<String>();
			listaDominios.add("@nexxera.com");
			listaDominios.add("@techpeople.com.br");

		for (String dominio : listaDominios) {
			novoUidEmail = uidEmail.replace(dominio, "");
			uidEmail = novoUidEmail;
		}
		return novoUidEmail;
	}
	
}