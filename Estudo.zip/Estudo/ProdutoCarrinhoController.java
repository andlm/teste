public class ProdutoCarrinhoController {
    private final String PLANTA_TRES_MARIAS_TEXT = 'Três Marias';
    private final String PLANTA_JUIZ_DE_FORA_TEXT = 'Juiz de Fora';
    private final String PLANTA_TRES_MARIAS = '7205';
    private final String PLANTA_JUIZ_DE_FORA = '7351';
    private static String ORG_DE_VENDAS_NEXA = '7500';
    private static String CANAL_DE_DISTRIBUICAO = '71';
    private static String SETOR_DE_ATIVIDADE = '71';

    public String nomeConta {get; set;}
    public String codigoCliente {get; set;}
    public String limiteCredito {get; set;}
    public String mostrarOpcoesCreditoflag {get; set;}
    public String disponibilidadeCredito {get; set;}
    public String setor {get; set;}
    public String telefone {get; set;}
    public String endecoentrega {get; set;}
    public String codigoClienteEmissorSAP {get; set;}
    public String codigoClienteRecebedorSAP {get; set;}

    public Messages_pt_BR message {get; set;}
    public String usuarioNome {get; set;}
    private Set<Id> produtosSet;
    public List<PricebookEntry> produtos {get; set;}
    public List<ProdutoPrecoWrapper> produtosPrecosWrapper {get; set;}
    public Map<String, Condicoes_de_pagamento__c> condsPagsMap {get; set;}
    public Decimal valorTotalPedido {get; set;}
    public String valorTotalPedidoSTR {get; set;}
    public String contatoSelecionadoBackId {get; set;}
    public Id usuarioId {get; set;}
    public Id contaId;
    public String codigoClienteSAP {get; set;}
    public String contaNome;
    public String condicaoPagamentoConta;
    public String numeroPedidoManual {get; set;}
    public Date dataDesejo {get; set;}
    public Account contaEmissor;
    public Account contaRecebedor;
    public String contaSelecionadaId {get; set;}

    public List<Condicoes_de_pagamento__c> condicoesPagamentosSelecionadas {get; set;}

    public class ProdutoPrecoWrapperParseJson {
        private final String PLANTA_TRES_MARIAS = '7205';
        private final String JUIZ_DE_FORA = '7351';
        public PricebookEntry produto;
        public String img;
        public Decimal quantidade;
        public Decimal Valor_X_Quantidade;
        public String valorDoFrete;
        public Decimal valorUnitario;
        public String valorTotalItem;
        public String plantaItem;
        
        public ProdutoPrecoWrapperParseJson(ProdutoPrecoWrapper p) { 
            produto = p.produto;
            img = p.img;
            quantidade = p.quantidade;
            Valor_X_Quantidade = p.Valor_X_Quantidade;
            valorDoFrete = p.valorDoFrete;
            valorUnitario = p.valorUnitario;
            valorTotalItem = p.valorTotalItem;
            plantaItem = p.condicoesPagsProduto.Codigo_da_pagamento__c;
        }
    }

    public class ProdutoPrecoWrapper {
        private final String PLANTA_TRES_MARIAS = '7205';
        private final String JUIZ_DE_FORA = '7351';
        public PricebookEntry produto {get; set;}
        public String img {get; set;}
        public Decimal quantidade {get; set;}
        public Decimal Valor_X_Quantidade {get; set;}
        public String valorTotalItemSTR {get; set;}
        public String valorDoFrete {get; set;}
        public Decimal valorUnitario {get; set;}
        public String valorUnitarioSTR {get; set;}
        public String valorTotalItem {get; set;}
        public List<SelectOption> options {get; set;}
        public String plantaItem {get; set;}
        public Condicoes_de_pagamento__c condicoesPagsProduto {get; set;}
        
        public ProdutoPrecoWrapper(PricebookEntry p, Condicoes_de_pagamento__c condsPagsProd) { 
            condicoesPagsProduto = condsPagsProd;
            produto = p;
            img = p.Product2.Product_Image__c.substringBetween('src=\"','\"');
            Decimal preco = 0.0;
            valorTotalItem = '0';
            valorDoFrete = '0';

            // >>> Cliente redução 
            plantaItem = p.Planta_selecionada__c == PLANTA_TRES_MARIAS ? 'Três Marias' : 'Juiz de Fora';

			if (condsPagsProd.Preco_tonelada_reducao__c > 0.0){
				preco = condsPagsProd.Preco_tonelada_reducao__c;
			}else{
                preco = p.Planta_selecionada__c == PLANTA_TRES_MARIAS ? condsPagsProd.Preco_Tonelada_TM__c : condsPagsProd.Preco_Tonelada_JF__c;
			}
            
            valorUnitario = preco.setscale(2);
            
            valorUnitarioSTR = FormatValues.handler(preco, 2);

            if('FOB' != condsPagsProd.Incoterms__c) {
                Regras_de_Volume_CIF__c regraVolume = [SELECT Id, Codigo_do_Material_SAP__c, Descricao_Material__c, Peso_Amarrado_Minimo_TON__c, Fabrica__c, 
                                                        Volume_1__c, Volume_2__c, Volume_3__c, Volume_4__c, Volume_5__c, Volume_6__c, Volume_7__c,
                                                        Volume_8__c, Volume_9__c, Volume_10__c, Volume_11__c, Volume_12__c, Volume_13__c, Volume_14__c, Volume_15__c,
                                                        Volume_16__c, Volume_17__c, Volume_18__c, Volume_19__c, Volume_20__c
                                                        FROM Regras_de_Volume_CIF__c where Codigo_do_Material_SAP__c = :p.ProductCode];
                options = new List<SelectOption>();
                options.clear();

                quantidade = regraVolume.Volume_1__c;

                if(null != regraVolume.Volume_1__c){
                    quantidade = regraVolume.Volume_1__c;
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_1__c), String.ValueOf(regraVolume.Volume_1__c)));
                }
                if(null != regraVolume.Volume_2__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_2__c), String.ValueOf(regraVolume.Volume_2__c)));
                }
                if(null != regraVolume.Volume_3__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_3__c), String.ValueOf(regraVolume.Volume_3__c)));
                }
                if(null != regraVolume.Volume_4__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_4__c), String.ValueOf(regraVolume.Volume_4__c)));
                }
                if(null != regraVolume.Volume_5__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_5__c), String.ValueOf(regraVolume.Volume_5__c)));
                }
                if(null != regraVolume.Volume_6__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_6__c), String.ValueOf(regraVolume.Volume_6__c)));
                }
                if(null != regraVolume.Volume_7__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_7__c), String.ValueOf(regraVolume.Volume_7__c)));
                }
                if(null != regraVolume.Volume_8__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_8__c), String.ValueOf(regraVolume.Volume_8__c)));
                }
                if(null != regraVolume.Volume_9__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_9__c), String.ValueOf(regraVolume.Volume_9__c)));
                }
                if(null != regraVolume.Volume_10__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_10__c), String.ValueOf(regraVolume.Volume_10__c)));
                }
                if(null != regraVolume.Volume_11__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_11__c), String.ValueOf(regraVolume.Volume_11__c)));
                }
                if(null != regraVolume.Volume_12__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_12__c), String.ValueOf(regraVolume.Volume_12__c)));
                }
                if(null != regraVolume.Volume_13__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_13__c), String.ValueOf(regraVolume.Volume_13__c)));
                }
                if(null != regraVolume.Volume_14__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_14__c), String.ValueOf(regraVolume.Volume_14__c)));
                }
                if(null != regraVolume.Volume_15__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_15__c), String.ValueOf(regraVolume.Volume_15__c)));
                }
                if(null != regraVolume.Volume_16__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_16__c), String.ValueOf(regraVolume.Volume_16__c)));
                }
                if(null != regraVolume.Volume_17__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_17__c), String.ValueOf(regraVolume.Volume_17__c)));
                }
                if(null != regraVolume.Volume_18__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_18__c), String.ValueOf(regraVolume.Volume_18__c)));
                }
                if(null != regraVolume.Volume_19__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_19__c), String.ValueOf(regraVolume.Volume_19__c)));
                }
                if(null != regraVolume.Volume_20__c){
                    options.add(new SelectOption(String.ValueOf(regraVolume.Volume_20__c), String.ValueOf(regraVolume.Volume_20__c)));
                }
            }

            if('FOB' == condsPagsProd.Incoterms__c) {
                options = new List<SelectOption>();
                options.clear();

                Decimal cont = 0;

                if(p.Volume_Minimo__c == null || p.Volume_Minimo__c < 1){
                    options.add(new SelectOption('0', '0'));
                    p.Volume_Minimo__c = 1.0;
                    return;
                }

                quantidade = p.Volume_Minimo__c;

                while(cont < 200) {
                    options.add(new SelectOption(String.valueOf(cont), String.valueOf(cont)));
                    cont = cont + p.Volume_Minimo__c;
                }
            }

            Valor_X_Quantidade = quantidade * valorUnitario;
            valorTotalItemSTR = FormatValues.handler(Valor_X_Quantidade, 2);
        }
    }

	public ProdutoCarrinhoController() { 
        String produtosIds = ApexPages.currentPage().getParameters().get('produtosIds');
        List<Id> produtosList = produtosIds.split('-');
        this.produtosSet = new Set<Id>(produtosList);

        this.contaSelecionadaId = ApexPages.currentPage().getParameters().get('contaSelecionadaId');
        this.contatoSelecionadoBackId = ApexPages.currentPage().getParameters().get('contatoSelecionadoBackId');
        String idClienteEmissor = ApexPages.currentPage().getParameters().get('codigoClienteEmissorSAP');
        String idClienteRecebedor = ApexPages.currentPage().getParameters().get('codigoClienteRecebedorSAP');

        String produtosDaCondPagSelecionados = ApexPages.currentPage().getParameters().get('produtosDaCondPagSelecionados');

        this.condicoesPagamentosSelecionadas = (List<Condicoes_de_pagamento__c>)System.JSON.deserialize(produtosDaCondPagSelecionados, List<Condicoes_de_pagamento__c>.class);
        System.debug('condicoesPagamentosSelecionadas.......: ' + condicoesPagamentosSelecionadas);
		
        System.debug('idClienteEmissor='+idClienteEmissor);
        System.debug('idClienteRecebedor='+idClienteRecebedor);
        this.contaEmissor = [select Id, Codigo_do_Cliente_KNA1_KUNNR__c, Incoterms__c from Account where id = :idClienteEmissor Limit 1];
        this.contaRecebedor = [select Id, Codigo_do_Cliente_KNA1_KUNNR__c, Incoterms__c from Account where id = :idClienteRecebedor Limit 1];
    }

    public void init() {
        this.usuarioId = UserInfo.getUserId();

        User usuarioContato = contatoUsuario(this.usuarioId);
        Account contaContato = null;

        this.dataDesejo = Date.today().addDays(2);

        try {
            if('null' == this.contatoSelecionadoBackId) {
                //Endereço de Faturamento
                String idClienteEmissor = ApexPages.currentPage().getParameters().get('codigoClienteEmissorSAP');
                contaContato = buscarContaBackoffice(idClienteEmissor);
                setarValoresCamposConta(contaContato);
            }else{
                contaContato = buscarContaContato(this.contatoSelecionadoBackId);
                setarValoresCamposConta(contaContato);
            }
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
        }

        initTextsView();

        this.codigoClienteSAP = contaContato.Codigo_do_Cliente_KNA1_KUNNR__c;
        this.valorTotalPedido = 0.00;
        this.valorTotalPedidoSTR = '0,00';
        this.contaId = contaContato.Id;
        this.contaNome = contaContato.Name;
        System.debug('this.produtosSet.........: ' + this.produtosSet);
        this.produtos = buscarProdutosPrecos(this.produtosSet);
        this.condicaoPagamentoConta = contaContato.Condicao_de_Pagamento__c;

        this.condsPagsMap = criarProdutosSelecionadosMap();

        formatarProdutoPreco(this.produtos, condsPagsMap);
    }

    private Map<String, Condicoes_de_pagamento__c> criarProdutosSelecionadosMap() {
        Map<String, Condicoes_de_pagamento__c> condsPagsMap = new Map<String, Condicoes_de_pagamento__c>();

        for(Condicoes_de_pagamento__c c : this.condicoesPagamentosSelecionadas) {
            condsPagsMap.put(c.Codigo_do_Material__c, c);
        }

        return condsPagsMap;
    }

    public List<SelectOption> getEnderecoSelect() {
        List<SelectOption> options = new List<SelectOption>();
        options.clear();

        List<Account> contaPai = getContaPai(this.contaId);
        if(null == contaPai || 1 > contaPai.size()) {
            options.add(new SelectOption('', 'Nenhuma outra empresa com endereço'));
            return null;
        }

        List<Account> contasFilhas = getContasFilhas(contaPai[0].Id);

        if(null == contasFilhas || 1 > contasFilhas.size()) {
            options.add(new SelectOption('', 'Nenhuma outra empresa com endereço'));
            return null;
        }

        options.add(new SelectOption(this.contaId, this.contaNome + ' - ' + this.endecoentrega));

        for(Account c : contasFilhas) {
            String endecoEntregaFilhas = c.ShippingStreet + ', ' + c.ShippingCity + ' - ' + c.ShippingState 
                                + ', Cep. ' + c.ShippingPostalCode + ' - ' + c.ShippingCountry;
            options.add(new SelectOption(String.isBlank(c.Codigo_do_Cliente_KNA1_KUNNR__c) ? '00000' : c.Codigo_do_Cliente_KNA1_KUNNR__c, c.Name + ' - ' + endecoEntregaFilhas));
        }
         
        return options;
    }

    public void initTextsView() {
		this.message = new Messages_pt_BR();
	}

    public PageReference voltarListaProdutos() {
        PageReference redirectPage = Page.ProdutoCliente;
        redirectPage.setRedirect(true);
        
        String idClienteEmissor = ApexPages.currentPage().getParameters().get('codigoClienteEmissorSAP');
		String idClienteRecebedor = ApexPages.currentPage().getParameters().get('codigoClienteRecebedorSAP');

        redirectPage.getParameters().put('contaSelecionadaId', this.contaSelecionadaId);
        redirectPage.getParameters().put('contatoSelecionadoBackId', this.contatoSelecionadoBackId);
        redirectPage.getParameters().put('codigoClienteEmissorSAP', idClienteEmissor);
        redirectPage.getParameters().put('codigoClienteRecebedorSAP', idClienteRecebedor);
        
        return redirectPage;
    }

    public PageReference concluirPedido() {
        Id cdOrdem = null;

        WS_ConsultaDisponibilidadeProduto.DT_SALESFORCE_ResponseConsultaDisponibilidadeOrdemDeVenda produtosConsultados = consultarDisponibilidadeProdutoSAP();

        Boolean isDataDesejoValida = true;
        String mensagemSAP = String.isBlank(produtosConsultados.Mensagem) ? '' : produtosConsultados.Mensagem; 

        for(WS_ConsultaDisponibilidadeProduto.Registros_element_response p : produtosConsultados.Registros) {
            if(p.Disponivel == 'false') {
                System.debug('Error....: ' + p.Mensagem);
                isDataDesejoValida = false; 
            } 
        }
        
        if(!isDataDesejoValida){
            ApexPages.addmessage(new ApexPages.message(ApexPages.severity.WARNING, mensagemSAP));
            return null;
        }

        Order ordemCriada = criarPedido(this.produtos[0].Pricebook2Id, this.contaId); 
        
        adicionarProdutoPedido(ordemCriada);

        return new ApexPages.StandardController(ordemCriada).view();
    }

    public WS_ConsultaDisponibilidadeProduto.DT_SALESFORCE_ResponseConsultaDisponibilidadeOrdemDeVenda consultarDisponibilidadeProdutoSAP() {
        WS_ConsultaDisponibilidadeProduto.HTTPS_Port port = new WS_ConsultaDisponibilidadeProduto.HTTPS_Port();
        
        List<WS_ConsultaDisponibilidadeProduto.Registros_element> registros = new List<WS_ConsultaDisponibilidadeProduto.Registros_element>(); 

        for(ProdutoPrecoWrapper p : this.produtosPrecosWrapper) {
            WS_ConsultaDisponibilidadeProduto.Registros_element registro = new WS_ConsultaDisponibilidadeProduto.Registros_element();
            registro.NumMaterial = p.produto.ProductCode;
            registro.UnidadePeso = 'TO';
            registro.VolumeItem = String.valueOf(p.quantidade);
            registro.Planta = p.plantaItem == 'Três Marias' ? PLANTA_TRES_MARIAS : PLANTA_JUIZ_DE_FORA;
            registro.DataDesejo = DateUtil.parseToDD_MM_AA(this.dataDesejo);

            registros.add(registro);
        } 

        WS_ConsultaDisponibilidadeProduto.DT_SALESFORCE_ResponseConsultaDisponibilidadeOrdemDeVenda registrosResponse = new WS_ConsultaDisponibilidadeProduto.DT_SALESFORCE_ResponseConsultaDisponibilidadeOrdemDeVenda();
        registrosResponse = port.SI_SALESFORCE_ConsultaDispOrdemDeVenda_out_sync(registros);

        return registrosResponse;
    }

    private void calcularLeadTime(Date dataDesejo){
        
    }

    public Order criarPedido(Id cdProduto, Id cdConta) {
        
        Order pedido = new Order();
        System.debug('cdProduto........: ' +cdProduto);
        pedido.Pricebook2Id = cdProduto; //Catálogo de preços
        
        //Endereço de Faturamento
        String idClienteEmissor = ApexPages.currentPage().getParameters().get('codigoClienteEmissorSAP');
        
        Account accClienteEmissor = buscarContaFaturamento(idClienteEmissor);
        if (accClienteEmissor!=null){
        	pedido.AccountId = accClienteEmissor.Id;
        }else{
            pedido.AccountId = cdConta;
        }
        
        pedido.Valor_total_do_pedido__c = calcularValorTotalPedido(produtosPrecosWrapper);
        pedido.EffectiveDate = Date.today();
        pedido.Status = 'Em processamento';
        
        if (!String.isBlank(this.numeroPedidoManual))
			pedido.Nr_do_pedido_Cliente__c = this.numeroPedidoManual;
        
        System.debug('idClienteEmissor='+idClienteEmissor);
        if (!String.isBlank(idClienteEmissor))
        	copiarEnderecoFaturamento(pedido,idClienteEmissor);
		
		String idClienteRecebedor = ApexPages.currentPage().getParameters().get('codigoClienteRecebedorSAP');
        
        System.debug('idClienteRecebedor='+idClienteRecebedor);
        if (!String.isBlank(idClienteRecebedor))
			copiarEnderecoEntrega(pedido,idClienteRecebedor);
        
        insert pedido;
        
        this.numeroPedidoManual = String.isBlank(this.numeroPedidoManual) ? pedido.OrderNumber : pedido.Nr_do_pedido_Cliente__c;
        
        return pedido;
    }
    
    private Account buscarContaFaturamento(String idClienteEmissor) {
        Try{
            Account conta= [Select id, Name From Account where id = :idClienteEmissor  Limit 1];
            return conta;
        } catch(QueryException e) {
            System.debug('buscarContaFaturamento::ERROR.......: ' + e.getMessage());
            return null;
        }
    }
    
    private void copiarEnderecoFaturamento(Order pedido, String idClienteEmissor) {
        
		Account acc = [Select id, Name, Codigo_do_Cliente_KNA1_KUNNR__c, BillingPostalCode, BillingCountry, 
							  BillingState, BillingCity, BillingStreet 
                        From Account where id = :idClienteEmissor  Limit 1];
        
        if(acc.BillingPostalCode == null || String.isBlank(acc.BillingPostalCode)) return;
        
        pedido.Codigo_do_Cliente_de_faturamento__c = acc.Codigo_do_Cliente_KNA1_KUNNR__c;
        pedido.Empresa_de_faturamento__c = acc.Id;   
        pedido.BillingStreet = acc.BillingStreet;
		pedido.BillingCity = acc.BillingCity;
		pedido.BillingState = acc.BillingState;
		pedido.BillingPostalCode = acc.BillingPostalCode;
        pedido.BillingCountry = acc.BillingCountry;
		
    }
	
	private void copiarEnderecoEntrega(Order pedido, String idClienteRecebedor) {
        Account acc = [Select id, Name, Codigo_do_Cliente_KNA1_KUNNR__c, ShippingPostalCode, ShippingCountry, 
							  ShippingState, ShippingCity, ShippingStreet 
                       From Account where id = :idClienteRecebedor  Limit 1];
        
        if(acc.ShippingPostalCode == null || String.isBlank(acc.ShippingPostalCode)) return;
        
        pedido.Codigo_do_cliente_de_entrega__c = acc.Codigo_do_Cliente_KNA1_KUNNR__c;
        pedido.Empresa_de_entrega__c = acc.Id;   
		pedido.ShippingStreet = acc.ShippingStreet;
		pedido.ShippingCity = acc.ShippingCity;
		pedido.ShippingState = acc.ShippingState;
		pedido.ShippingPostalCode = acc.ShippingPostalCode;
        pedido.ShippingCountry = acc.ShippingCountry;
    }
 
    public void adicionarProdutoPedido(Order ordemCriada) {
        List<OrderItem> produtosPedido = new List<OrderItem>();
        
        for(ProdutoPrecoWrapper p : this.produtosPrecosWrapper) {
            Condicoes_de_pagamento__c condPag = this.condsPagsMap.get(p.produto.ProductCode);

            OrderItem produto = new OrderItem();
            produto.OrderId = ordemCriada.Id;
            produto.PricebookEntryId = p.produto.Id; //Entrada da Tabela de Preços

            if(p.plantaItem  == PLANTA_TRES_MARIAS_TEXT) {
                produto.Planta__c = PLANTA_TRES_MARIAS_TEXT;
                produto.UnitPrice = condPag.Preco_Tonelada_TM__c;
                produto.Frete_do_produto__c = condPag.FreteTM__c;
                produto.ICMS_Taxa__c = condPag.ICMS_Taxa_TM__c;
                produto.Preco_Tonelada__c = condPag.Preco_tonelada_reducao__c > 0.0 ? condPag.Preco_tonelada_reducao__c : condPag.Preco_Tonelada_TM__c;
            } else {
                produto.Planta__c = PLANTA_JUIZ_DE_FORA_TEXT;
                produto.UnitPrice = condPag.Preco_Tonelada_JF__c;
                produto.Frete_do_produto__c = condPag.Frete_JF__c;
                produto.ICMS_Taxa__c = condPag.ICMS_Taxa_JF__c;
                produto.Preco_Tonelada__c = condPag.Preco_tonelada_reducao__c > 0.0 ? condPag.Preco_tonelada_reducao__c : condPag.Preco_Tonelada_JF__c;

            }

            produto.Codigo_da_pagamento__c = condPag.Codigo_da_pagamento__c + ' - ' + condPag.Name;
            produto.Codigo_Material__c = p.produto.ProductCode;
            produto.Quantity = p.quantidade;
            produto.Dolar__c = condPag.Dolar__c;
            produto.Incoterms__c = condPag.Incoterms__c;
            produto.LME__c = condPag.LME__c;
            produto.Premio_USD__c = condPag.Premio_USD__c;
            produto.QP__c = condPag.QP__c;
            produto.Taxa_Financeira__c = condPag.Taxa_Financeira__c;

            produtosPedido.add(produto);
        }

        Database.SaveResult[] srList = Database.insert(produtosPedido, false);
        Boolean status;
        for (Database.SaveResult sr : srList) {
            if (sr.isSuccess()) {
                System.debug('Successfully inserted account. Account ID: ' + sr.getId());
            } else {
                for(Database.Error err : sr.getErrors()) {
                    System.debug('The following error has occurred.');                    
                    System.debug(err.getStatusCode() + ': ' + err.getMessage());
                    System.debug('Account fields that affected this error: ' + err.getFields());
                }
            }
        }

        List<ProdutoPrecoWrapperParseJson> listPw = new List<ProdutoPrecoWrapperParseJson>();
        for(ProdutoPrecoWrapper p : produtosPrecosWrapper) {
            listPw.add(new ProdutoPrecoWrapperParseJson(p));
        }

        String produtosJSON = JSON.serialize(listPw);
        
        Order ordem = [select OrderNumber, Nr_do_pedido_Cliente__c from Order where Id = :ordemCriada.Id];
        
        this.numeroPedidoManual = String.isBlank(this.numeroPedidoManual) ? ordem.OrderNumber : ordem.Nr_do_pedido_Cliente__c;
        
        criraOrdemVenda_SAP(ordemCriada.Id, this.contaEmissor.Codigo_do_Cliente_KNA1_KUNNR__c, this.contaRecebedor.Codigo_do_Cliente_KNA1_KUNNR__c, produtosJSON, this.numeroPedidoManual, this.contaRecebedor.Incoterms__c, this.dataDesejo, this.condicaoPagamentoConta);
    }

    public void removerItemListaCorrinho() {
        String produtoId = Apexpages.currentPage().getParameters().get('itemRemover');
        Id itemRemoverId = produtoId;

        for(Integer i = 0; i < produtosPrecosWrapper.size(); i++) {
            if(produtosPrecosWrapper[i].produto.Id == itemRemoverId) {
                recalcularValorTotalPedido(produtosPrecosWrapper, produtosPrecosWrapper[i]);
                produtosPrecosWrapper.remove(i);
                return;
            }
        }
    }

    @Future(callout=true)
    private static void criraOrdemVenda_SAP(Id cdOrdemCriada, String codigoClienteEmissorSAP, String codigoClienteRecebedorSAP, String produtosJSON, String numeroPedidoManual, String incoterms, Date dataDeDesejo, String condicaoPagamentoConta) {
        WS_OrdemVenda.HTTPS_Port port = new WS_OrdemVenda.HTTPS_Port();

        List<WS_OrdemVenda.DT_SALESFORCE_CriaOrdemDeVenda_2> listCriaOrdemDeVenda_2 = new List<WS_OrdemVenda.DT_SALESFORCE_CriaOrdemDeVenda_2>();
        WS_OrdemVenda.DT_SALESFORCE_CriaOrdemDeVenda_2 criaOrdemDeVenda_2 = new WS_OrdemVenda.DT_SALESFORCE_CriaOrdemDeVenda_2();


        List<WS_OrdemVenda.Registros_element> listRegistro = setarProdutosOrdemVenda(produtosJSON, codigoClienteEmissorSAP, codigoClienteRecebedorSAP, numeroPedidoManual, incoterms, dataDeDesejo, condicaoPagamentoConta);

        Order ordem = new Order();
        ordem.Id = cdOrdemCriada;
        
        try{
            List<WS_OrdemVenda.Registros_element_response> registrosElementResponse = port.SI_SALESFORCE_CriaOrdemDeVenda_out_sync(listRegistro);
            
            Map<String, String> mapDocs = new Map<String, String>();

            String msgErroSAP = '';

            
            for(WS_OrdemVenda.Registros_element_response r : registrosElementResponse) {
                msgErroSAP = String.isBlank(r.DocVendas) ? r.Cod_Erro[0].Erro : 'Programado';

                if (!String.isBlank(r.DocVendas)){
                	mapDocs.put(r.DocVendas, r.DocVendas);
                }
            }

            for(String s : mapDocs.values()) {
                ordem.Documento_de_Venda__c = String.isBlank(ordem.Documento_de_Venda__c) ? s : s + '; ' + ordem.Documento_de_Venda__c;
            }
            
            Order ordemAux = [select OrderNumber, Nr_do_pedido_Cliente__c from Order where Id = :ordem.Id];
            if (ordemAux!=null)
                if (String.isBlank(ordemAux.Nr_do_pedido_Cliente__c))
            		ordem.Nr_do_pedido_Cliente__c = ordemAux.OrderNumber;
            
            ordem.Status = String.isBlank(ordem.Documento_de_Venda__c) ? 'Em análise' : 'Aprovado';
                
            ordem.Situacao_do_pedido__c = msgErroSAP;
        } catch(CalloutException ex) {
            System.debug('Erro...: ' + ex);
            ordem.Status = 'Em análise';
        }
			
        update ordem;
    }

    private static void setarClienteOrdemVenda(WS_OrdemVenda.Registros_element registro, String codigoClienteEmissorSAP, String codigoClienteRecebedorSAP, String numeroPedidoManual, String incoterms) {
        
        if (codigoClienteEmissorSAP == codigoClienteRecebedorSAP)
        	registro.TipoDocVendas = 'ZNOR';
        else{
        	registro.TipoDocVendas = 'ZFCO';
        }
        registro.OrgVendas = ORG_DE_VENDAS_NEXA;
        registro.CanalDistribuicao = CANAL_DE_DISTRIBUICAO;
        registro.SetorAtividade = SETOR_DE_ATIVIDADE;
        registro.CodCliente = codigoClienteEmissorSAP; 
        registro.Recebedor = codigoClienteRecebedorSAP;
        registro.NrPedido =  numeroPedidoManual; 
        registro.Incoterms = String.isBlank(incoterms) ? 'CIF' : incoterms;
    }

    private static List<WS_OrdemVenda.Registros_element> setarProdutosOrdemVenda(String produtosJSON, String codigoClienteEmissorSAP, String codigoClienteRecebedorSAP, String numeroPedidoManual, String incoterms, Date dataDeDesejo, String condicaoPagamentoConta) {
        List<WS_OrdemVenda.Registros_element> listRegistro = new List<WS_OrdemVenda.Registros_element>();
        List<ProdutoPrecoWrapper> produtoWrapper = (List<ProdutoPrecoWrapper>)System.JSON.deserialize(produtosJSON, List<ProdutoPrecoWrapper>.class);
        WS_OrdemVenda.Registros_element registro = null;

        for(Integer i = 0; i < produtoWrapper.size(); i++) {
            registro = new WS_OrdemVenda.Registros_element();
            setarClienteOrdemVenda(registro, codigoClienteEmissorSAP, codigoClienteRecebedorSAP, numeroPedidoManual, incoterms);

            registro.ItemDocVendas = String.valueOf(i+1);
            registro.NumMaterial = produtoWrapper[i].produto.ProductCode;

            Decimal pesoLiq = produtoWrapper[i].produto.Product2.Peso_liquido_do_item__c == null ? 1.0 : produtoWrapper[i].produto.Product2.Peso_liquido_do_item__c;
            registro.PesoLiquidoItem = String.valueOf(produtoWrapper[i].quantidade * pesoLiq);
            registro.UnidadePeso = 'TO';//produtoWrapper[i].produto.Product2.QuantityUnitOfMeasure;
            registro.VolumeItem = String.valueOf(produtoWrapper[i].quantidade);
            registro.Planta = produtoWrapper[i].produto.Planta_selecionada__c;
            registro.DataPreco = DateUtil.getDataHoje_DD_MM_AA();
            registro.DataDesejo = DateUtil.parseToDD_MM_AA(dataDeDesejo);
            registro.CondPagamento = produtoWrapper[i].plantaItem;

            listRegistro.add(registro);
        }

        return listRegistro; 
    }

    private Decimal calcularValorTotalPedido(List<ProdutoPrecoWrapper> produtos) {
        Decimal valorTatolPedido = 0.00; 
        Decimal valor = 0.00;
        Decimal tatolFrete = 0.00; 

        for(ProdutoPrecoWrapper p : produtos) {
			// >>> Cliente redução
			Decimal precoTonelada = 0.0;
			precoTonelada = p.produto.Preco_ton_Reducao_ZTBSD_LME_MEDIA__c == null ? 0.00 : p.produto.Preco_ton_Reducao_ZTBSD_LME_MEDIA__c;
			if (precoTonelada > 0.0){
				valor = valor + (p.quantidade * p.produto.Preco_ton_Reducao_ZTBSD_LME_MEDIA__c.setscale(2));
			} else{
				valor = valor + (p.quantidade * p.produto.Preco_ton_Tres_Marias_ZTBSD_LME_ZDEMEDIA__c.setscale(2));
			}
        }
        
        return valorTatolPedido = valor;
    }

    private void recalcularValorTotalPedido(List<ProdutoPrecoWrapper> pList, ProdutoPrecoWrapper produto) {
        Decimal valor = 0.00;
        Decimal tatolFrete = 0.00; 

        for(ProdutoPrecoWrapper p : pList) {
            
            // >>> Cliente redução
			Decimal precoTonelada = 0.0;
			precoTonelada = p.produto.Preco_ton_Reducao_ZTBSD_LME_MEDIA__c == null ? 0.00 : p.produto.Preco_ton_Reducao_ZTBSD_LME_MEDIA__c;
			if (precoTonelada > 0.0){
				valor = valor + (p.quantidade * p.produto.Preco_ton_Reducao_ZTBSD_LME_MEDIA__c.setscale(2));
			}else {
				if(PLANTA_TRES_MARIAS == p.produto.Planta_selecionada__c){
					valor = valor + (p.quantidade * p.produto.Preco_ton_Tres_Marias_ZTBSD_LME_ZDEMEDIA__c.setscale(2));
				}else{
					if(PLANTA_JUIZ_DE_FORA == p.produto.Planta_selecionada__c){
						valor = valor + (p.quantidade * p.produto.Preco_ton_Juiz_de_Fora_ZTBSD_LME_MEDIA__c.setscale(2));
					}
				}
			}
        }

        this.valorTotalPedido = valor;
        this.valorTotalPedidoSTR = FormatValues.currencyBRL(valor, 3);
    }

    private static void executeQuery(List<Database.SaveResult> results){
    	for (Database.SaveResult result : results){
		    if (result.isSuccess()) {
		        System.debug('Registro persistido com sucesso: ' + result.getId());
		    }else{
		        for(Database.Error err : result.getErrors()) {
		            System.debug('Ocorreu o seguinte erro.');                   
		            System.debug(err.getStatusCode() + ': ' + err.getMessage());
		            System.debug('Campos que afetados por este erro: ' + err.getFields());
		        }
		    }
		}
    }

	private void formatarProdutoPreco(List<PricebookEntry> produtosPrecos, Map<String, Condicoes_de_pagamento__c> condsPagsMap) {
		this.produtosPrecosWrapper = new List<ProdutoPrecoWrapper>();
		for(PricebookEntry p : produtosPrecos) {
            Condicoes_de_pagamento__c condsPagsProd = condsPagsMap.get(p.ProductCode);

            System.debug('condsPagsProd.........: ' + condsPagsProd);

            ProdutoPrecoWrapper produtoPrecoWrapper = new ProdutoPrecoWrapper(p, condsPagsProd);
            
            this.produtosPrecosWrapper.add(produtoPrecoWrapper);

			// >>> Cliente redução 
            Decimal precoTonelada = produtoPrecoWrapper.produto.Preco_ton_Reducao_ZTBSD_LME_MEDIA__c == null ? 0.00 : produtoPrecoWrapper.produto.Preco_ton_Reducao_ZTBSD_LME_MEDIA__c;
			System.debug('precoTonelada........: ' + precoTonelada);

			if (precoTonelada > 0.0){
				this.valorTotalPedido = this.valorTotalPedido + (produtoPrecoWrapper.quantidade * produtoPrecoWrapper.produto.Preco_ton_Reducao_ZTBSD_LME_MEDIA__c.setscale(2));
				this.valorTotalPedidoSTR = FormatValues.currencyBRL(this.valorTotalPedido, 3);
			}else{
				if(PLANTA_TRES_MARIAS == p.Planta_selecionada__c){
					this.valorTotalPedido = this.valorTotalPedido + (produtoPrecoWrapper.quantidade * produtoPrecoWrapper.produto.Preco_ton_Tres_Marias_ZTBSD_LME_ZDEMEDIA__c.setscale(2));
					this.valorTotalPedidoSTR = FormatValues.currencyBRL(this.valorTotalPedido, 3);
				}else{
					if(PLANTA_JUIZ_DE_FORA == p.Planta_selecionada__c){
						this.valorTotalPedido = this.valorTotalPedido + (produtoPrecoWrapper.quantidade * produtoPrecoWrapper.produto.Preco_ton_Juiz_de_Fora_ZTBSD_LME_MEDIA__c.setscale(2));
						this.valorTotalPedidoSTR = FormatValues.currencyBRL(this.valorTotalPedido, 3);
					}
				}
			}
		}
	}
	
    private List<PricebookEntry> buscarProdutosPrecos(Set<Id> produtosSet) {
        return [select Id, Name, ProductCode, UnitPrice, 
                Pricebook2Id, 
                Product2.Description, 
                Product2.Product_Image__c, 
                Product2.Peso_liquido_do_item__c,
                Product2.QuantityUnitOfMeasure, 
                Planta_selecionada__c, Opcao_Planta_selecionada__c, IsActive,
                LME__c, QP__c, PremioUSD__c, ValorICMSBruto__c, Imposto__c,
                TaxaFinanceiraTresMarias__c, TaxaFinanceiraJuizDeFora__c,
                Taxa_impostos_Juiz_de_Fora_PA0045_EFFIN__c, 
                Taxa_impostos_3_Marias_PA0045_EFFIN__c,
                Valor_Frete_Juiz_de_Fora_EKBZ_KBETR__c, 
                Valor_Frete_Tres_Marias_EKBZ_KBETR__c,
                Preco_ton_Tres_Marias_ZTBSD_LME_ZDEMEDIA__c, 
                Preco_ton_Juiz_de_Fora_ZTBSD_LME_MEDIA__c,
                Preco_ton_Reducao_ZTBSD_LME_MEDIA__c,
                Volume_Minimo__c
                from PricebookEntry where Id = :produtosSet];
    }

    private void setarValoresCamposConta(Account contaContato) {
        this.nomeConta = contaContato.Name;
        this.codigoCliente =  contaContato.Codigo_do_Cliente_KNA1_KUNNR__c;
        this.limiteCredito = contaContato.Limite_de_credito__c;
        this.mostrarOpcoesCreditoflag = contaContato.Mostrar_opcoes_de_Credito_flag__c ? 'true' : 'false';
        this.disponibilidadeCredito = contaContato.Disponibilidade_de_cr_dito__c;
        this.setor = contaContato.Industry;
        this.telefone = contaContato.Phone;
        this.endecoentrega = contaContato.ShippingStreet + ', ' 
                            + contaContato.ShippingCity + ' - ' 
                            + contaContato.ShippingState + ', Cep. ' 
                            + contaContato.ShippingPostalCode + ' - ' 
                            + contaContato.ShippingCountry;
    }

    private User contatoUsuario(Id idUsuario) {
        return [select Id, ContactId from User where id = :idUsuario];
    }

    private Account buscarContaBackoffice(Id idConta) {
        Try{
                return [select Id, Name, Codigo_do_Cliente_KNA1_KUNNR__c, Limite_de_credito__c, 
                                Disponibilidade_de_cr_dito__c, Industry, Phone, 
                                ShippingStreet, ShippingCity, ShippingState, ShippingPostalCode, ShippingCountry,
                                Condicao_Pagamento_flag__c, Dolar_flag__c, Frete_flag__c, ICMS_flag__c, Imposto_flag__c, 
                                LME_flag__c, Premio_flag__c, QP_flag__c, Taxa_flag__c, Taxa_Financeira_flag__c, 
                                Condicao_de_Pagamento__c, Dolar__c, Frete__c, ICMS__c, Imposto__c, LME__c, Premio__c,
                                Organizacao_de_vendas_VBAK_VKORG__c, Canal_de_distribuicao_VBAK_VTWEG__c, 
                                Grupo_de_Vendedores_KNVV_VKGRP__c, Mostrar_opcoes_de_Credito_flag__c
                                from Account where id = :idConta];
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
            return null;
        }
    }

    private Account buscarContaContato(Id idContato) {
        Try{
            Contact contato = [select AccountId, Account.Name, Account.Codigo_do_Cliente_KNA1_KUNNR__c, Account.Limite_de_credito__c, 
                                Account.Disponibilidade_de_cr_dito__c, Account.Industry, Account.Phone, 
                                Account.ShippingStreet, Account.ShippingCity, Account.ShippingState, Account.ShippingPostalCode, Account.ShippingCountry,
                                Account.Condicao_Pagamento_flag__c, Account.Dolar_flag__c, Account.Frete_flag__c, Account.ICMS_flag__c, Account.Imposto_flag__c, 
                                Account.LME_flag__c, Account.Premio_flag__c, Account.QP_flag__c, Account.Taxa_flag__c, Account.Taxa_Financeira_flag__c, 
                                Account.Condicao_de_Pagamento__c, Account.Dolar__c, Account.Frete__c, Account.ICMS__c, Account.Imposto__c, Account.LME__c, Account.Premio__c,
                                Account.Organizacao_de_vendas_VBAK_VKORG__c, Account.Canal_de_distribuicao_VBAK_VTWEG__c, 
                                Account.Grupo_de_Vendedores_KNVV_VKGRP__c, Account.Mostrar_opcoes_de_Credito_flag__c
                                from Contact where id = :idContato];

            Account conta = new Account();
            conta.Id = contato.AccountId;
            conta.Name = contato.Account.Name;
            conta.Codigo_do_Cliente_KNA1_KUNNR__c = contato.Account.Codigo_do_Cliente_KNA1_KUNNR__c;
            conta.Limite_de_credito__c = contato.Account.Limite_de_credito__c;
            conta.Disponibilidade_de_cr_dito__c = contato.Account.Disponibilidade_de_cr_dito__c;
            conta.Industry = contato.Account.Industry;
            conta.Phone = contato.Account.Phone;
            conta.ShippingStreet = contato.Account.ShippingStreet;
            conta.ShippingCity = contato.Account.ShippingCity;
            conta.ShippingState = contato.Account.ShippingState;
            conta.ShippingPostalCode = contato.Account.ShippingPostalCode;
            conta.ShippingCountry = contato.Account.ShippingCountry;
            conta.Condicao_Pagamento_flag__c = contato.Account.Condicao_Pagamento_flag__c;
            conta.Dolar_flag__c = contato.Account.Dolar_flag__c;
            conta.Frete_flag__c = contato.Account.Frete_flag__c;
            conta.ICMS_flag__c = contato.Account.ICMS_flag__c;
            conta.Imposto_flag__c = contato.Account.Imposto_flag__c;
            conta.LME_flag__c = contato.Account.LME_flag__c;
            conta.Premio_flag__c = contato.Account.Premio_flag__c;
            conta.QP_flag__c = contato.Account.QP_flag__c;
            conta.Taxa_flag__c = contato.Account.Taxa_flag__c;
            conta.Taxa_Financeira_flag__c = contato.Account.Taxa_Financeira_flag__c;
            conta.Condicao_de_Pagamento__c = contato.Account.Condicao_de_Pagamento__c;
            conta.Dolar__c = contato.Account.Dolar__c;
            conta.Frete__c = contato.Account.Frete__c;
            conta.ICMS__c = contato.Account.ICMS__c;
            conta.Imposto__c = contato.Account.Imposto__c;
            conta.LME__c = contato.Account.LME__c;
            conta.Premio__c = contato.Account.Premio__c;
            conta.Organizacao_de_vendas_VBAK_VKORG__c = contato.Account.Organizacao_de_vendas_VBAK_VKORG__c;
            conta.Canal_de_distribuicao_VBAK_VTWEG__c = contato.Account.Canal_de_distribuicao_VBAK_VTWEG__c;
            conta.Grupo_de_Vendedores_KNVV_VKGRP__c = contato.Account.Grupo_de_Vendedores_KNVV_VKGRP__c;
            conta.Mostrar_opcoes_de_Credito_flag__c = contato.Account.Mostrar_opcoes_de_Credito_flag__c;
            return conta;
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
            return null;
        }
    }

    private List<Account> buscarContasNexa() {
        try{
                return [select Id, Name, Codigo_do_Cliente_KNA1_KUNNR__c, Limite_de_credito__c, 
                        Disponibilidade_de_cr_dito__c, Industry, Phone,
                        Condicao_Pagamento_flag__c, Dolar_flag__c, Frete_flag__c, ICMS_flag__c, Imposto_flag__c, 
                        LME_flag__c, Premio_flag__c, QP_flag__c, Taxa_flag__c, Taxa_Financeira_flag__c,
                        ShippingStreet, ShippingPostalCode, ShippingCity, ShippingState, ShippingCountry
                        from Account where Codigo_do_Cliente_KNA1_KUNNR__c <> null];
        } catch(QueryException e) {
            System.debug('buscarContasNexaERRO.......: ' + e.getMessage());
            return null;
        }
    }

    private List<Account> getContaPai(Id cdConta) {
        try{
            return [SELECT Id, ParentId, Codigo_do_Cliente_KNA1_KUNNR__c FROM Account where Id = :cdConta];
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
            return null;
        }
    }

    private List<Account> getContasFilhas(Id cdPai) {
        try{
            return [SELECT Id, Name, Codigo_do_Cliente_KNA1_KUNNR__c, ShippingStreet, 
                        ShippingCity, ShippingState, ShippingPostalCode, ShippingCountry 
                    FROM Account where ParentId = :cdPai];
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
            return null;
        }
    }



    /*-------------Criar Pedido---------------
    https://desenv-nexaresources.cs13.force.com
    usuário: clienteportalexterno@nexaresources.com
    senha:cliente@nexadev
    ------------------------------------------
   
*/
    
    public static void TestClass() {
        Integer i = 0;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
    }
}