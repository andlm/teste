package com.nexxera.pds.entity.enums;

public enum TipoContrato 
{
	Gravado("Gravado"),
	EnvAssinatura("Enviado para Assinatura"),
	Assinado("Assinado"),
	Expirado("Expirado"),
	CodigoBarra("C�digo de Barra"),
	//MarcaDagua("Marca D'�gua"),
	AssinaturaBiometrica("Assinado Bimetrico"),
	Escribo("Escribo"),
	AssinaturaBiometricaVerficacao("Assinado Bimetrico com Verifica��o"),
	Cancelado("Cancelado");

	private String nome;

	private TipoContrato(String nome){
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
