package com.nexxera.pds.webservice.server;

import javax.ejb.Stateless;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.nexxera.pds.webservice.exception.PDSServerException;

@WebService(name = "PDSPdfSignerService")
@Stateless
public class PDSPdfSignerService {
	
	private ICPBrasilA1Server icpBrasilA1Server;
	
	public PDSPdfSignerService() {
		icpBrasilA1Server = new ICPBrasilA1Server();
	}
	
	@WebMethod
	public boolean validarCertificadoICPBrasilA1(	@WebParam(name = "certificado") String certificado, 
													@WebParam(name = "cadeiaDeCertificados") String[] cadeiaDeCertificados) throws PDSServerException {
		
		return icpBrasilA1Server.validarCertificadoICPBrasilA1(certificado, cadeiaDeCertificados);
		
	}
	
	@WebMethod
	public boolean validarCPFDoCertificadoComNumeroDeIdentificacaoDoUsuarioEmpresa(	@WebParam(name = "certificado") String certificado,	
																					@WebParam(name = "cdContratoAssinaturaServico") Long cdContratoAssinaturaServico) throws PDSServerException {
		
		return icpBrasilA1Server.validarCPFDoCertificadoComNumeroDeIdentificacaoDoUsuarioEmpresa(certificado, cdContratoAssinaturaServico);
		
	}
	
	@WebMethod
	public String baixarPdfDoContratoParaSerAssinado(@WebParam(name = "cdContratoAssinaturaServico") Long cdContratoAssinaturaServico) throws PDSServerException {
		
		return icpBrasilA1Server.enviarPdfDoContrato(cdContratoAssinaturaServico);
	}
	
	@WebMethod
	public boolean enviarPdfDoContratoAssinado(	@WebParam(name = "pdfAssinado") String pdfAssinado,
											  	@WebParam(name = "cdContratoAssinaturaServico") Long cdContratoAssinaturaServico) throws PDSServerException {
		
		if (icpBrasilA1Server.salvarPdfDoContratoAssinado(cdContratoAssinaturaServico, pdfAssinado)) {
			icpBrasilA1Server.ativarProximoContratoAssinaturaDoWorkflowDoTrackingAAssinar(cdContratoAssinaturaServico);
			return true;
		}
		
		return false;
	}
}
