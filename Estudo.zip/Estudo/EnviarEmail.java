package com.nexxera.pds.utility;

import org.jboss.seam.annotations.Name;

import com.nexxera.pds.service.MailService;
import com.nexxera.pds.service.exception.ServiceException;


@Name("enviarEmail")
public class EnviarEmail {

	private String para;
	private String assunto;
	private String mensagem;
	private String url;

	public void enviar() throws ServiceException{
			SeamUtils.getComponent(MailService.class).enviar("emailUsuario", this);
	}

	public String getPara() {
		return para;
	}

	public void setPara(String para) {
		this.para = para;
	}

	public String getAssunto() {
		return assunto;
	}

	public void setAssunto(String assunto) {
		this.assunto = assunto;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
}