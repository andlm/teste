package com.flipkart.batching.gson.adapters;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.stream.JsonWriter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public final class JSONUtils {

    private static final String IS_JSON_OBJECT = "isJsonObject";
    private static final String IS_JSON_ARRAY = "isJsonArray";

    private static JsonElement getJsonElement(JsonWriter out, Object value) throws IOException {
        JsonElement element = null;
        if (null != value) {
            if (value instanceof JSONObject) {
                element = JSON_OBJECT.serialize(out, (JSONObject) value);
            } else if (value instanceof JSONArray) {
                element = JSON_ARRAY.serialize(out, (JSONArray) value);
            } else if (value instanceof String) {
                element = new JsonPrimitive((String) value);
            } else if (value instanceof Number) {
                element = new JsonPrimitive((Number) value);
            } else if (value instanceof Boolean) {
                element = new JsonPrimitive((Boolean) value);
            }
        }

        return element;
    }

    private static Map<String, Object> getMapFromJson(JsonObject data) {
        Map<String, Object> result = null;
        if (null != data) {
            result = new LinkedTreeMap<>();
            for (Map.Entry<String, JsonElement> entry : data.entrySet()) {
                result.put(entry.getKey(), getObjectFromJsonElement(entry.getValue()));
            }
        }
        return result;
    }

    private static Object getObjectFromJsonElement(JsonElement value) {
        Object result = null;
        if (value.isJsonObject()) {
            if (value.getAsJsonObject().has(IS_JSON_OBJECT)) {
                JSONObject jsonObject = JSON_OBJECT.deserialize(value);
                if (null != jsonObject) {
                    jsonObject.remove(IS_JSON_OBJECT);
                }
                return jsonObject;
            } else if (value.getAsJsonObject().has(IS_JSON_ARRAY)) {
                return JSON_ARRAY.deserialize(value);
            } else {
                result = getMapFromJson(value.getAsJsonObject());
            }

        } else if (value.isJsonPrimitive()) {
            JsonPrimitive primitiveValue = value.getAsJsonPrimitive();
            if (primitiveValue.isBoolean()) {
                result = primitiveValue.getAsBoolean();
            } else if (primitiveValue.isNumber()) {
                result = primitiveValue.getAsNumber();
            } else {
                result = primitiveValue.getAsString();
            }
        } else if (value.isJsonNull()) {
            result = null;
        } else if (value.isJsonArray()) {
            JsonArray jsonArray = value.getAsJsonArray();
            ArrayList<Object> list = new ArrayList<>(jsonArray.size());
            for (JsonElement element : jsonArray) {
                list.add(getObjectFromJsonElement(element));
            }
            result = list;
        }
        return result;
    }

    static final class JSON_OBJECT {
        static JsonObject serialize(JsonWriter out, JSONObject value) throws IOException {
            JsonObject result;
            try {
                result = new JsonObject();
                Iterator<String> iterator = value.keys();
                while (iterator.hasNext()) {
                    String keyType = iterator.next();
                    Object valueType = value.get(keyType);
                    JsonElement element = JSONUtils.getJsonElement(out, valueType);
                    result.add(keyType, element);
                }
                result.addProperty(IS_JSON_OBJECT, true);
                return result;
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        }

        static JSONObject deserialize(JsonElement jsonElement) {
            JSONObject result = null;
            if (null != jsonElement && jsonElement.isJsonObject()) {
                try {
                    result = new JSONObject();
                    JsonObject jsonObject = jsonElement.getAsJsonObject();
                    for (Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                        JsonElement value = entry.getValue();
                        if (null != value) {
                            result.put(entry.getKey(), JSONUtils.getObjectFromJsonElement(entry.getValue()));
                        } else {
                            result.put(entry.getKey(), null);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return result;
        }
    }

    static final class JSON_ARRAY {
        static JsonElement serialize(JsonWriter out, JSONArray value) throws IOException {
            JsonObject result;
            try {
                result = new JsonObject();
                JsonArray jsonArray = new JsonArray();
                for (int idx = 0; idx < value.length(); idx++) {
                    Object valueKey = value.get(idx);
                    JsonElement element = JSONUtils.getJsonElement(out, valueKey);
                    jsonArray.add(element);
                }
                result.add(IS_JSON_ARRAY, jsonArray);
                return result;
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        }

        static JSONArray deserialize(JsonElement jsonElement) {
            JSONArray result = null;
            if (null != jsonElement) {
                result = new JSONArray();
                if (jsonElement.isJsonObject() && jsonElement.getAsJsonObject().has(IS_JSON_ARRAY)) {
                    JsonArray jsonArray = jsonElement.getAsJsonObject().getAsJsonArray(IS_JSON_ARRAY);
                    for (JsonElement element : jsonArray) {
                        if (null != element) {
                            result.put(JSONUtils.getObjectFromJsonElement(element));
                        } else {
                            result.put(null);
                        }
                    }
                }
            }
            return result;
        }
    }
}