package br.prosaude.arquitetura.core;

import java.util.ArrayList;
import java.util.List;

public class Pilha {
	private List<Object> lista = new ArrayList<Object>(5);

	public void insere(Object objeto) {
		this.lista.add(objeto);
	}

	public Object retira() {
		return this.lista.remove(this.lista.size() - 1);
	}

	public Object get() {
		return this.lista.get(this.lista.size() - 1);
	}

	public void limpar() {
		this.lista.clear();
	}
}
