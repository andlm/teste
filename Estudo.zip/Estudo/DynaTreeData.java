/*  1:   */ package br.com.virtuoso.prosaude.utils.view;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ 
/*  5:   */ public class DynaTreeData
/*  6:   */ {
/*  7:   */   private String title;
/*  8:   */   private String key;
/*  9:   */   private Boolean activate;
/* 10:   */   private Boolean isFolder;
/* 11:   */   private Boolean expand;
/* 12:   */   private List<DynaTreeData> children;
/* 13:   */   
/* 14:   */   public String getTitle()
/* 15:   */   {
/* 16:19 */     return this.title;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setTitle(String title)
/* 20:   */   {
/* 21:23 */     this.title = title;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getKey()
/* 25:   */   {
/* 26:27 */     return this.key;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setKey(String key)
/* 30:   */   {
/* 31:31 */     this.key = key;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Boolean getActivate()
/* 35:   */   {
/* 36:35 */     return this.activate;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void setActivate(Boolean activate)
/* 40:   */   {
/* 41:39 */     this.activate = activate;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public Boolean getIsFolder()
/* 45:   */   {
/* 46:43 */     return this.isFolder;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setIsFolder(Boolean isFolder)
/* 50:   */   {
/* 51:47 */     this.isFolder = isFolder;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public Boolean getExpand()
/* 55:   */   {
/* 56:51 */     return this.expand;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void setExpand(Boolean expand)
/* 60:   */   {
/* 61:55 */     this.expand = expand;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public List<DynaTreeData> getChildren()
/* 65:   */   {
/* 66:59 */     return this.children;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void setChildren(List<DynaTreeData> children)
/* 70:   */   {
/* 71:63 */     this.children = children;
/* 72:   */   }
/* 73:   */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.view.DynaTreeData
 * JD-Core Version:    0.7.0.1
 */