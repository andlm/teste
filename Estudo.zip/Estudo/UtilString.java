/*   1:    */ package br.com.virtuoso.prosaude.utils;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.text.DecimalFormat;
/*   5:    */ import java.text.DecimalFormatSymbols;
/*   6:    */ import java.util.Arrays;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.regex.Matcher;
/*   9:    */ import java.util.regex.Pattern;
/*  10:    */ 
/*  11:    */ public class UtilString
/*  12:    */ {
/*  13:    */   public static final String NULL = "null";
/*  14:    */   public static final String EMPTY = "";
/*  15:    */   public static final String ESPACO = " ";
/*  16:    */   public static final String ZERO = "0";
/*  17:    */   public static final String QUEBRA_LINHA = "\r\n";
/*  18:    */   
/*  19:    */   public static void main(String... args)
/*  20:    */   {
/*  21: 24 */     System.out.println(getDecimalFormatPtBr("No   ##########0000000000").format(1.0D));
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static String esquerda(String texto, Integer qtdCaracteres)
/*  25:    */   {
/*  26: 28 */     if (texto.length() < qtdCaracteres.intValue()) {
/*  27: 29 */       qtdCaracteres = Integer.valueOf(texto.length());
/*  28:    */     }
/*  29: 31 */     return texto.substring(0, qtdCaracteres.intValue());
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static String direita(String texto, Integer qtdCaracteres)
/*  33:    */   {
/*  34: 35 */     if (texto.length() < qtdCaracteres.intValue()) {
/*  35: 36 */       qtdCaracteres = Integer.valueOf(texto.length());
/*  36:    */     }
/*  37: 38 */     return texto.substring(texto.length() - qtdCaracteres.intValue(), texto.length());
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static boolean isNuloOuBranco(Object objeto)
/*  41:    */   {
/*  42: 42 */     return (objeto == null) || (objeto.toString().trim().equals("")) || (objeto.toString().trim().equals("null"));
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static String retirarAcentos(String valor)
/*  46:    */   {
/*  47: 47 */     String[] REPLACES = { "a", "e", "i", "o", "u", "c", "A", "E", "I", "O", "U", "C" };
/*  48:    */     
/*  49: 49 */     Pattern[] PATTERNS = new Pattern[REPLACES.length];
/*  50: 50 */     PATTERNS[0] = Pattern.compile("[âãáàä]");
/*  51: 51 */     PATTERNS[1] = Pattern.compile("[éèêë]");
/*  52: 52 */     PATTERNS[2] = Pattern.compile("[íìîï]");
/*  53: 53 */     PATTERNS[3] = Pattern.compile("[óòôõö]");
/*  54: 54 */     PATTERNS[4] = Pattern.compile("[úùûü]");
/*  55: 55 */     PATTERNS[5] = Pattern.compile("[ç]");
/*  56: 56 */     PATTERNS[6] = Pattern.compile("[ÂÃÁÀÄ]");
/*  57: 57 */     PATTERNS[7] = Pattern.compile("[ÉÈÊË]");
/*  58: 58 */     PATTERNS[8] = Pattern.compile("[ÍÌÎÏ]");
/*  59: 59 */     PATTERNS[9] = Pattern.compile("[ÓÒÔÕÖ]");
/*  60: 60 */     PATTERNS[10] = Pattern.compile("[ÚÙÛÜ]");
/*  61: 61 */     PATTERNS[11] = Pattern.compile("[Ç]");
/*  62:    */     
/*  63: 63 */     String result = valor;
/*  64: 64 */     for (int i = 0; i < PATTERNS.length; i++)
/*  65:    */     {
/*  66: 65 */       Matcher matcher = PATTERNS[i].matcher(result);
/*  67: 66 */       result = matcher.replaceAll(REPLACES[i]);
/*  68:    */     }
/*  69: 69 */     result = result.replaceAll("[^\\p{ASCII}]", "");
/*  70:    */     
/*  71: 71 */     return result;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static String normalizarNomeProprio(String texto)
/*  75:    */   {
/*  76: 75 */     StringBuffer retorno = new StringBuffer();
/*  77: 76 */     List<String> partesDoTexto = Arrays.asList(texto.split(" "));
/*  78: 77 */     for (String parte : partesDoTexto)
/*  79:    */     {
/*  80: 79 */       int tamanhoParte = parte.trim().length();
/*  81: 80 */       if (tamanhoParte != 0)
/*  82:    */       {
/*  83: 84 */         retorno.append(parte.substring(0, 1).toUpperCase());
/*  84: 85 */         retorno.append(parte.substring(1, tamanhoParte).toLowerCase());
/*  85: 86 */         retorno.append(" ");
/*  86:    */       }
/*  87:    */     }
/*  88: 88 */     return retorno.toString();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public static String normalizarCpf(String texto)
/*  92:    */   {
/*  93: 92 */     texto = Pattern.compile("[^0-9]").matcher(texto).replaceAll("");
/*  94:    */     
/*  95: 94 */     int tamanho = texto.length();
/*  96: 95 */     for (int i = 0; i < 11 - tamanho; i++) {
/*  97: 96 */       texto = "0" + texto;
/*  98:    */     }
/*  99: 98 */     texto = texto.substring(0, 3) + "." + texto.substring(3, 6) + "." + texto.substring(6, 9) + "-" + texto.substring(9, 11);
/* 100: 99 */     return texto;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static String toBrancoSeNull(Object objeto)
/* 104:    */   {
/* 105:103 */     if (objeto == null) {
/* 106:104 */       return "";
/* 107:    */     }
/* 108:106 */     return objeto.toString();
/* 109:    */   }
/* 110:    */   
/* 111:    */   public static String toTracoSeNull(Object objeto)
/* 112:    */   {
/* 113:110 */     if (objeto == null) {
/* 114:111 */       return "--";
/* 115:    */     }
/* 116:113 */     return objeto.toString();
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static String primeiraMinuscula(String texto)
/* 120:    */   {
/* 121:117 */     return texto.substring(0, 1).toLowerCase() + texto.substring(1);
/* 122:    */   }
/* 123:    */   
/* 124:    */   private static DecimalFormat getDecimalFormatPtBr(String mascara)
/* 125:    */   {
/* 126:121 */     DecimalFormatSymbols formatoPtBr = new DecimalFormatSymbols(UtilLocale.getLocale());
/* 127:122 */     formatoPtBr.setDecimalSeparator(',');
/* 128:123 */     formatoPtBr.setGroupingSeparator('.');
/* 129:124 */     DecimalFormat df = new DecimalFormat(mascara, formatoPtBr);
/* 130:125 */     return df;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public static String formatarMoedaDuasCasasDecimais(Double vlr)
/* 134:    */   {
/* 135:129 */     if (vlr == null) {
/* 136:130 */       return "R$ 0,00";
/* 137:    */     }
/* 138:131 */     return getDecimalFormatPtBr("R$ ###,###,##0.00").format(vlr);
/* 139:    */   }
/* 140:    */   
/* 141:    */   public static String formatarNumeroDuasCasasDecimais(Double vlr)
/* 142:    */   {
/* 143:135 */     if (vlr == null) {
/* 144:136 */       return "0,00";
/* 145:    */     }
/* 146:137 */     return getDecimalFormatPtBr("###,###,##0.00").format(vlr);
/* 147:    */   }
/* 148:    */   
/* 149:    */   public static String formatarNumeroTresCasasDecimais(Double vlr)
/* 150:    */   {
/* 151:141 */     if (vlr == null) {
/* 152:142 */       return "0,000";
/* 153:    */     }
/* 154:143 */     return getDecimalFormatPtBr("###,###,###0.000").format(vlr);
/* 155:    */   }
/* 156:    */   
/* 157:    */   public static String formatarNumeroQuatroCasasDecimais(Double vlr)
/* 158:    */   {
/* 159:147 */     if (vlr == null) {
/* 160:148 */       return "0,0000";
/* 161:    */     }
/* 162:149 */     return getDecimalFormatPtBr("###,###,####0.0000").format(vlr);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public static String completarCaracterAEsquerda(String texto, String caracter, Integer nrVezes)
/* 166:    */   {
/* 167:153 */     StringBuffer retorno = new StringBuffer();
/* 168:154 */     for (int i = 0; i < nrVezes.intValue(); i++) {
/* 169:155 */       retorno.append(caracter);
/* 170:    */     }
/* 171:157 */     retorno.append(texto);
/* 172:158 */     return retorno.toString();
/* 173:    */   }
/* 174:    */   
/* 175:    */   public static String completarCaracterADireita(String texto, String caracter, Integer nrVezes)
/* 176:    */   {
/* 177:162 */     StringBuffer retorno = new StringBuffer();
/* 178:163 */     retorno.append(texto);
/* 179:164 */     for (int i = 0; i < nrVezes.intValue(); i++) {
/* 180:165 */       retorno.append(caracter);
/* 181:    */     }
/* 182:167 */     return retorno.toString();
/* 183:    */   }
/* 184:    */   
/* 185:    */   public static String normalizaStringDataTable(String texto)
/* 186:    */   {
/* 187:171 */     texto = texto.replaceAll("'", "");
/* 188:172 */     return texto;
/* 189:    */   }
/* 190:    */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilString
 * JD-Core Version:    0.7.0.1
 */