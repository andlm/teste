package com.nexxera.pds.utility;

import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

import org.pdfclown.bytes.Buffer;
import org.pdfclown.documents.Document;
import org.pdfclown.documents.Page;
import org.pdfclown.documents.contents.ITextString;
import org.pdfclown.documents.contents.TextChar;
import org.pdfclown.files.File;
import org.pdfclown.tools.TextExtractor;

import com.nexxera.pds.webservice.server.RegiaoCaixaAssinatura;


public class PdfClownUtil {
	
	public static List<Texto> search(byte[] pdfBytes, String text, Orientacao orientacao) {
		File pdf = new File(new Buffer(pdfBytes));
		return search(pdf, text, orientacao);
	}
	
	public static List<Texto> search(File pdf, String text, Orientacao orientacao) {
		List<Texto> textos = new ArrayList<Texto>();
		Document document = pdf.getDocument();
		for (Page page: document.getPages())
			searchInPage(page, text, orientacao, textos);
		return textos;
	}
	
	private static void searchInPage(Page page, String text, Orientacao orientacao, List<Texto> textos) {
		List<ITextString> textStrings = new TextExtractor().extract(page).get(null);
		for (ITextString textString : textStrings)
			searchInText(page, textString, text, orientacao, textos);
	}

	private static void searchInText(Page page, ITextString textString, String text, Orientacao orientacao, List<Texto> textos) {
		char[] caracteres = text.toCharArray();
		int indice = 0;
		Rectangle2D inicio = null;
		
		boolean aguardarProximoEspaco = false;
		
		List<TextChar> chars = textString.getTextChars();
		for (int i = 0; i < chars.size(); i++) {
			TextChar tChar = chars.get(i);
			
			if (tChar.isVirtual()) {
				aguardarProximoEspaco = false;
				continue;
			}
			
			if (aguardarProximoEspaco) {
				aguardarProximoEspaco = tChar.getValue() > ' ';
				continue;
			}
			
			if (tChar.getValue() <= ' ') {
				indice = 0;
				continue;
			}
			
			if (tChar.getValue() != caracteres[indice]) {
				aguardarProximoEspaco = true;
				indice = 0;
				continue;
			}
			
			if (indice == 0) {
				inicio = tChar.getBox();
			}
				
			if (++indice >= caracteres.length) {
				if (i + 1 == chars.size() || chars.get(i + 1).getValue() <= ' ') {
					Texto texto = new Texto(text, page.getIndex() + 1, inicio, tChar.getBox());
					orientacao.aplicarOrientacao(texto, page.getSize().getWidth(), page.getSize().getHeight());
					textos.add(texto);
				}
				aguardarProximoEspaco = true;
				indice = 0;
			}
		}		
	}
	
	public static RegiaoCaixaAssinatura convert(Texto texto) {
		RegiaoCaixaAssinatura regiaoCaixaAssinatura = new RegiaoCaixaAssinatura();
		if (texto == null)
			return regiaoCaixaAssinatura;
		regiaoCaixaAssinatura.setNumeroPagina(texto.pagina);
		regiaoCaixaAssinatura.setXDireita(new Float(texto.retangulo.getX() + texto.retangulo.getWidth()));
		regiaoCaixaAssinatura.setXEsquerda(new Float(texto.retangulo.getX()));
		regiaoCaixaAssinatura.setYBase(new Float(texto.retangulo.getY()));
		regiaoCaixaAssinatura.setYTopo(new Float(texto.retangulo.getY() + texto.retangulo.getHeight() + 30));
		return regiaoCaixaAssinatura;
	}
	
	public static class Texto {
		
		public final String conteudo;
		public final int pagina;
		public final Rectangle2D retangulo;
		
		public Texto(String conteudo, int pagina, double x, double y, double w, double h) {
			super();
			this.conteudo = conteudo;
			this.pagina = pagina;
			this.retangulo = new Rectangle.Double(x, y, w, h);
		}
		
		public Texto(String conteudo, int pagina, Rectangle2D retangulo) {
			this(conteudo, pagina, retangulo.getX(), retangulo.getY(), retangulo.getWidth(), retangulo.getHeight());
		}
		
		public Texto(String conteudo, int pagina, Rectangle2D inicio, Rectangle2D fim) {
			this(conteudo, pagina, inicio.createUnion(fim));
		}
		
		@Override
		public String toString() {
			return "Texto '" + conteudo + "', pg " + pagina + " [ " + Math.round(retangulo.getX()) + ", " +
																	  Math.round(retangulo.getY()) + ", " +
																	  Math.round(retangulo.getWidth()) + ", " +
																	  Math.round(retangulo.getHeight()) + " ]";
		}

	}
	
	public static enum Orientacao {
		
		SUPERIOR_ESQUERDA,
		INFERIOR_ESQUERDA {
			@Override
			protected void aplicarOrientacao(Texto texto, double pageWidth, double pageHeight) {
				double x = texto.retangulo.getX();
				double y = texto.retangulo.getY();
				double w = texto.retangulo.getWidth();
				double h = texto.retangulo.getHeight();
				texto.retangulo.setRect(x, pageHeight - y - h, w, h);
			}
		};
		
		protected void aplicarOrientacao(Texto texto, double pageWidth, double pageHeight) { }
		
	}

}
