/*   1:    */ package br.com.virtuoso.prosaude.utils.hibernate;
/*   2:    */ 
/*   3:    */ import br.com.virtuoso.prosaude.models.Persistivel;
/*   4:    */ import br.com.virtuoso.prosaude.models.tabela.TabAtivo;
/*   5:    */ import java.lang.reflect.Field;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Map.Entry;
/*  11:    */ import java.util.Set;
/*  12:    */ import org.hibernate.Criteria;
/*  13:    */ import org.hibernate.Session;
/*  14:    */ import org.hibernate.criterion.Order;
/*  15:    */ import org.hibernate.criterion.ProjectionList;
/*  16:    */ import org.hibernate.criterion.Projections;
/*  17:    */ import org.hibernate.criterion.PropertyProjection;
/*  18:    */ import org.hibernate.criterion.Restrictions;
/*  19:    */ import org.hibernate.transform.AliasToBeanResultTransformer;
/*  20:    */ 
/*  21:    */ public class UtilConsultaCriteria<T>
/*  22:    */ {
/*  23: 27 */   private final String INNER_JOIN_IDENTIFY = "@INNER_JOIN#";
/*  24: 28 */   private final String LEFT_JOIN_IDENTIFY = "@LEFT_JOIN#";
/*  25:    */   private Session session;
/*  26:    */   private Class tClass;
/*  27:    */   private Boolean distinct;
/*  28:    */   private Boolean somenteAtivos;
/*  29:    */   private Integer firstResult;
/*  30:    */   private Integer maxResults;
/*  31:    */   private Object[] filtros;
/*  32:    */   private Object[] ordens;
/*  33:    */   
/*  34:    */   public UtilConsultaCriteria(Session session, Class tClass)
/*  35:    */   {
/*  36: 40 */     this.session = session;
/*  37: 41 */     this.tClass = tClass;
/*  38: 42 */     this.distinct = Boolean.FALSE;
/*  39: 43 */     this.somenteAtivos = Boolean.FALSE;
/*  40: 44 */     this.firstResult = Integer.valueOf(0);
/*  41: 45 */     this.maxResults = Integer.valueOf(0);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setDistinct(Boolean distinct)
/*  45:    */   {
/*  46: 49 */     this.distinct = distinct;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void setSomenteAtivos(Boolean somenteAtivos)
/*  50:    */   {
/*  51: 53 */     this.somenteAtivos = somenteAtivos;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setFirstResult(Integer firstResult)
/*  55:    */   {
/*  56: 57 */     this.firstResult = firstResult;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void setMaxResults(Integer maxResults)
/*  60:    */   {
/*  61: 61 */     this.maxResults = maxResults;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setFiltros(Object... filtros)
/*  65:    */   {
/*  66: 65 */     this.filtros = filtros;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setOrdem(Object... ordens)
/*  70:    */   {
/*  71: 69 */     this.ordens = ordens;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public List<T> list()
/*  75:    */     throws Exception
/*  76:    */   {
/*  77: 73 */     return getCriteria().list();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public List<T> listIntervalo(Integer firstResult, Integer maxResults)
/*  81:    */     throws Exception
/*  82:    */   {
/*  83: 77 */     Criteria criteria = getCriteria();
/*  84: 78 */     criteria.setFirstResult(firstResult.intValue());
/*  85: 79 */     criteria.setMaxResults(maxResults.intValue());
/*  86: 80 */     return getCriteria().list();
/*  87:    */   }
/*  88:    */   
/*  89:    */   public T uniqueResult()
/*  90:    */     throws Exception
/*  91:    */   {
/*  92: 84 */     return getCriteria().uniqueResult();
/*  93:    */   }
/*  94:    */   
/*  95:    */   public int count()
/*  96:    */     throws Exception
/*  97:    */   {
/*  98: 88 */     Criteria criteria = getCriteria();
/*  99: 89 */     criteria.setProjection(Projections.rowCount());
/* 100: 90 */     return ((Long)criteria.list().get(0)).intValue();
/* 101:    */   }
/* 102:    */   
/* 103:    */   private Criteria getCriteria()
/* 104:    */     throws Exception
/* 105:    */   {
/* 106: 94 */     Criteria criteria = this.session.createCriteria(this.tClass, "main");
/* 107: 95 */     aplicandoJoins(criteria);
/* 108: 96 */     aplicandoFiltros(criteria);
/* 109: 97 */     aplicandoOrdens(criteria);
/* 110: 98 */     return criteria;
/* 111:    */   }
/* 112:    */   
/* 113:    */   private void aplicandoOrdens(Criteria criteria)
/* 114:    */     throws Exception
/* 115:    */   {
/* 116:102 */     if ((this.ordens != null) && (this.ordens.length >= 2)) {
/* 117:103 */       for (int i = 0; i < this.ordens.length; i++)
/* 118:    */       {
/* 119:104 */         String atributo = "main." + this.ordens[(i++)].toString();
/* 120:105 */         String direcao = this.ordens[i].toString();
/* 121:106 */         if ("ASC".equalsIgnoreCase(direcao)) {
/* 122:107 */           criteria.addOrder(Order.asc(atributo));
/* 123:108 */         } else if ("DESC".equalsIgnoreCase(direcao)) {
/* 124:109 */           criteria.addOrder(Order.desc(atributo));
/* 125:    */         }
/* 126:    */       }
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   private void aplicandoJoins(Criteria criteria)
/* 131:    */     throws Exception
/* 132:    */   {
/* 133:117 */     Map<String, Object> mapJoins = new HashMap();
/* 134:118 */     if ((this.filtros != null) && (this.filtros.length >= 2)) {
/* 135:119 */       for (int i = 0; i < this.filtros.length; i++)
/* 136:    */       {
/* 137:120 */         String join = this.filtros[(i++)].toString();
/* 138:121 */         if (join.indexOf(".") > 0)
/* 139:    */         {
/* 140:122 */           String[] relacionamentos = join.split("\\.");
/* 141:123 */           String joinAnterior = "main";
/* 142:124 */           String aliaseAnterior = "main";
/* 143:125 */           for (int y = 0; y < relacionamentos.length - 1; y++)
/* 144:    */           {
/* 145:126 */             mapJoins.put(joinAnterior + "." + relacionamentos[y], aliaseAnterior + "_" + relacionamentos[y]);
/* 146:127 */             joinAnterior = aliaseAnterior + "_" + relacionamentos[y];
/* 147:128 */             aliaseAnterior = joinAnterior;
/* 148:    */           }
/* 149:    */         }
/* 150:    */       }
/* 151:    */     }
/* 152:134 */     Set setJoins = mapJoins.entrySet();
/* 153:135 */     Iterator iteratorSetJoins = setJoins.iterator();
/* 154:136 */     while (iteratorSetJoins.hasNext())
/* 155:    */     {
/* 156:137 */       Map.Entry joinFinal = (Map.Entry)iteratorSetJoins.next();
/* 157:138 */       boolean isLeftJoin = joinFinal.getKey().toString().indexOf("@LEFT_JOIN#") > 0;
/* 158:139 */       if (isLeftJoin) {
/* 159:140 */         criteria.createAlias(joinFinal.getKey().toString().replace("@LEFT_JOIN#", ""), joinFinal.getValue().toString().replace("@LEFT_JOIN#", ""), 1);
/* 160:    */       } else {
/* 161:143 */         criteria.createAlias(joinFinal.getKey().toString().replace("@INNER_JOIN#", ""), joinFinal.getValue().toString().replace("@INNER_JOIN#", ""), 0);
/* 162:    */       }
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   public Map<String, Object> aplicandoFiltrosBase(Criteria criteria)
/* 167:    */     throws Exception
/* 168:    */   {
/* 169:150 */     if (this.somenteAtivos.booleanValue()) {
/* 170:151 */       criteria.createAlias("main.tabAtivo", "main_tabAtivo", 0).add(Restrictions.eq("main_tabAtivo.chAtivo", TabAtivo.ATIVO));
/* 171:    */     }
/* 172:154 */     if (this.firstResult.intValue() > 0) {
/* 173:155 */       criteria.setFirstResult(this.firstResult.intValue());
/* 174:    */     }
/* 175:157 */     if (this.maxResults.intValue() > 0) {
/* 176:158 */       criteria.setMaxResults(this.maxResults.intValue());
/* 177:    */     }
/* 178:161 */     Map<String, Object> mapAtributos = new HashMap();
/* 179:162 */     if ((this.filtros != null) && (this.filtros.length >= 2)) {
/* 180:163 */       for (int i = 0; i < this.filtros.length; i++)
/* 181:    */       {
/* 182:164 */         String atributo = this.filtros[(i++)].toString().replace("@INNER_JOIN#", "").replace("@LEFT_JOIN#", "");
/* 183:165 */         if (atributo.indexOf(".") > 0)
/* 184:    */         {
/* 185:166 */           String[] relacionamentos = atributo.split("\\.");
/* 186:167 */           for (int y = 0; y < relacionamentos.length; y++)
/* 187:    */           {
/* 188:168 */             if (y == 0) {
/* 189:169 */               atributo = "main_" + relacionamentos[y];
/* 190:    */             }
/* 191:171 */             if ((y > 0) && (y < relacionamentos.length - 1)) {
/* 192:172 */               atributo = atributo + "_" + relacionamentos[y];
/* 193:    */             }
/* 194:174 */             if (y == relacionamentos.length - 1) {
/* 195:175 */               atributo = atributo + "." + relacionamentos[y];
/* 196:    */             }
/* 197:    */           }
/* 198:    */         }
/* 199:    */         else
/* 200:    */         {
/* 201:179 */           atributo = "main." + atributo.replace("@INNER_JOIN#", "").replace("@LEFT_JOIN#", "");
/* 202:    */         }
/* 203:181 */         mapAtributos.put(atributo, this.filtros[i]);
/* 204:    */       }
/* 205:    */     }
/* 206:185 */     return mapAtributos;
/* 207:    */   }
/* 208:    */   
/* 209:    */   private void aplicandoFiltros(Criteria criteria)
/* 210:    */     throws Exception
/* 211:    */   {
/* 212:189 */     Map<String, Object> mapAtributos = aplicandoFiltrosBase(criteria);
/* 213:190 */     Set setAtributos = mapAtributos.entrySet();
/* 214:191 */     Iterator iteratorSetAtributos = setAtributos.iterator();
/* 215:192 */     while (iteratorSetAtributos.hasNext())
/* 216:    */     {
/* 217:193 */       Map.Entry atributoFinal = (Map.Entry)iteratorSetAtributos.next();
/* 218:194 */       if (atributoFinal.getValue() != null) {
/* 219:195 */         criteria.add(Restrictions.eq(atributoFinal.getKey().toString(), atributoFinal.getValue()));
/* 220:    */       } else {
/* 221:197 */         criteria.add(Restrictions.isNull(atributoFinal.getKey().toString()));
/* 222:    */       }
/* 223:    */     }
/* 224:    */   }
/* 225:    */   
/* 226:    */   private void aplicarApenasAtributosClasseMain(boolean apenasAtributosClasseMain, Criteria criteria)
/* 227:    */   {
/* 228:203 */     if (apenasAtributosClasseMain)
/* 229:    */     {
/* 230:205 */       Map<String, String> atributosClasseMain = new HashMap();
/* 231:206 */       atributosClasseMain.put("main.id", "id");
/* 232:207 */       Field[] fields = this.tClass.getDeclaredFields();
/* 233:208 */       for (Field field : fields) {
/* 234:209 */         if ((!field.getType().getSuperclass().equals(Persistivel.class)) && (field.getModifiers() == 2)) {
/* 235:211 */           atributosClasseMain.put("main." + field.getName(), field.getName());
/* 236:    */         }
/* 237:    */       }
/* 238:215 */       Set setAtributosClasseMain = atributosClasseMain.entrySet();
/* 239:216 */       Iterator iteratorSetAtributosClasseMain = setAtributosClasseMain.iterator();
/* 240:217 */       ProjectionList projectionList = Projections.projectionList();
/* 241:218 */       while (iteratorSetAtributosClasseMain.hasNext())
/* 242:    */       {
/* 243:219 */         Map.Entry atributoFinal = (Map.Entry)iteratorSetAtributosClasseMain.next();
/* 244:220 */         projectionList.add(Projections.property(atributoFinal.getKey().toString()).as(atributoFinal.getValue().toString()));
/* 245:    */       }
/* 246:222 */       criteria.setProjection(projectionList).setResultTransformer(new AliasToBeanResultTransformer(this.tClass));
/* 247:    */     }
/* 248:    */   }
/* 249:    */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.hibernate.UtilConsultaCriteria
 * JD-Core Version:    0.7.0.1
 */