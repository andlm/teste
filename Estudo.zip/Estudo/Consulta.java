/*   1:    */ package br.com.virtuoso.prosaude.utils.hibernate;
/*   2:    */ 
/*   3:    */ import br.com.virtuoso.prosaude.utils.UtilCast;
/*   4:    */ import br.com.virtuoso.prosaude.utils.UtilData;
/*   5:    */ import br.com.virtuoso.prosaude.utils.UtilLista;
/*   6:    */ import br.com.virtuoso.prosaude.utils.UtilReflexao;
/*   7:    */ import br.com.virtuoso.prosaude.utils.UtilString;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Date;
/*  12:    */ import java.util.LinkedHashMap;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.Map;
/*  15:    */ import org.apache.commons.lang.ArrayUtils;
/*  16:    */ import org.apache.commons.lang.StringUtils;
/*  17:    */ import org.hibernate.Query;
/*  18:    */ import org.hibernate.Session;
/*  19:    */ 
/*  20:    */ public class Consulta
/*  21:    */ {
/*  22: 26 */   public Boolean isWrite = Boolean.valueOf(false);
/*  23: 27 */   public static String SEPARADOR_ITERATOR = "@_@";
/*  24:    */   private Session session;
/*  25:    */   private List<String> selectBackup;
/*  26:    */   private List<String> selectCount;
/*  27:    */   private List<String> select;
/*  28:    */   private Map<String, String> from;
/*  29:    */   private Map<String, String> join;
/*  30:    */   private WhereAndOrHQL whereAndOrHQLAtual;
/*  31:    */   private List<String> group;
/*  32:    */   private WhereAndOrHQL havingAndOrHQLAtual;
/*  33:    */   private List<String> order;
/*  34:    */   private Pilha pilhaWhereAndOrHQL;
/*  35:    */   private Pilha pilhaHavingAndOrHQL;
/*  36:    */   private Integer firstResult;
/*  37:    */   private Integer maxResults;
/*  38:    */   private Boolean distinct;
/*  39:    */   private Boolean selectMap;
/*  40:    */   private Boolean isIterator;
/*  41:    */   
/*  42:    */   public Consulta(Session session)
/*  43:    */   {
/*  44: 47 */     this.session = session;
/*  45: 48 */     this.pilhaWhereAndOrHQL = new Pilha();
/*  46: 49 */     this.pilhaHavingAndOrHQL = new Pilha();
/*  47: 50 */     this.select = new ArrayList(2);
/*  48: 51 */     this.from = new LinkedHashMap(2);
/*  49: 52 */     this.join = new LinkedHashMap(2);
/*  50: 53 */     this.group = new ArrayList(2);
/*  51: 54 */     this.order = new ArrayList(2);
/*  52: 55 */     this.distinct = Boolean.valueOf(false);
/*  53: 56 */     this.selectMap = Boolean.valueOf(false);
/*  54: 57 */     whereIniciarAND();
/*  55: 58 */     havingIniciarAND();
/*  56: 59 */     this.selectCount = new ArrayList(1);
/*  57: 60 */     this.selectCount.add("count(*)");
/*  58: 61 */     this.isIterator = Boolean.valueOf(false);
/*  59: 62 */     this.firstResult = Integer.valueOf(0);
/*  60: 63 */     this.maxResults = Integer.valueOf(0);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void selectSetMap(Boolean selectMap)
/*  64:    */   {
/*  65: 67 */     this.selectMap = selectMap;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void selectAddAtributo(String atributo)
/*  69:    */   {
/*  70: 71 */     this.select.add(atributo);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void fromAddClasse(String classe, String label)
/*  74:    */   {
/*  75: 75 */     this.from.put(label, classe + " " + label);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void fromAddClasse(Class classe, String label)
/*  79:    */   {
/*  80: 79 */     fromAddClasse(UtilReflexao.getNomeClasse(classe), label);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void fromAddClasse(Class classe)
/*  84:    */   {
/*  85: 83 */     fromAddClasse(classe, "main");
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void fromAddJoin(String atributo, String label)
/*  89:    */   {
/*  90: 87 */     this.join.put(label, " JOIN " + atributo + " " + label);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void fromAddLeftJoin(String atributo, String label)
/*  94:    */   {
/*  95: 91 */     this.join.put(label, " LEFT JOIN " + atributo + " " + label);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void fromAddJoinWithIgual(String atributo, String label, String atributoWith, Object valueWith)
/*  99:    */   {
/* 100: 95 */     fromAddJoinWith(atributo, label, atributoWith, valueWith, WhereHQL.IGUAL);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void fromAddLeftJoinWithIgual(String atributo, String label, String atributoWith, Object valueWith)
/* 104:    */   {
/* 105: 99 */     fromAddLeftJoinWith(atributo, label, atributoWith, valueWith, WhereHQL.IGUAL);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void fromAddJoinWith(String atributo, String label, String atributoWith, Object value, String operadorLogico)
/* 109:    */   {
/* 110:103 */     String valorJoin = " JOIN " + atributo + " " + label + " WITH " + atributoWith + " " + operadorLogico + " " + value;
/* 111:104 */     this.join.put(label, valorJoin);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void fromAddLeftJoinWith(String atributo, String label, String atributoWith, Object value, String operadorLogico)
/* 115:    */   {
/* 116:108 */     String valorJoin = " LEFT JOIN " + atributo + " " + label + " WITH " + atributoWith + " " + operadorLogico + " " + value;
/* 117:109 */     this.join.put(label, valorJoin);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void groupAddAtributo(String atributo)
/* 121:    */   {
/* 122:113 */     this.group.add(atributo);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void orderAdd(String atributo)
/* 126:    */   {
/* 127:117 */     this.order.add(atributo);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void orderAddDESC(String atributo)
/* 131:    */   {
/* 132:121 */     this.order.add(atributo + " DESC");
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void whereAddMaior(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 136:    */   {
/* 137:125 */     whereAdd(atributo, valor, WhereHQL.MAIOR, valorEhOutroAtributo);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public void whereAddMaior(String atributo, Object valor)
/* 141:    */   {
/* 142:129 */     whereAddMaior(atributo, valor, Boolean.valueOf(false));
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void whereAddMaiorIgual(String atributo, Object valor)
/* 146:    */   {
/* 147:133 */     whereAdd(atributo, valor, WhereHQL.MAIOR_IGUAL);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public void whereAddMaiorIgual(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 151:    */   {
/* 152:137 */     whereAdd(atributo, valor, WhereHQL.MAIOR_IGUAL, valorEhOutroAtributo);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void whereAddMenor(String atributo, Object valor)
/* 156:    */   {
/* 157:141 */     whereAdd(atributo, valor, WhereHQL.MENOR);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public void whereAddMenor(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 161:    */   {
/* 162:145 */     whereAdd(atributo, valor, WhereHQL.MENOR, valorEhOutroAtributo);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public void whereAddMenor(String atributo, Consulta consulta)
/* 166:    */   {
/* 167:149 */     whereAddMenor(atributo, consulta, Boolean.valueOf(true));
/* 168:    */   }
/* 169:    */   
/* 170:    */   public void whereAddMenorIgual(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 171:    */   {
/* 172:153 */     whereAdd(atributo, valor, WhereHQL.MENOR_IGUAL, valorEhOutroAtributo);
/* 173:    */   }
/* 174:    */   
/* 175:    */   public void whereAddMenorIgual(String atributo, Object valor)
/* 176:    */   {
/* 177:157 */     whereAddMenorIgual(atributo, valor, Boolean.valueOf(false));
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void whereAddMenorIgual(String atributo, Consulta consulta)
/* 181:    */   {
/* 182:161 */     whereAddMenorIgual(atributo, consulta, Boolean.valueOf(true));
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void whereAddIgual(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 186:    */   {
/* 187:165 */     whereAdd(atributo, valor, WhereHQL.IGUAL, valorEhOutroAtributo);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public void whereAddIgual(String atributo, Object valor)
/* 191:    */   {
/* 192:169 */     whereAdd(atributo, valor, WhereHQL.IGUAL);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void whereAddIgualBranco(String atributo)
/* 196:    */   {
/* 197:173 */     whereAdd(atributo, "", WhereHQL.IGUAL, Boolean.FALSE, Boolean.TRUE);
/* 198:    */   }
/* 199:    */   
/* 200:    */   public void whereAddIgualDia(String atributo, Object valor)
/* 201:    */   {
/* 202:177 */     whereAddEntre(atributo, UtilData.zerarHora((Date)valor), UtilData.setUltimaHora((Date)valor));
/* 203:    */   }
/* 204:    */   
/* 205:    */   public void whereAddDiferente(String atributo, Object valor)
/* 206:    */   {
/* 207:181 */     whereAdd(atributo, valor, WhereHQL.DIFERENTE);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public void whereAddDiferente(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 211:    */   {
/* 212:185 */     whereAdd(atributo, valor, WhereHQL.DIFERENTE, valorEhOutroAtributo);
/* 213:    */   }
/* 214:    */   
/* 215:    */   public void whereAddDiferenteBranco(String atributo)
/* 216:    */   {
/* 217:189 */     whereAdd(atributo, "", WhereHQL.DIFERENTE, Boolean.FALSE, Boolean.TRUE);
/* 218:    */   }
/* 219:    */   
/* 220:    */   public void whereAddLike(String atributo, Object valor)
/* 221:    */   {
/* 222:193 */     whereAdd(atributo, valor, WhereHQL.LIKE);
/* 223:    */   }
/* 224:    */   
/* 225:    */   public void whereAddLike(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 226:    */   {
/* 227:197 */     whereAdd(atributo, valor, WhereHQL.LIKE, valorEhOutroAtributo);
/* 228:    */   }
/* 229:    */   
/* 230:    */   public void whereAddLikeSemAcentos(String atributo, String valor)
/* 231:    */   {
/* 232:201 */     whereAddSemAcentos(atributo, valor, WhereHQL.LIKE);
/* 233:    */   }
/* 234:    */   
/* 235:    */   public void whereAddLikeBoth(String atributo, Object valor)
/* 236:    */   {
/* 237:205 */     whereAdd(atributo, valor, WhereHQL.LIKE_BOTH);
/* 238:    */   }
/* 239:    */   
/* 240:    */   public void whereAddLikeBothSemAcentos(String atributo, String valor)
/* 241:    */   {
/* 242:209 */     whereAddSemAcentos(atributo, valor, WhereHQL.LIKE_BOTH);
/* 243:    */   }
/* 244:    */   
/* 245:    */   public void whereAddLikeLeft(String atributo, Object valor)
/* 246:    */   {
/* 247:213 */     whereAdd(atributo, valor, WhereHQL.LIKE_LEFT);
/* 248:    */   }
/* 249:    */   
/* 250:    */   public void whereAddLikeLeft(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 251:    */   {
/* 252:217 */     whereAdd(atributo, "'%'||" + valor, WhereHQL.LIKE, valorEhOutroAtributo);
/* 253:    */   }
/* 254:    */   
/* 255:    */   public void whereAddLikeRight(String atributo, Object valor)
/* 256:    */   {
/* 257:221 */     whereAdd(atributo, valor, WhereHQL.LIKE_RIGHT);
/* 258:    */   }
/* 259:    */   
/* 260:    */   public void whereAddLikeRight(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 261:    */   {
/* 262:225 */     whereAdd(atributo, valor + "||'%'", WhereHQL.LIKE, valorEhOutroAtributo);
/* 263:    */   }
/* 264:    */   
/* 265:    */   public void whereAddLikeBoth(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 266:    */   {
/* 267:229 */     whereAdd(atributo, "'%' ||" + valor + "||'%'", WhereHQL.LIKE, valorEhOutroAtributo);
/* 268:    */   }
/* 269:    */   
/* 270:    */   public void whereAddEntre(String atributo, Object valorInicio, Object valorFim)
/* 271:    */   {
/* 272:233 */     whereAddMaiorIgual(atributo, valorInicio);
/* 273:234 */     whereAddMenorIgual(atributo, valorFim);
/* 274:    */   }
/* 275:    */   
/* 276:    */   public void whereAddEntre(String atributo, Object valorInicio, Object valorFim, Boolean valorEhOutroAtributo1, Boolean valorEhOutroAtributo2)
/* 277:    */   {
/* 278:239 */     whereAddMaiorIgual(atributo, valorInicio, valorEhOutroAtributo1);
/* 279:240 */     whereAddMenorIgual(atributo, valorFim, valorEhOutroAtributo2);
/* 280:    */   }
/* 281:    */   
/* 282:    */   public void whereAddIn(String atributo, Object valor)
/* 283:    */   {
/* 284:244 */     whereAdd(atributo, valor, WhereHQL.IN);
/* 285:    */   }
/* 286:    */   
/* 287:    */   public void whereAddInWithParameters(String atributo, Object... valor)
/* 288:    */   {
/* 289:248 */     whereAdd(atributo, valor, WhereHQL.IN);
/* 290:    */   }
/* 291:    */   
/* 292:    */   public void whereAddNotIn(String atributo, Object valor)
/* 293:    */   {
/* 294:252 */     whereAdd(atributo, valor, WhereHQL.NOT_IN);
/* 295:    */   }
/* 296:    */   
/* 297:    */   public void whereAddIsNull(String atributo)
/* 298:    */   {
/* 299:256 */     whereAdd(atributo, WhereHQL.IS_NULL);
/* 300:    */   }
/* 301:    */   
/* 302:    */   public void whereAddIsNotNull(String atributo)
/* 303:    */   {
/* 304:260 */     whereAdd(atributo, WhereHQL.IS_NOT_NULL);
/* 305:    */   }
/* 306:    */   
/* 307:    */   public void whereAddExists(Consulta consulta)
/* 308:    */   {
/* 309:264 */     whereAdd("", consulta, WhereHQL.EXISTS, Boolean.valueOf(true));
/* 310:    */   }
/* 311:    */   
/* 312:    */   public void whereAddIgual(String atributo, Consulta consulta)
/* 313:    */   {
/* 314:268 */     whereAdd(atributo, consulta, WhereHQL.IGUAL, Boolean.valueOf(true));
/* 315:    */   }
/* 316:    */   
/* 317:    */   public void whereAddNotExists(Consulta consulta)
/* 318:    */   {
/* 319:272 */     whereAdd("", consulta, WhereHQL.NOT_EXISTS, Boolean.valueOf(true));
/* 320:    */   }
/* 321:    */   
/* 322:    */   public void whereAdd(String atributo, Object valor, String operadorLogico)
/* 323:    */   {
/* 324:276 */     whereAdd(atributo, valor, operadorLogico, Boolean.valueOf(false));
/* 325:    */   }
/* 326:    */   
/* 327:    */   public void whereAddSemAcentos(String atributo, Object valor, String operadorLogico)
/* 328:    */   {
/* 329:280 */     atributo = "sem_acentos(trim(lower(cast(" + atributo + " as string))))";
/* 330:281 */     valor = UtilString.retirarAcentos(valor.toString()).toLowerCase().trim();
/* 331:282 */     whereAdd(atributo, valor, operadorLogico, Boolean.valueOf(false));
/* 332:    */   }
/* 333:    */   
/* 334:    */   public void whereAdd(String atributo, Object valor, String operadorLogico, Boolean valorEhOutroAtributo)
/* 335:    */   {
/* 336:286 */     whereAdd(atributo, valor, operadorLogico, valorEhOutroAtributo, Boolean.FALSE);
/* 337:    */   }
/* 338:    */   
/* 339:    */   public void whereAdd(String atributo, Object valor, String operadorLogico, Boolean valorEhOutroAtributo, Boolean flPermitirBranco)
/* 340:    */   {
/* 341:290 */     if ((valor == null) || ((valor.toString().equals("")) && (!flPermitirBranco.booleanValue()))) {
/* 342:291 */       return;
/* 343:    */     }
/* 344:293 */     if (((valor instanceof Collection)) && (((Collection)valor).isEmpty())) {
/* 345:294 */       return;
/* 346:    */     }
/* 347:296 */     if (operadorLogico.equals(WhereHQL.LIKE_BOTH)) {
/* 348:297 */       valor = "%" + valor + "%";
/* 349:298 */     } else if (operadorLogico.equals(WhereHQL.LIKE_LEFT)) {
/* 350:299 */       valor = "%" + valor;
/* 351:300 */     } else if (operadorLogico.equals(WhereHQL.LIKE_RIGHT)) {
/* 352:301 */       valor = valor + "%";
/* 353:    */     }
/* 354:303 */     if (operadorLogico.startsWith(WhereHQL.LIKE)) {
/* 355:304 */       operadorLogico = WhereHQL.LIKE;
/* 356:    */     }
/* 357:306 */     this.whereAndOrHQLAtual.add(new WhereHQL(atributo, valor, operadorLogico, valorEhOutroAtributo));
/* 358:    */   }
/* 359:    */   
/* 360:    */   private void whereAdd(String atributo, String operadorLogico)
/* 361:    */   {
/* 362:310 */     this.whereAndOrHQLAtual.add(new WhereHQL(atributo, operadorLogico));
/* 363:    */   }
/* 364:    */   
/* 365:    */   public void whereIniciarOR()
/* 366:    */   {
/* 367:314 */     whereIniciarANDOR(WhereAndOrHQL.OR);
/* 368:    */   }
/* 369:    */   
/* 370:    */   public void whereIniciarAND()
/* 371:    */   {
/* 372:318 */     whereIniciarANDOR(WhereAndOrHQL.AND);
/* 373:    */   }
/* 374:    */   
/* 375:    */   private void whereIniciarANDOR(String operadorBooleano)
/* 376:    */   {
/* 377:322 */     WhereAndOrHQL whereAndOrHQL = new WhereAndOrHQL(operadorBooleano);
/* 378:323 */     if (this.whereAndOrHQLAtual != null) {
/* 379:324 */       this.whereAndOrHQLAtual.add(whereAndOrHQL);
/* 380:    */     }
/* 381:326 */     this.pilhaWhereAndOrHQL.insere(whereAndOrHQL);
/* 382:327 */     this.whereAndOrHQLAtual = whereAndOrHQL;
/* 383:    */   }
/* 384:    */   
/* 385:    */   public void whereFinalizarANDOR()
/* 386:    */   {
/* 387:331 */     WhereAndOrHQL whereAndOrHQL = (WhereAndOrHQL)this.pilhaWhereAndOrHQL.retira();
/* 388:332 */     this.whereAndOrHQLAtual = ((WhereAndOrHQL)this.pilhaWhereAndOrHQL.get());
/* 389:333 */     if (whereAndOrHQL.isEmpty().booleanValue()) {
/* 390:334 */       this.whereAndOrHQLAtual.remove(whereAndOrHQL);
/* 391:    */     }
/* 392:    */   }
/* 393:    */   
/* 394:    */   public void havingAddMaior(String atributo, Object valor)
/* 395:    */   {
/* 396:339 */     havingAdd(atributo, valor, WhereHQL.MAIOR);
/* 397:    */   }
/* 398:    */   
/* 399:    */   public void havingAddMaior(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 400:    */   {
/* 401:343 */     havingAdd(atributo, valor, WhereHQL.MAIOR, valorEhOutroAtributo);
/* 402:    */   }
/* 403:    */   
/* 404:    */   public void havingAddMaiorIgual(String atributo, Object valor)
/* 405:    */   {
/* 406:347 */     havingAdd(atributo, valor, WhereHQL.MAIOR_IGUAL);
/* 407:    */   }
/* 408:    */   
/* 409:    */   public void havingAddMenor(String atributo, Object valor)
/* 410:    */   {
/* 411:351 */     havingAdd(atributo, valor, WhereHQL.MENOR);
/* 412:    */   }
/* 413:    */   
/* 414:    */   public void havingAddMenor(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 415:    */   {
/* 416:355 */     havingAdd(atributo, valor, WhereHQL.MENOR, valorEhOutroAtributo);
/* 417:    */   }
/* 418:    */   
/* 419:    */   public void havingAddMenorIgual(String atributo, Object valor)
/* 420:    */   {
/* 421:359 */     havingAdd(atributo, valor, WhereHQL.MENOR_IGUAL);
/* 422:    */   }
/* 423:    */   
/* 424:    */   public void havingAddIgual(String atributo, Object valor)
/* 425:    */   {
/* 426:363 */     havingAdd(atributo, valor, WhereHQL.IGUAL);
/* 427:    */   }
/* 428:    */   
/* 429:    */   public void havingAddDiferente(String atributo, Object valor)
/* 430:    */   {
/* 431:367 */     havingAddDiferente(atributo, valor, Boolean.valueOf(false));
/* 432:    */   }
/* 433:    */   
/* 434:    */   public void havingAddDiferente(String atributo, Object valor, Boolean valorEhOutroAtributo)
/* 435:    */   {
/* 436:371 */     havingAdd(atributo, valor, WhereHQL.DIFERENTE, valorEhOutroAtributo);
/* 437:    */   }
/* 438:    */   
/* 439:    */   public void havingAddEntre(String atributo, Object valorInicio, Object valorFim)
/* 440:    */   {
/* 441:375 */     havingAddMaiorIgual(atributo, valorInicio);
/* 442:376 */     havingAddMenorIgual(atributo, valorFim);
/* 443:    */   }
/* 444:    */   
/* 445:    */   public void havingAddIn(String atributo, Object valor)
/* 446:    */   {
/* 447:380 */     havingAdd(atributo, valor, WhereHQL.IN);
/* 448:    */   }
/* 449:    */   
/* 450:    */   public void havingAddNotIn(String atributo, Object valor)
/* 451:    */   {
/* 452:384 */     havingAdd(atributo, valor, WhereHQL.NOT_IN);
/* 453:    */   }
/* 454:    */   
/* 455:    */   public void havingAddIsNull(String atributo)
/* 456:    */   {
/* 457:388 */     havingAdd(atributo, WhereHQL.IS_NULL);
/* 458:    */   }
/* 459:    */   
/* 460:    */   public void havingAddIsNotNull(String atributo)
/* 461:    */   {
/* 462:392 */     havingAdd(atributo, WhereHQL.IS_NOT_NULL);
/* 463:    */   }
/* 464:    */   
/* 465:    */   public void havingAdd(String atributo)
/* 466:    */   {
/* 467:396 */     havingAdd(atributo, null);
/* 468:    */   }
/* 469:    */   
/* 470:    */   private void havingAdd(String atributo, Object valor, String operadorLogico)
/* 471:    */   {
/* 472:400 */     havingAdd(atributo, valor, operadorLogico, Boolean.valueOf(false));
/* 473:    */   }
/* 474:    */   
/* 475:    */   private void havingAdd(String atributo, String operadorLogico)
/* 476:    */   {
/* 477:404 */     this.havingAndOrHQLAtual.add(new WhereHQL(atributo, operadorLogico));
/* 478:    */   }
/* 479:    */   
/* 480:    */   private void havingAdd(String atributo, Object valor, String operadorLogico, Boolean valorEhOutroAtributo)
/* 481:    */   {
/* 482:408 */     if (valor == null) {
/* 483:409 */       return;
/* 484:    */     }
/* 485:411 */     this.havingAndOrHQLAtual.add(new WhereHQL(atributo, valor, operadorLogico, valorEhOutroAtributo));
/* 486:    */   }
/* 487:    */   
/* 488:    */   public void havingIniciarOR()
/* 489:    */   {
/* 490:415 */     havingIniciarANDOR(WhereAndOrHQL.OR);
/* 491:    */   }
/* 492:    */   
/* 493:    */   public void havingIniciarAND()
/* 494:    */   {
/* 495:419 */     havingIniciarANDOR(WhereAndOrHQL.AND);
/* 496:    */   }
/* 497:    */   
/* 498:    */   private void havingIniciarANDOR(String operadorBooleano)
/* 499:    */   {
/* 500:423 */     WhereAndOrHQL havingAndOrHQL = new WhereAndOrHQL(operadorBooleano);
/* 501:424 */     if (this.havingAndOrHQLAtual != null) {
/* 502:425 */       this.havingAndOrHQLAtual.add(havingAndOrHQL);
/* 503:    */     }
/* 504:427 */     this.pilhaHavingAndOrHQL.insere(havingAndOrHQL);
/* 505:428 */     this.havingAndOrHQLAtual = havingAndOrHQL;
/* 506:    */   }
/* 507:    */   
/* 508:    */   public void havingFinalizarANDOR()
/* 509:    */   {
/* 510:432 */     WhereAndOrHQL havingAndOrHQL = (WhereAndOrHQL)this.pilhaHavingAndOrHQL.retira();
/* 511:433 */     this.havingAndOrHQLAtual = ((WhereAndOrHQL)this.pilhaHavingAndOrHQL.get());
/* 512:434 */     if (havingAndOrHQL.isEmpty().booleanValue()) {
/* 513:435 */       this.havingAndOrHQLAtual.remove(havingAndOrHQL);
/* 514:    */     }
/* 515:    */   }
/* 516:    */   
/* 517:    */   public Integer getFirstResult()
/* 518:    */   {
/* 519:440 */     return this.firstResult;
/* 520:    */   }
/* 521:    */   
/* 522:    */   public void setFirstResult(Integer firstResult)
/* 523:    */   {
/* 524:444 */     this.firstResult = firstResult;
/* 525:    */   }
/* 526:    */   
/* 527:    */   public Integer getMaxResults()
/* 528:    */   {
/* 529:448 */     return this.maxResults;
/* 530:    */   }
/* 531:    */   
/* 532:    */   public void setMaxResults(Integer maxResults)
/* 533:    */   {
/* 534:452 */     this.maxResults = maxResults;
/* 535:    */   }
/* 536:    */   
/* 537:    */   public Query getQuery()
/* 538:    */     throws Exception
/* 539:    */   {
/* 540:456 */     StringBuffer hql = new StringBuffer();
/* 541:457 */     ProSaudeMap proSaudeMap = getHql(hql, Integer.valueOf(0));
/* 542:458 */     if ((proSaudeMap != null) && (proSaudeMap.size() != 0)) {
/* 543:459 */       System.err.println(proSaudeMap);
/* 544:    */     }
/* 545:462 */     Query query = this.session.createQuery(hql.toString());
/* 546:463 */     if (this.maxResults.intValue() > 0) {
/* 547:464 */       query.setMaxResults(this.maxResults.intValue());
/* 548:    */     }
/* 549:466 */     if (this.firstResult.intValue() > 0) {
/* 550:467 */       query.setFirstResult(this.firstResult.intValue());
/* 551:    */     }
/* 552:469 */     for (Object chave : proSaudeMap.keySet())
/* 553:    */     {
/* 554:470 */       Object valor = proSaudeMap.get(chave);
/* 555:471 */       if ((valor instanceof Collection)) {
/* 556:472 */         query.setParameterList(chave.toString(), (Collection)valor);
/* 557:473 */       } else if ((valor instanceof Object[])) {
/* 558:474 */         query.setParameterList(chave.toString(), (Object[])valor);
/* 559:    */       } else {
/* 560:476 */         query.setParameter(chave.toString(), valor);
/* 561:    */       }
/* 562:478 */       if (this.isWrite.booleanValue()) {
/* 563:479 */         if ((valor instanceof Object[])) {
/* 564:480 */           System.out.print(chave + "=" + ArrayUtils.toString(valor) + ";");
/* 565:    */         } else {
/* 566:482 */           System.out.print(chave + "=" + valor + ";");
/* 567:    */         }
/* 568:    */       }
/* 569:    */     }
/* 570:486 */     if (this.isWrite.booleanValue()) {
/* 571:487 */       System.out.println("");
/* 572:    */     }
/* 573:489 */     return query;
/* 574:    */   }
/* 575:    */   
/* 576:    */   public String getHql()
/* 577:    */   {
/* 578:493 */     return getHql(Integer.valueOf(0));
/* 579:    */   }
/* 580:    */   
/* 581:    */   public String getHql(Integer offset)
/* 582:    */   {
/* 583:497 */     StringBuffer hql = new StringBuffer();
/* 584:498 */     getHql(hql, offset);
/* 585:499 */     return hql.toString();
/* 586:    */   }
/* 587:    */   
/* 588:    */   public void whereLimpar()
/* 589:    */   {
/* 590:503 */     this.pilhaWhereAndOrHQL.limpar();
/* 591:504 */     this.whereAndOrHQLAtual = null;
/* 592:505 */     whereIniciarAND();
/* 593:    */   }
/* 594:    */   
/* 595:    */   public ProSaudeMap getHql(StringBuffer hql, Integer offset)
/* 596:    */   {
/* 597:509 */     ProSaudeMap mapSet = new ProSaudeMap();
/* 598:510 */     adicionarParteHql(hql, "SELECT", this.select);
/* 599:511 */     adicionarParteHql(hql, "FROM", this.from.values());
/* 600:512 */     adicionarParteHqlJoin(hql, this.join);
/* 601:514 */     if (!this.whereAndOrHQLAtual.isEmpty().booleanValue())
/* 602:    */     {
/* 603:515 */       hql.append("WHERE ");
/* 604:516 */       mapSet.putAll(this.whereAndOrHQLAtual.gerarHql(hql, offset));
/* 605:    */     }
/* 606:519 */     adicionarParteHql(hql, " GROUP BY", this.group);
/* 607:521 */     if (!this.havingAndOrHQLAtual.isEmpty().booleanValue())
/* 608:    */     {
/* 609:522 */       hql.append("HAVING ");
/* 610:523 */       this.havingAndOrHQLAtual.gerarHql(hql, offset, mapSet);
/* 611:    */     }
/* 612:526 */     adicionarParteHql(hql, " ORDER BY", this.order);
/* 613:527 */     return mapSet;
/* 614:    */   }
/* 615:    */   
/* 616:    */   private void adicionarParteHql(StringBuffer hql, String parteHql, Collection<String> lista)
/* 617:    */   {
/* 618:531 */     if (!lista.isEmpty())
/* 619:    */     {
/* 620:532 */       Boolean isSelect = Boolean.valueOf(parteHql.equals("SELECT"));
/* 621:533 */       Boolean isSelectMap = Boolean.valueOf((isSelect.booleanValue()) && (this.selectMap.booleanValue()));
/* 622:534 */       hql.append(parteHql + " ");
/* 623:535 */       if ((isSelect.booleanValue()) && (this.distinct.booleanValue())) {
/* 624:536 */         hql.append("DISTINCT ");
/* 625:    */       }
/* 626:538 */       if (isSelectMap.booleanValue()) {
/* 627:539 */         hql.append("new map(");
/* 628:    */       }
/* 629:541 */       Boolean primeiroAtributo = Boolean.TRUE;
/* 630:542 */       for (String valor : lista)
/* 631:    */       {
/* 632:543 */         if (!primeiroAtributo.booleanValue()) {
/* 633:544 */           hql.append(" ,");
/* 634:    */         }
/* 635:546 */         primeiroAtributo = Boolean.FALSE;
/* 636:547 */         hql.append(valor + " ");
/* 637:548 */         if (isSelectMap.booleanValue())
/* 638:    */         {
/* 639:549 */           String expressao = valor;
/* 640:550 */           if (!StringUtils.contains(expressao.toLowerCase(), " as"))
/* 641:    */           {
/* 642:551 */             Integer indexLastDot = Integer.valueOf(expressao.lastIndexOf("."));
/* 643:552 */             String alias = null;
/* 644:553 */             if (indexLastDot.intValue() >= 0) {
/* 645:554 */               alias = expressao.trim().substring(indexLastDot.intValue() + 1);
/* 646:    */             } else {
/* 647:556 */               alias = expressao.trim();
/* 648:    */             }
/* 649:558 */             hql.append(" as " + alias + " ");
/* 650:    */           }
/* 651:    */         }
/* 652:    */       }
/* 653:562 */       if (isSelectMap.booleanValue()) {
/* 654:563 */         hql.append(")");
/* 655:    */       }
/* 656:    */     }
/* 657:    */   }
/* 658:    */   
/* 659:    */   private void adicionarParteHqlJoin(StringBuffer hql, Map<String, String> joins)
/* 660:    */   {
/* 661:569 */     if (!joins.isEmpty())
/* 662:    */     {
/* 663:570 */       List<String> joinsAdicionados = new ArrayList();
/* 664:571 */       for (String join : joins.values()) {
/* 665:572 */         adicionarJoinOrdenado(join, joinsAdicionados, joins);
/* 666:    */       }
/* 667:574 */       hql.append(UtilLista.toString(joinsAdicionados, " ")).append(" ");
/* 668:    */     }
/* 669:    */   }
/* 670:    */   
/* 671:    */   private void adicionarJoinOrdenado(String join, List<String> joinsAdicionados, Map<String, String> joins)
/* 672:    */   {
/* 673:579 */     if (joinsAdicionados.contains(join)) {
/* 674:580 */       return;
/* 675:    */     }
/* 676:582 */     String parent = join.substring(join.indexOf("JOIN ") + 5, join.indexOf("."));
/* 677:583 */     String parentJoin = (String)joins.get(parent);
/* 678:584 */     if ((!joinsAdicionados.contains(parentJoin)) && (!this.from.containsKey(parent))) {
/* 679:585 */       adicionarJoinOrdenado(parentJoin, joinsAdicionados, joins);
/* 680:    */     }
/* 681:587 */     joinsAdicionados.add(join);
/* 682:    */   }
/* 683:    */   
/* 684:    */   public void limparSelect()
/* 685:    */   {
/* 686:591 */     this.select.clear();
/* 687:    */   }
/* 688:    */   
/* 689:    */   public void limparOrderBy()
/* 690:    */   {
/* 691:595 */     this.order.clear();
/* 692:    */   }
/* 693:    */   
/* 694:    */   public void limparGroupBy()
/* 695:    */   {
/* 696:599 */     this.group.clear();
/* 697:    */   }
/* 698:    */   
/* 699:    */   public Boolean possuiWhere()
/* 700:    */   {
/* 701:603 */     return Boolean.valueOf(!this.whereAndOrHQLAtual.isEmpty().booleanValue());
/* 702:    */   }
/* 703:    */   
/* 704:    */   public Boolean idDistinct()
/* 705:    */   {
/* 706:607 */     return this.distinct;
/* 707:    */   }
/* 708:    */   
/* 709:    */   public void setDistinct(Boolean distinct)
/* 710:    */   {
/* 711:611 */     this.distinct = distinct;
/* 712:    */   }
/* 713:    */   
/* 714:    */   public void setDistinct(Boolean distinct, String distinctAtributo)
/* 715:    */   {
/* 716:615 */     this.distinct = distinct;
/* 717:616 */     this.selectCount.clear();
/* 718:617 */     this.selectCount.add("count(distinct " + distinctAtributo + ")");
/* 719:    */   }
/* 720:    */   
/* 721:    */   public Integer getCount(String nmAtributoDistinct)
/* 722:    */     throws Exception
/* 723:    */   {
/* 724:621 */     this.selectCount.clear();
/* 725:622 */     if (nmAtributoDistinct == null) {
/* 726:623 */       this.selectCount.add("count(*)");
/* 727:    */     } else {
/* 728:625 */       this.selectCount.add("count(distinct " + nmAtributoDistinct + ")");
/* 729:    */     }
/* 730:627 */     Integer firstResultTemp = this.firstResult;
/* 731:628 */     Integer maxResultsTemp = this.maxResults;
/* 732:629 */     List orderTemp = this.order;
/* 733:630 */     Boolean selectMapTemp = this.selectMap;
/* 734:631 */     this.selectMap = Boolean.valueOf(false);
/* 735:632 */     this.firstResult = null;
/* 736:633 */     this.maxResults = null;
/* 737:634 */     this.order = new ArrayList(2);
/* 738:635 */     List selectTemp = this.select;
/* 739:636 */     Number retorno = null;
/* 740:637 */     if (!this.group.isEmpty())
/* 741:    */     {
/* 742:638 */       retorno = Integer.valueOf(getQuery().list().size());
/* 743:    */     }
/* 744:    */     else
/* 745:    */     {
/* 746:640 */       this.select = this.selectCount;
/* 747:641 */       retorno = (Number)getQuery().uniqueResult();
/* 748:    */     }
/* 749:643 */     this.select = selectTemp;
/* 750:644 */     this.firstResult = firstResultTemp;
/* 751:645 */     this.maxResults = maxResultsTemp;
/* 752:646 */     this.order = orderTemp;
/* 753:647 */     this.selectMap = selectMapTemp;
/* 754:648 */     return Integer.valueOf(retorno.intValue());
/* 755:    */   }
/* 756:    */   
/* 757:    */   public Integer getCount()
/* 758:    */     throws Exception
/* 759:    */   {
/* 760:652 */     Integer firstResultTemp = this.firstResult;
/* 761:653 */     Integer maxResultsTemp = this.maxResults;
/* 762:654 */     List orderTemp = this.order;
/* 763:655 */     this.firstResult = null;
/* 764:656 */     this.maxResults = null;
/* 765:657 */     this.order = new ArrayList(2);
/* 766:658 */     List selectTemp = this.select;
/* 767:659 */     Number retorno = null;
/* 768:660 */     if (!this.group.isEmpty())
/* 769:    */     {
/* 770:661 */       retorno = Integer.valueOf(getQuery().list().size());
/* 771:    */     }
/* 772:    */     else
/* 773:    */     {
/* 774:663 */       this.select = this.selectCount;
/* 775:664 */       retorno = (Number)getQuery().uniqueResult();
/* 776:    */     }
/* 777:666 */     this.select = selectTemp;
/* 778:667 */     this.firstResult = firstResultTemp;
/* 779:668 */     this.maxResults = maxResultsTemp;
/* 780:669 */     this.order = orderTemp;
/* 781:670 */     return Integer.valueOf(retorno.intValue());
/* 782:    */   }
/* 783:    */   
/* 784:    */   public void setSession(Session session)
/* 785:    */   {
/* 786:674 */     this.session = session;
/* 787:    */   }
/* 788:    */   
/* 789:    */   public Object uniqueResult()
/* 790:    */     throws Exception
/* 791:    */   {
/* 792:678 */     return getQuery().uniqueResult();
/* 793:    */   }
/* 794:    */   
/* 795:    */   public <T> T uniqueResultBean()
/* 796:    */     throws Exception
/* 797:    */   {
/* 798:682 */     return uniqueResult();
/* 799:    */   }
/* 800:    */   
/* 801:    */   public Long uniqueResultLong()
/* 802:    */     throws Exception
/* 803:    */   {
/* 804:686 */     Object retorno = uniqueResult();
/* 805:687 */     return UtilCast.toLong(retorno);
/* 806:    */   }
/* 807:    */   
/* 808:    */   public Integer uniqueResultInteger()
/* 809:    */     throws Exception
/* 810:    */   {
/* 811:691 */     Object retorno = uniqueResult();
/* 812:692 */     return UtilCast.toInteger(retorno);
/* 813:    */   }
/* 814:    */   
/* 815:    */   public Double uniqueResultDouble()
/* 816:    */     throws Exception
/* 817:    */   {
/* 818:696 */     Object retorno = uniqueResult();
/* 819:697 */     return UtilCast.toDoubleZeroSeNull(retorno);
/* 820:    */   }
/* 821:    */   
/* 822:    */   public List list()
/* 823:    */     throws Exception
/* 824:    */   {
/* 825:701 */     Query query = getQuery();
/* 826:702 */     List<?> retorno = query.list();
/* 827:703 */     return retorno;
/* 828:    */   }
/* 829:    */   
/* 830:    */   public void setIterator(String nmCampoControle1, String nmCampoControle2)
/* 831:    */     throws Exception
/* 832:    */   {
/* 833:707 */     removeIterator();
/* 834:708 */     String nmCampoControle = "cast(" + nmCampoControle1 + " as string) || '" + SEPARADOR_ITERATOR + "' || cast(" + nmCampoControle2 + " as string)";
/* 835:    */     
/* 836:710 */     this.select.add(0, nmCampoControle + " as iterator");
/* 837:711 */     this.order.add(0, nmCampoControle1);
/* 838:712 */     this.order.add(1, nmCampoControle2);
/* 839:713 */     this.isIterator = Boolean.valueOf(true);
/* 840:    */   }
/* 841:    */   
/* 842:    */   public void setIterator(String nmCampoControle)
/* 843:    */     throws Exception
/* 844:    */   {
/* 845:717 */     removeIterator();
/* 846:718 */     this.select.add(0, nmCampoControle + " as iterator");
/* 847:719 */     this.order.add(0, nmCampoControle);
/* 848:720 */     this.isIterator = Boolean.valueOf(true);
/* 849:    */   }
/* 850:    */   
/* 851:    */   public void removeIterator()
/* 852:    */   {
/* 853:724 */     if (!this.isIterator.booleanValue()) {
/* 854:725 */       return;
/* 855:    */     }
/* 856:727 */     String nmCampoControle = (String)this.select.remove(0);
/* 857:728 */     this.order.remove(0);
/* 858:729 */     if (nmCampoControle.matches(".*" + SEPARADOR_ITERATOR + ".*")) {
/* 859:730 */       this.order.remove(0);
/* 860:    */     }
/* 861:732 */     this.isIterator = Boolean.valueOf(false);
/* 862:    */   }
/* 863:    */   
/* 864:    */   public void writeHql()
/* 865:    */   {
/* 866:736 */     this.isWrite = Boolean.valueOf(true);
/* 867:    */     try
/* 868:    */     {
/* 869:738 */       getQuery();
/* 870:    */     }
/* 871:    */     catch (Exception e)
/* 872:    */     {
/* 873:740 */       e.printStackTrace();
/* 874:    */     }
/* 875:742 */     this.isWrite = Boolean.valueOf(false);
/* 876:    */   }
/* 877:    */   
/* 878:    */   public void backupSelect()
/* 879:    */   {
/* 880:746 */     this.selectBackup = new ArrayList(this.select);
/* 881:    */   }
/* 882:    */   
/* 883:    */   public void restoreSelect()
/* 884:    */   {
/* 885:750 */     this.select = this.selectBackup;
/* 886:    */   }
/* 887:    */   
/* 888:    */   public Boolean possuiJoin(String label)
/* 889:    */   {
/* 890:754 */     return Boolean.valueOf(this.join.containsKey(label));
/* 891:    */   }
/* 892:    */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.hibernate.Consulta
 * JD-Core Version:    0.7.0.1
 */