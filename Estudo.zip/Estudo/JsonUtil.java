package com.prosaude.sistema.util;

import android.text.TextUtils;

import com.google.gson.Gson;

public class JsonUtil {

    public static String toJSon(Object oEntidade) {
        Gson gson = new Gson();
        return gson.toJson(oEntidade);
    }

    public static Object getJson(String result, Class oEntidade) {
        Gson gson = new Gson();
        return gson.fromJson(result, oEntidade.getClass());
    }

    public static boolean IsNullOrEmptyObject(String sValor) {
        if (TextUtils.isEmpty(sValor))
            return false;
        return true;
    }
}