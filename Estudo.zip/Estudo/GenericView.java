package com.nexxera.pds.utility;

import java.io.Serializable;

import org.jboss.seam.annotations.In;
import org.jboss.seam.faces.FacesMessages;

import com.nexxera.pds.utility.paginator.UIPaginator;



public class GenericView implements Serializable {

	private static final long serialVersionUID = 1L;
	
//	@In
//	@Out(required=false)
//	protected Usuario usuarioLogado;
	
	@In("#{facesMessages}")
	protected FacesMessages messages;
	protected int index;
	protected UIPaginator paginator;
	protected CRUDController controller;

	/*
	 * Getters e Setters
	 */

	public FacesMessages getMessages() {
		return messages;
	}

	public void setMessages(FacesMessages messages) {
		this.messages = messages;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public UIPaginator getPaginator() {
		return paginator;
	}

	public void setPaginator(UIPaginator paginator) {
		this.paginator = paginator;
	}

//	public Usuario getUsuarioLogado() {
//		return usuarioLogado;
//	}
//
//	public void setUsuarioLogado(Usuario usuarioLogado) {
//		this.usuarioLogado = usuarioLogado;
//	}

	public CRUDController getController() {
		return controller;
	}

	public void setController(CRUDController controller) {
		this.controller = controller;
	}

}