package com.nexxera.pds.service.exception;

import javax.ejb.ApplicationException;

import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;

/**
 * Representa uma excessao que aconteceu na "camada" de servico, por exemplo
 * regras de negocio.
 * 
 * @author Israel Fonseca
 * 
 */
@ApplicationException(rollback = true)
public class ServiceException extends Exception {

	private static final long serialVersionUID = 1L;

	private Severity severity;
	private String message;
	private Object[] params;

	public ServiceException(Severity severity, String message, Object... params) {
		this.severity = severity;
		this.message = message;
		this.params = params;
	}

	public void addFacesMessage(){
		FacesMessages.instance().add(severity, message, params);
	}
	
	public ServiceException(String message, Object... params) {
		this(Severity.ERROR, message, params);
	}

	public String getMessage() {
		return message;
	}

	public Severity getSeverity() {
		return severity;
	}
	
	public Object[] getParams(){
		return params;
	}
}