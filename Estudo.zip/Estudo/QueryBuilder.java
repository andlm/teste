package br.medcorp.arquitetura.rest.service.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 */
public class QueryBuilder<T> {

	private final Pattern pattern = Pattern.compile(":(\\w*?)(\\s|$|\\Q)\\E)");
	private final Pattern patternFrom = Pattern.compile("[fF][rR][oO][mM]");
	
	private String query;
	private Map<String, Object> params = new HashMap<String, Object>();
	
	public QueryBuilder(String baseQuery) {
		query = baseQuery + " where 1 = 1";
	}

	@Override
	public String toString() {
		return query;
	}

	public QueryBuilder<T> appendString(String string) {
		query += " " + string;
		return this;
	}
	
	public QueryBuilder<T> restrict(String restriction) {
		query += " and " + restriction;
		return this;
	}
	
	public QueryBuilder<T> restrict(String restriction, Object value) {
		return restrict(restriction, value, true);
	}
	
	public QueryBuilder<T> restrict(String restriction, Object value, boolean ignoreNullOrEmpty) {
		if(ignoreNullOrEmpty && (value == null || value.toString().trim().isEmpty()
				|| value.toString().trim().equals("%%") || value.toString().trim().equals("%")
				 || value.toString().trim().equals("%null%"))){
			return this;
		}

		Matcher matcher = pattern.matcher(restriction);
		String parametro;
		if(matcher.find()){
			parametro = matcher.group(1);
		}else{
			throw new RuntimeException("N�o foi possivel achar o parametro na restri��o.");
		}
		
		params.put(parametro, value);
		
		return restrict(restriction);
	}
	
	public Map<String, Object> getParams() {
		return params;
	}
	
	@SuppressWarnings("unchecked")
	public List<T> list(EntityManager em){
		Query query = em.createQuery(this.toString());
		for(Entry<String, Object> entry : params.entrySet()){
			query.setParameter(entry.getKey(), entry.getValue());
		}
		
		return query.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<T> list(EntityManager em, int inicio, int qtde){
		Query query = em.createQuery(this.toString());
		for(Entry<String, Object> entry : params.entrySet()){
			query.setParameter(entry.getKey(), entry.getValue());
		}
		
		query.setFirstResult(inicio);
		query.setMaxResults(qtde);
		
		return query.getResultList();
	}

	public T first(EntityManager em){
		List<T> result = list(em, 0, 1);
		if(result.isEmpty()){
			return null;
		}
		return result.get(0);
	}
	
	public long count(EntityManager em){
		Matcher m = patternFrom.matcher(query);
		Integer fromIndex = null;

		if (m.find()) {
			fromIndex = m.start();
		} else {
			throw new RuntimeException("Claúsula 'from' não encontrada!");
		}

		String qr = "select count(*) " + query.substring(fromIndex).replace("fetch ", "");

		Query query = em.createQuery(qr);
		for(Entry<String, Object> entry : params.entrySet()){
			query.setParameter(entry.getKey(), entry.getValue());
		}
		
		return (Long) query.getSingleResult();
	}
	
	public QueryBuilder<T> orderBy(String field, boolean dec){
		query += " order by " + field + (dec ? " desc" : " asc");
		return this;
	}
	
	public QueryBuilder<T> orderBy(String field){
		return orderBy(field, false);
	}
}
