/*   1:    */ package br.com.virtuoso.prosaude.utils;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.math.BigDecimal;
/*   5:    */ import java.math.BigInteger;
/*   6:    */ import java.text.DecimalFormat;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.Iterator;
/*   9:    */ 
/*  10:    */ public class UtilExtenso
/*  11:    */ {
/*  12:    */   private ArrayList nro;
/*  13:    */   private BigInteger num;
/*  14: 19 */   private String[][] Qualificadores = { { "centavo", "centavos" }, { "", "" }, { "mil", "mil" }, { "milhão", "milhões" }, { "bilhão", "bilhões" }, { "trilhão", "trilhões" }, { "quatrilhão", "quatrilhões" }, { "quintilhão", "quintilhões" }, { "sextilhão", "sextilhões" }, { "septilhão", "septilhões" } };
/*  15: 22 */   private String[][] Numeros = { { "zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez", "onze", "doze", "treze", "quatorze", "quinze", "desesseis", "desessete", "dezoito", "desenove" }, { "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa" }, { "cem", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos", "oitocentos", "novecentos" } };
/*  16:    */   
/*  17:    */   public UtilExtenso()
/*  18:    */   {
/*  19: 29 */     this.nro = new ArrayList();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public UtilExtenso(BigDecimal dec)
/*  23:    */   {
/*  24: 33 */     this();
/*  25: 34 */     setNumber(dec);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public UtilExtenso(double dec)
/*  29:    */   {
/*  30: 38 */     this();
/*  31: 39 */     setNumber(dec);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public UtilExtenso(String dec)
/*  35:    */   {
/*  36: 43 */     this();
/*  37: 44 */     dec = dec.replaceAll("\\.", "");
/*  38: 45 */     dec = dec.replaceAll(",", ".");
/*  39:    */     try
/*  40:    */     {
/*  41: 47 */       setNumber(new BigDecimal(Double.parseDouble(dec)));
/*  42:    */     }
/*  43:    */     catch (NumberFormatException e)
/*  44:    */     {
/*  45: 49 */       setNumber(new BigDecimal(0.0D));
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void setNumber(BigDecimal dec)
/*  50:    */   {
/*  51: 60 */     this.num = dec.setScale(2, 4).multiply(BigDecimal.valueOf(100L)).toBigInteger();
/*  52:    */     
/*  53:    */ 
/*  54: 63 */     this.nro.clear();
/*  55: 64 */     if (this.num.equals(BigInteger.ZERO))
/*  56:    */     {
/*  57: 66 */       this.nro.add(new Integer(0));
/*  58:    */       
/*  59: 68 */       this.nro.add(new Integer(0));
/*  60:    */     }
/*  61:    */     else
/*  62:    */     {
/*  63: 71 */       addRemainder(100);
/*  64: 74 */       while (!this.num.equals(BigInteger.ZERO)) {
/*  65: 75 */         addRemainder(1000);
/*  66:    */       }
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void setNumber(double dec)
/*  71:    */   {
/*  72: 81 */     setNumber(new BigDecimal(dec));
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void show()
/*  76:    */   {
/*  77: 88 */     Iterator valores = this.nro.iterator();
/*  78: 90 */     while (valores.hasNext()) {
/*  79: 91 */       System.out.println(((Integer)valores.next()).intValue());
/*  80:    */     }
/*  81: 93 */     System.out.println(toString());
/*  82:    */   }
/*  83:    */   
/*  84:    */   public String toString()
/*  85:    */   {
/*  86:102 */     StringBuffer buf = new StringBuffer();
/*  87:    */     
/*  88:104 */     int numero = ((Integer)this.nro.get(0)).intValue();
/*  89:107 */     for (int ct = this.nro.size() - 1; ct > 0; ct--)
/*  90:    */     {
/*  91:109 */       if ((buf.length() > 0) && (!ehGrupoZero(ct))) {
/*  92:110 */         buf.append(" e ");
/*  93:    */       }
/*  94:112 */       buf.append(numToString(((Integer)this.nro.get(ct)).intValue(), ct));
/*  95:    */     }
/*  96:114 */     if (buf.length() > 0)
/*  97:    */     {
/*  98:115 */       if (ehUnicoGrupo()) {
/*  99:116 */         buf.append(" de ");
/* 100:    */       }
/* 101:117 */       while (buf.toString().endsWith(" ")) {
/* 102:118 */         buf.setLength(buf.length() - 1);
/* 103:    */       }
/* 104:119 */       if (ehPrimeiroGrupoUm()) {
/* 105:120 */         buf.insert(0, "h");
/* 106:    */       }
/* 107:121 */       if ((this.nro.size() == 2) && (((Integer)this.nro.get(1)).intValue() == 1)) {
/* 108:122 */         buf.append(" real");
/* 109:    */       } else {
/* 110:124 */         buf.append(" reais");
/* 111:    */       }
/* 112:126 */       if (((Integer)this.nro.get(0)).intValue() != 0) {
/* 113:127 */         buf.append(" e ");
/* 114:    */       }
/* 115:    */     }
/* 116:130 */     if (((Integer)this.nro.get(0)).intValue() != 0) {
/* 117:131 */       buf.append(numToString(((Integer)this.nro.get(0)).intValue(), 0));
/* 118:    */     }
/* 119:133 */     return "(" + buf.toString() + ")";
/* 120:    */   }
/* 121:    */   
/* 122:    */   private boolean ehPrimeiroGrupoUm()
/* 123:    */   {
/* 124:137 */     if (((Integer)this.nro.get(this.nro.size() - 1)).intValue() == 1) {
/* 125:138 */       return true;
/* 126:    */     }
/* 127:139 */     return false;
/* 128:    */   }
/* 129:    */   
/* 130:    */   private void addRemainder(int divisor)
/* 131:    */   {
/* 132:149 */     BigInteger[] newNum = this.num.divideAndRemainder(BigInteger.valueOf(divisor));
/* 133:    */     
/* 134:    */ 
/* 135:152 */     this.nro.add(new Integer(newNum[1].intValue()));
/* 136:    */     
/* 137:    */ 
/* 138:155 */     this.num = newNum[0];
/* 139:    */   }
/* 140:    */   
/* 141:    */   private boolean temMaisGrupos(int ps)
/* 142:    */   {
/* 143:165 */     for (; ps > 0; ps--) {
/* 144:166 */       if (((Integer)this.nro.get(ps)).intValue() != 0) {
/* 145:167 */         return true;
/* 146:    */       }
/* 147:    */     }
/* 148:171 */     return false;
/* 149:    */   }
/* 150:    */   
/* 151:    */   private boolean ehUltimoGrupo(int ps)
/* 152:    */   {
/* 153:181 */     return (ps > 0) && (((Integer)this.nro.get(ps)).intValue() != 0) && (!temMaisGrupos(ps - 1));
/* 154:    */   }
/* 155:    */   
/* 156:    */   private boolean ehUnicoGrupo()
/* 157:    */   {
/* 158:190 */     if (this.nro.size() <= 3) {
/* 159:191 */       return false;
/* 160:    */     }
/* 161:192 */     if ((!ehGrupoZero(1)) && (!ehGrupoZero(2))) {
/* 162:193 */       return false;
/* 163:    */     }
/* 164:194 */     boolean hasOne = false;
/* 165:195 */     for (int i = 3; i < this.nro.size(); i++) {
/* 166:196 */       if (((Integer)this.nro.get(i)).intValue() != 0)
/* 167:    */       {
/* 168:197 */         if (hasOne) {
/* 169:198 */           return false;
/* 170:    */         }
/* 171:199 */         hasOne = true;
/* 172:    */       }
/* 173:    */     }
/* 174:202 */     return true;
/* 175:    */   }
/* 176:    */   
/* 177:    */   boolean ehGrupoZero(int ps)
/* 178:    */   {
/* 179:206 */     if ((ps <= 0) || (ps >= this.nro.size())) {
/* 180:207 */       return true;
/* 181:    */     }
/* 182:208 */     return ((Integer)this.nro.get(ps)).intValue() == 0;
/* 183:    */   }
/* 184:    */   
/* 185:    */   private String numToString(int numero, int escala)
/* 186:    */   {
/* 187:219 */     int unidade = numero % 10;
/* 188:220 */     int dezena = numero % 100;
/* 189:221 */     int centena = numero / 100;
/* 190:222 */     StringBuffer buf = new StringBuffer();
/* 191:224 */     if (numero != 0)
/* 192:    */     {
/* 193:225 */       if (centena != 0) {
/* 194:226 */         if ((dezena == 0) && (centena == 1)) {
/* 195:227 */           buf.append(this.Numeros[2][0]);
/* 196:    */         } else {
/* 197:229 */           buf.append(this.Numeros[2][centena]);
/* 198:    */         }
/* 199:    */       }
/* 200:233 */       if ((buf.length() > 0) && (dezena != 0)) {
/* 201:234 */         buf.append(" e ");
/* 202:    */       }
/* 203:236 */       if (dezena > 19)
/* 204:    */       {
/* 205:237 */         dezena /= 10;
/* 206:238 */         buf.append(this.Numeros[1][(dezena - 2)]);
/* 207:239 */         if (unidade != 0)
/* 208:    */         {
/* 209:240 */           buf.append(" e ");
/* 210:241 */           buf.append(this.Numeros[0][unidade]);
/* 211:    */         }
/* 212:    */       }
/* 213:243 */       else if ((centena == 0) || (dezena != 0))
/* 214:    */       {
/* 215:244 */         buf.append(this.Numeros[0][dezena]);
/* 216:    */       }
/* 217:247 */       buf.append(" ");
/* 218:248 */       if (numero == 1) {
/* 219:249 */         buf.append(this.Qualificadores[escala][0]);
/* 220:    */       } else {
/* 221:251 */         buf.append(this.Qualificadores[escala][1]);
/* 222:    */       }
/* 223:    */     }
/* 224:255 */     return buf.toString();
/* 225:    */   }
/* 226:    */   
/* 227:    */   public static void main(String[] args)
/* 228:    */   {
/* 229:264 */     String valor = "25.50";
/* 230:265 */     UtilExtenso teste = new UtilExtenso(new BigDecimal(valor));
/* 231:266 */     System.out.println("Numero : " + new DecimalFormat().format(Double.valueOf(valor)));
/* 232:267 */     System.out.println("Extenso : " + teste.toString());
/* 233:    */   }
/* 234:    */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilExtenso
 * JD-Core Version:    0.7.0.1
 */