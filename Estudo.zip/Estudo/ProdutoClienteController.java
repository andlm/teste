public class ProdutoClienteController {
	public String nomeConta {get; set;}
    public String codigoCliente {get; set;}
    public String limiteCredito {get; set;}
    public String mostrarOpcoesCreditoflag {get; set;}
    public String disponibilidadeCredito {get; set;}
    public String setor {get; set;}
    public String telefone {get; set;}
    public String organizacaoVendas {get; set;}
    public String canalDistribuicao {get; set;}
    public String grupoVendedores {get; set;}
    public String codigoClienteEmissorOrdem {get; set;}
    public String tipoDocumento {get; set;}
    public String plantaSelected {get; set;}
    public String frete {get; set;}
	public Messages_pt_BR message {get; set;}
	public List<Pricebook2> catalogos {get; set;}
	public Id catalogoPrecoSelecionado {get; set;}
	public List<ProdutoPrecoWrapper> produtosPrecosWrapper {get; set;}
	public List<PricebookEntry> produtos {get; set;}
    public List<PricebookEntry> produtosCalogo {get; set;}
    public List<Condicoes_de_pagamento__c> condicoesPagamentosAtualizada {get; set;}
	public Set<String> produtosSelecionadosSet = new Set<String>();
	public String btnAddCarrinhoText {get; set;}
	public String btnRemoveCarrinhoText {get; set;}
    public List<PricebookEntry> produtosPlantasSelecionas = new List<PricebookEntry>(); 
	public Map<String, String> mapProduto = new Map<String, String>();
	public String btnAtualizar {get; set;}
	public String msn {get; set;}
    public Id usuarioId {get; set;}
    public ConfigVisualizarCamposWrapper visualizarCamposWrapper {get; set;}
    public String contatoSelecionadoBackId {get; set;}
    public String contaSelecionadaId {get; set;}
    public String flag {get; set;}
    public Id contaId;
    public String contaNome;
    public String endecoentrega {get; set;}
    public String codigoClienteEmissorSAP {get; set;}
    public String codigoClienteRecebedorSAP {get; set;}
    public Map<String, Regras_de_Volume_CIF__c> mapRegrasVolumeCIF = new Map<String, Regras_de_Volume_CIF__c>();
    
    public String mostrarButtonIrCarrinho {get; set;}

	public ProdutoClienteController () {
        this.contaSelecionadaId = ApexPages.currentPage().getParameters().get('contaSelecionadaId');
        this.contatoSelecionadoBackId = ApexPages.currentPage().getParameters().get('contatoSelecionadoBackId');
        this.codigoClienteEmissorSAP = ApexPages.currentPage().getParameters().get('codigoClienteEmissorSAP');
        this.codigoClienteRecebedorSAP = ApexPages.currentPage().getParameters().get('codigoClienteRecebedorSAP');
    }

    public class  ConfigVisualizarCamposWrapper {
        public String Condicao_Pagamento_flag {get; set;} 
        public String Dolar_flag {get; set;}
        public String Frete_flag {get; set;}
        public String ICMS_flag {get; set;}
        public String Imposto_flag {get; set;}
        public String LME_flag {get; set;}
        public String Premio_flag {get; set;}
        public String QP_flag {get; set;}
        public String Taxa_flag {get; set;}
        public String Taxa_Financeira_flag {get; set;}
        
        public String Condicao_Pagamento {get; set;} 
        public String Dolar {get; set;}
        public String ICMS {get; set;}
        public String Imposto {get; set;}
        public String LME {get; set;}
        public String Premio {get; set;}
        public String QP {get; set;}
        public String Taxa {get; set;}
        public String Taxa_Financeira {get; set;}
        
    }

	public class ProdutoPrecoWrapper {
        public PricebookEntry produto {get; set;}
        public String img {get; set;}
        public String plantaSelecionadaProduto {get; set;}
        public List<SelectOption> options {get; set;}
        public List<SelectOption> optionsPagamento {get; set;}
        public String taxaCambio {get; set;}
        public String indiceLME {get; set;}
        public String valorFreteTresMarias {get; set;}
        public String valorFreteJuizFora {get; set;}
        public String valorCondicaodePagamentoTresMarias {get; set;}
        public String valorCondicaodePagamentoJuizFora {get; set;}
        // >>> Cliente redução 
		public String valorICMSMarias {get; set;}
        public String valorICMSJuizFora {get; set;}

        public List<String> condicoesPagamentos {get; set;}
		
        public ProdutoPrecoWrapper(PricebookEntry p, Map<String, Regras_de_Volume_CIF__c> mapRegrasVolumeCIF, List<Condicoes_de_pagamento__c> condicoesPagamentosAtualizada) {
            optionsPagamento = new List<SelectOption>();
            optionsPagamento.clear();
            optionsPagamento.add(new SelectOption('', 'Selecione a Cond. Pagamento'));
            
            condicoesPagamentos = new List<String>();

            System.debug('condicoesPagamentosAtualizada........: ' + condicoesPagamentosAtualizada);

            for(Condicoes_de_pagamento__c cp : condicoesPagamentosAtualizada) {
                if(p.ProductCode == cp.Codigo_do_Material__c) {
                    optionsPagamento.add(new SelectOption(cp.Codigo_da_pagamento__c, cp.Codigo_da_pagamento__c + ' - ' + cp.Name));
                    //String produtosJSON = JSON.serialize(produtos);
                    condicoesPagamentos.add(JSON.serialize(cp));
                }
            }
            
            options = new List<SelectOption>();
            options.clear();
            options.add(new SelectOption('', 'Selecione a Planta'));

            Regras_de_Volume_CIF__c regraVolumeCIF = mapRegrasVolumeCIF.get(p.ProductCode);

            if (regraVolumeCIF!=null) {
                String[] arrFabrica = regraVolumeCIF.Fabrica__c.split('/');
                for (String sFabrica: arrFabrica) {     
                	if (sFabrica =='7205') {
                       options.add(new SelectOption('7205', 'Três Marias'));
                       p.Planta_selecionada__c = 'Três Marias';	   
					}
                    if (sFabrica =='7351') {
                       options.add(new SelectOption('7351', 'Juiz de Fora')); 
                       p.Planta_selecionada__c = 'Juiz de Fora';	   
					}
                }                
            }
            
            produto = p;
            taxaCambio = FormatValues.currencyBRL(p.Taxa_de_cambio_TCURR_UKURS__c, 2);
            
            if ( taxaCambio !='' ) {
                String[] lPartsTaxaCambio = taxaCambio.split( '\\,' );
                if (lPartsTaxaCambio.size()>0) {
                    String sValor 	= String.isBlank(lPartsTaxaCambio[0]) ? '0' : lPartsTaxaCambio[0];    
                    String sDecimal = String.isBlank(lPartsTaxaCambio[1]) ? '0000' : lPartsTaxaCambio[1];  
                    taxaCambio = sValor + ','+ sDecimal.left(4);
                    if (taxaCambio=='0,0000')
                        taxaCambio = '';
                }
            }
            
            indiceLME =  FormatValues.handler(p.LME__c, 2);

            valorFreteTresMarias =  FormatValues.currencyBRL(p.Valor_Frete_Tres_Marias_EKBZ_KBETR__c, 2);
            valorFreteJuizFora =  FormatValues.currencyBRL(p.Valor_Frete_Juiz_de_Fora_EKBZ_KBETR__c, 2);
            img = p.Product2.Product_Image__c.substringBetween('src=\"','\"');
            
            valorCondicaodePagamentoTresMarias = p.Condicao_de_Pagamento__c;
            valorCondicaodePagamentoJuizFora =  p.Condicao_de_Pagamento__c;
            
            // >>> Cliente redução 
			Decimal impostoICMSReducao = 0.0;
			impostoICMSReducao = p.Tax_imp_ICMS_RE_ZTBSD_VM_LISTAPR_ICMS_RE__c == null ? 0.00 : p.Tax_imp_ICMS_RE_ZTBSD_VM_LISTAPR_ICMS_RE__c;
            
			if (impostoICMSReducao > 0.0){
				valorICMSMarias = String.valueOf(impostoICMSReducao);
				valorICMSJuizFora  = String.valueOf(impostoICMSReducao);
			} else {
				valorICMSMarias = String.valueOf(p.Taxa_imposto_ZTBSD_VM_LISTAPR_ICMS_TM__c);
				valorICMSJuizFora  = String.valueOf(p.Taxa_imposto_ZTBSD_VM_LISTAPR_ICMS_JF__c);
			}
            System.debug('valorICMSMarias........: ' + valorICMSMarias);
            System.debug('valorICMSJuizFora........: ' + valorICMSJuizFora);
        }
    }

    public void init() {
        this.usuarioId = UserInfo.getUserId();
        this.flag = 'false';
        User usuarioContato = contatoUsuario(this.usuarioId);
        Account contaContato = null;
        this.visualizarCamposWrapper = new ConfigVisualizarCamposWrapper();
        this.mostrarButtonIrCarrinho = 'true';
        
        try {
            if('null' == this.contatoSelecionadoBackId) {
                //Endereço de Faturamento
                contaContato = buscarContaBackoffice(this.codigoClienteEmissorSAP);
                setarValoresCamposConta(contaContato);
            }else{
                contaContato = buscarContaContato(this.contatoSelecionadoBackId);
                setarValoresCamposConta(contaContato);
            }
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
        }

        initTextsView();

        this.contaId = contaContato.Id;
        this.contaNome = contaContato.Name;
        this.produtosCalogo = CatalagoPrecoProdutoUtil.produtosCalogoConta(codigoClienteEmissorSAP, contaContato.Name);
        
        if(!atualizarProdutosSalesforceComValoresDoSAP(contaContato)){
            ApexPages.addmessage(new ApexPages.message(ApexPages.severity.WARNING,'Não foi encontrado nenhum produto para esta cliente! (Ou serviço indisponível)'));
            this.mostrarButtonIrCarrinho = 'false';
            return;
        }

        if (produtosCalogo!=null){
            if(this.produtosCalogo.size() > 0){
        		this.produtos = CatalagoPrecoProdutoUtil.buscarProdutosAtivos(produtosCalogo[0].Pricebook2Id);
            }
        }

        if(null == this.produtos || 1 > this.produtos.size()){
            ApexPages.addmessage(new ApexPages.message(ApexPages.severity.WARNING,'Nenhum produto disponível para este cliente, por gentileza entrar em contato com o comercial.'));
            this.mostrarButtonIrCarrinho = 'false';
            return;
        }
        
        List<Regras_de_Volume_CIF__c> regrasVolumesCIF = buscarRegrasVolumesCIFs();
        for(Regras_de_Volume_CIF__c regraVolumeCIF : regrasVolumesCIF) {
            mapRegrasVolumeCIF.put(regraVolumeCIF.Codigo_do_Material_SAP__c, regraVolumeCIF);
        }

        formatarProdutoPreco(this.produtos);
        controlarVisibilidadeCamposComposicaoPreco(contaContato);
        //controlarEstadosCamposComposicaoPreco(contaContato);
    }

    private List<Condicoes_de_pagamento__c> selecionarCondicoesPagamentoParaInsertUpdade(List<vmConsultaprecoComV1.Registros_element_response> produtosResponseSAP, Account conta) {
        List<Condicoes_de_pagamento__c> listCondicaoPagamento = new List<Condicoes_de_pagamento__c>();
        Map<String, String> mapCp = new Map<String, String>();

        for(vmConsultaprecoComV1.Registros_element_Response pro : produtosResponseSAP) {
            String strKey = pro.NumMaterial+'-'+pro.CondPagamento;
            if(!mapCp.containsKey(strKey)) {
                Condicoes_de_pagamento__c cp = new Condicoes_de_pagamento__c();
                cp.Codigo_da_pagamento__c = pro.CondPagamento;
                cp.Name = pro.DescCondPagamento;
                cp.Descricao_do_Material__c = pro.TextoBreveMaterial; 
                cp.Incoterms__c = pro.IncotermsParte1;
                cp.Codigo_do_Material__c = pro.NumMaterial;
                cp.Conta__c = conta.Id;
                cp.Dolar__c = parseToDecimal(pro.TaxaCambio);
                cp.ICMS_Taxa_TM__c = parseToDecimal(pro.ICMSTaxaTM);
                cp.ICMS_Taxa_JF__c = parseToDecimal(pro.ICMSTaxaJF);
                cp.LME__c = parseToDecimal(pro.LME);
                cp.QP__c = pro.QP;
                cp.Taxa_Financeira__c = parseToDecimal(pro.TaxaFinanceira).setscale(4);
                cp.Premio_USD__c = parseToDecimal(pro.PremioUSD);
                cp.Preco_Tonelada_TM__c = parseToDecimal(pro.PrecoToneladasTresMarias);
                cp.Preco_Tonelada_JF__c = parseToDecimal(pro.PrecoToneladasJuizDeFora);
                cp.Preco_tonelada_reducao__c = parseToDecimal(pro.PrecoToneladasReducao);
                cp.FreteTM__c = parseToDecimal(pro.ValorFreteTresMarias);
                cp.Frete_JF__c = parseToDecimal(pro.ValorFreteJuizDeFora);

                listCondicaoPagamento.add(cp);
                mapCp.put(strKey, pro.CondPagamento);
            }
        }

        return listCondicaoPagamento;
    }

    private Decimal parseToDecimal(String value) {
        return String.isBlank(value.trim()) ? 0.00 : Decimal.valueOf(value.trim());
    }

    private void excluirCondicoesPagamentosParaAtualizar(Account contaContato) {
        List<Condicoes_de_pagamento__c> cp = [SELECT Id FROM Condicoes_de_pagamento__c where Conta__c = :contaContato.Id];
        delete cp;
    }

    private Boolean atualizarProdutosSalesforceComValoresDoSAP(Account contaContato) {
        List<vmConsultaprecoComV1.Registros_element_response> produtosResponseSAP = null;

        try{
            produtosResponseSAP = buscarListaProdutosPrecosCliente_SAP(contaContato.Codigo_do_Cliente_KNA1_KUNNR__c);
            
            for(PricebookEntry p : this.produtosCalogo) {
                p.IsActive = false;
            }
            update this.produtosCalogo;
            if(null == produtosResponseSAP || produtosResponseSAP.size() < 1) return false;
        } catch(CalloutException ex) {
            System.debug('Erro...: ' + ex);
            return false;
        }

        this.condicoesPagamentosAtualizada = selecionarCondicoesPagamentoParaInsertUpdade(produtosResponseSAP, contaContato);
        excluirCondicoesPagamentosParaAtualizar(contaContato);
        persistirCondicoesPagamentos(this.condicoesPagamentosAtualizada);
        System.debug('condicoesPagamentosAtualizada...............: ' + this.condicoesPagamentosAtualizada);

        Map<String, vmConsultaprecoComV1.Registros_element_response> mapProdutosResponseSAP = new Map<String, vmConsultaprecoComV1.Registros_element_response>();

        Set<String> setCodigoProdutoSAP = new set<String>();

        for(vmConsultaprecoComV1.Registros_element_Response pro : produtosResponseSAP) {
            pro.NumMaterial = pro.NumMaterial.replaceFirst('00000000000', '');
            setCodigoProdutoSAP.add(pro.NumMaterial);
            mapProdutosResponseSAP.put(pro.NumMaterial, pro);
        }
        
        for(PricebookEntry p : this.produtosCalogo) {
            if(setCodigoProdutoSAP.contains(p.ProductCode) || setCodigoProdutoSAP.contains(p.ProductCode)) {
                p.IsActive = true;
                vmConsultaprecoComV1.Registros_element_response produtoSap = mapProdutosResponseSAP.get(p.ProductCode);
                p.LME__c = String.isBlank(produtoSap.LME) ? 0.00 : Decimal.valueOf(produtoSap.LME.trim());
                p.QP__c = produtoSap.QP;
                p.Taxa_de_cambio_TCURR_UKURS__c = String.isBlank(produtoSap.TaxaCambio.trim()) ? 0.00 : Decimal.valueOf(produtoSap.TaxaCambio.trim());
                p.PremioUSD__c = String.isBlank(produtoSap.PremioUSD) ? '0' : produtoSap.PremioUSD;
                p.ValorICMSBruto__c = String.isBlank(produtoSap.ValorICMSBruto) ? '0' : produtoSap.ValorICMSBruto;
                p.Imposto_TM__c = String.isBlank(produtoSap.TaxaImpostoTM) ? 0.00 : Decimal.valueOf(produtoSap.TaxaImpostoTM.trim());
                p.Imposto_JF__c = String.isBlank(produtoSap.TaxaImpostoJF) ? 0.00 : Decimal.valueOf(produtoSap.TaxaImpostoJF.trim());
                p.TaxaFinanceiraTresMarias__c = String.isBlank(produtoSap.TaxaFinanceiraTresMarias) ? '0' : produtoSap.TaxaFinanceiraTresMarias;
                p.TaxaFinanceiraJuizDeFora__c = String.isBlank(produtoSap.TaxaFinanceiraJuizDeFora) ? '0' : produtoSap.TaxaFinanceiraJuizDeFora;
                p.Taxa_impostos_3_Marias_PA0045_EFFIN__c = String.isBlank(produtoSap.TaxaImpostoTresMarias) ? 0 : Decimal.valueOf(produtoSap.TaxaImpostoTresMarias.trim());
 
                //é o ICMS TM
                p.Taxa_imposto_ZTBSD_VM_LISTAPR_ICMS_TM__c = String.isBlank(produtoSap.ICMSTaxaTM) ? 0.00 : Decimal.valueOf(produtoSap.ICMSTaxaTM.trim()).setscale(2);
                //é o ICMS JF
                p.Taxa_imposto_ZTBSD_VM_LISTAPR_ICMS_JF__c = String.isBlank(produtoSap.ICMSTaxaJF) ? 0 : Decimal.valueOf(produtoSap.ICMSTaxaJF.trim()).setscale(2);
                p.Taxa_impostos_Juiz_de_Fora_PA0045_EFFIN__c = String.isBlank(produtoSap.TaxaImpostoJuizDeFora) ? 0 : Decimal.valueOf(produtoSap.TaxaImpostoJuizDeFora.trim());
                p.Valor_Frete_Tres_Marias_EKBZ_KBETR__c = String.isBlank(produtoSap.ValorFreteTresMarias) ? 0.0 : Decimal.valueOf(produtoSap.ValorFreteTresMarias.trim());
                p.Valor_Frete_Juiz_de_Fora_EKBZ_KBETR__c = String.isBlank(produtoSap.ValorFreteJuizDeFora) ? 0.0 : Decimal.valueOf(produtoSap.ValorFreteJuizDeFora.trim());
                p.Incoterms_KNVV_INCO1__c = String.isBlank(produtoSap.IncotermsParte1) ? '' : produtoSap.IncotermsParte1.trim();
                p.Preco_ton_Tres_Marias_ZTBSD_LME_ZDEMEDIA__c = String.isBlank(produtoSap.PrecoToneladasTresMarias) ? 0.0 : Decimal.valueOf(produtoSap.PrecoToneladasTresMarias.trim());
                p.Preco_ton_Juiz_de_Fora_ZTBSD_LME_MEDIA__c = String.isBlank(produtoSap.PrecoToneladasJuizDeFora) ? 0.0 : Decimal.valueOf(produtoSap.PrecoToneladasJuizDeFora.trim()); 
                p.Condicao_de_Pagamento__c = String.isBlank(produtoSap.CondPagamento) ? '' : produtoSap.CondPagamento.trim() + ' - ' + produtoSap.DescCondPagamento.trim();
            
            	// >>> Cliente redução 
				p.Preco_ton_Reducao_ZTBSD_LME_MEDIA__c = String.isBlank(produtoSap.PrecoToneladasReducao) ? 0.0 : Decimal.valueOf(produtoSap.PrecoToneladasReducao.trim()); 
            	p.Tax_imp_ICMS_RE_ZTBSD_VM_LISTAPR_ICMS_RE__c = String.isBlank(produtoSap.ICMSTaxaRE) ? 0.00 : Decimal.valueOf(produtoSap.ICMSTaxaRE.trim()).setscale(2);
            }else{
                p.IsActive = false;
            }
        }

        update this.produtosCalogo;

        return true;
    }

    public PageReference voltarListaPedidos() {
        PageReference redirectPage = Page.NovoPedidoBotao;
        redirectPage.setRedirect(true);
        redirectPage.getParameters().put('contaSelecionadaId', this.contaSelecionadaId);
        redirectPage.getParameters().put('contatoSelecionadoBackId', this.contatoSelecionadoBackId);
        redirectPage.getParameters().put('codigoClienteEmissorSAP', this.codigoClienteEmissorSAP);
        redirectPage.getParameters().put('codigoClienteRecebedorSAP', this.codigoClienteRecebedorSAP);
        
        return redirectPage;
    }
	
    
    public void initTextsView() {
        this.message = new Messages_pt_BR();
        this.btnAddCarrinhoText = this.message.btnAddProdutoCarrinho;
        this.btnRemoveCarrinhoText = this.message.btnRemoveProdutoCarrinho;
    }

    public List<SelectOption> getCatalogosDisponiveis() {
        List<SelectOption> options = new List<SelectOption>();
        options.clear();

        for(Pricebook2 c : catalogos){
            options.add(new SelectOption(c.Id, c.Name));
        }
        return options;
    }

    public void atualizarListaOpcaoProdutos() {
        this.produtos = buscarProdutosPrecos(catalogoPrecoSelecionado);
        formatarProdutoPreco(this.produtos);
    }

    public List<SelectOption> getPlantaSelect() {
        List<SelectOption> options = new List<SelectOption>();
        options.clear();
        options.add(new SelectOption('', 'Selecione uma Planta'));
        options.add(new SelectOption('7205', 'Três Marias'));
        options.add(new SelectOption('7351', 'Juiz de Fora'));
        return options;
    }

    public List<SelectOption> getEnderecoSelect() {
        List<SelectOption> options = new List<SelectOption>();
        options.clear();

        List<Account> contaPai = getContaPai(this.contaId);
        if(null == contaPai || 1 > contaPai.size()) {
            options.add(new SelectOption('', 'Nenhuma outra empresa com endereço'));
            return null;
        }

        List<Account> contasFilhas = getContasFilhas(contaPai[0].Id);

        if(null == contasFilhas || 1 > contasFilhas.size()) {
            options.add(new SelectOption('', 'Nenhuma outra empresa com endereço'));
            return null;
        }

        options.add(new SelectOption(this.contaId, this.contaNome + ' - ' + this.endecoentrega));

        for(Account c : contasFilhas) {
            String endecoEntregaFilhas = c.ShippingStreet + ', ' + c.ShippingCity + ' - ' + c.ShippingState 
                                + ', Cep. ' + c.ShippingPostalCode + ' - ' + c.ShippingCountry;
            options.add(new SelectOption(String.isBlank(c.Codigo_do_Cliente_KNA1_KUNNR__c) ? '00000' : c.Codigo_do_Cliente_KNA1_KUNNR__c, c.Name + ' - ' + endecoEntregaFilhas));
        }
         
        return options;
    }

    public PageReference irProdutoCarrinho() {
        String produtos = Apexpages.currentPage().getParameters().get('produtosSelecionados');

        PageReference redirectPage = Page.PedidoCarrinho;
        redirectPage.setRedirect(true);
        String produtosJSON = JSON.serialize(produtos);
        redirectPage.getParameters().put('produtos', produtosJSON);
        
        //redirectPage.getParameters().put('codigoClienteEmissorSAP', codigoClienteEmissorSAP);
        //redirectPage.getParameters().put('codigoClienteRecebedorSAP', codigoClienteRecebedorSAP);
        
        redirectPage.getParameters().put('codigoClienteEmissorSAP', this.codigoClienteEmissorSAP);
        redirectPage.getParameters().put('codigoClienteRecebedorSAP', this.codigoClienteRecebedorSAP);
        
        return redirectPage;
    }

    public PageReference irCarrinho() {
        String produtosIds = Apexpages.currentPage().getParameters().get('produtosSelecionados');
        String produtosDaCondPagSelecionados = Apexpages.currentPage().getParameters().get('produtosDaCondicaoMap');
        this.msn = 'Você deve selecionar no mínimo um produto.';
        ApexPages.addmessage(new ApexPages.message(ApexPages.severity.WARNING,'Você deve selecionar no mínimo um produto.'));
        
        System.debug('produtosDaCondPagSelecionados.......: ' + produtosDaCondPagSelecionados);

        if(String.isBlank(produtosIds)) {
            return null;
        }

        PageReference redirectPage = Page.ProdutoCarrinho;
        redirectPage.setRedirect(true);
        redirectPage.getParameters().put('produtosIds', produtosIds);
        redirectPage.getParameters().put('contaSelecionadaId', this.contaSelecionadaId);
        redirectPage.getParameters().put('contatoSelecionadoBackId', this.contatoSelecionadoBackId);
        redirectPage.getParameters().put('codigoClienteEmissorSAP', this.codigoClienteEmissorSAP);
        redirectPage.getParameters().put('codigoClienteRecebedorSAP', this.codigoClienteRecebedorSAP);
        redirectPage.getParameters().put('produtosDaCondPagSelecionados', produtosDaCondPagSelecionados);

        return redirectPage;
    }

    public void atualizarPlantaProduto() {
        String produtoId = Apexpages.currentPage().getParameters().get('produtoId');
        Id cdProd = produtoId;
        String pantaValor = Apexpages.currentPage().getParameters().get('pantaValor');

        PricebookEntry produtoSelect = new PricebookEntry(id = cdProd, Planta_selecionada__c = pantaValor);
        update produtoSelect;
    }

    private List<vmConsultaprecoComV1.Registros_element_response> buscarListaProdutosPrecosCliente_SAP(String codigoCliente) {
        vmConsultaprecoComV1.HTTPS_Port port = new vmConsultaprecoComV1.HTTPS_Port();
        vmConsultaprecoComV1.Registros_element registro = new vmConsultaprecoComV1.Registros_element();

        registro.Data = DateUtil.getDataHoje_DD_MM_AA();
        registro.CodigoCliente = codigoCliente;
        List<vmConsultaprecoComV1.Registros_element> registros = new List<vmConsultaprecoComV1.Registros_element>(); 
        registros.add(registro);

        List<vmConsultaprecoComV1.Registros_element_response> registrosResponse = new List<vmConsultaprecoComV1.Registros_element_response>();
        registrosResponse = port.SI_SALESFORCE_ConsultaPrecoDisponibilidadeProdutos_out_sync(registros);
        
        return registrosResponse;
    }

    private void setarValoresCamposConta(Account contaContato) {
        this.nomeConta = contaContato.Name;
        this.codigoCliente =  contaContato.Codigo_do_Cliente_KNA1_KUNNR__c;
        
        this.limiteCredito = contaContato.Limite_de_credito__c;   
        this.mostrarOpcoesCreditoflag = contaContato.Mostrar_opcoes_de_Credito_flag__c ? 'true' : 'false';
        this.disponibilidadeCredito = contaContato.Disponibilidade_de_cr_dito__c;
        this.setor = contaContato.Industry;
        this.telefone = contaContato.Phone;

        this.organizacaoVendas = contaContato.Organizacao_de_vendas_VBAK_VKORG__c;
        this.canalDistribuicao = contaContato.Canal_de_distribuicao_VBAK_VTWEG__c;
        this.grupoVendedores = contaContato.Grupo_de_Vendedores_KNVV_VKGRP__c;
        this.codigoClienteEmissorOrdem = contaContato.Codigo_do_Cliente_KNA1_KUNNR__c;
        this.tipoDocumento = 'DOC-TIPO';
        this.frete = '457,56';
        this.endecoentrega = contaContato.ShippingStreet + ', ' 
                            + contaContato.ShippingCity + ' - ' 
                            + contaContato.ShippingState + ', Cep. ' 
                            + contaContato.ShippingPostalCode + ' - ' 
                            + contaContato.ShippingCountry;
    }

    private void controlarVisibilidadeCamposComposicaoPreco(Account contaContato) {
        this.visualizarCamposWrapper.LME_flag = contaContato.LME_flag__c ? 'true' : 'false';
        this.visualizarCamposWrapper.Condicao_Pagamento_flag = contaContato.Condicao_Pagamento_flag__c ? 'true' : 'false';
        //this.visualizarCamposWrapper.Condicao_Pagamento_flag = 'MUDANÇA';
        this.visualizarCamposWrapper.Dolar_flag = contaContato.Dolar_flag__c ? 'true' : 'false';
        this.visualizarCamposWrapper.Frete_flag = contaContato.Frete_flag__c ? 'true' : 'false';
        this.visualizarCamposWrapper.ICMS_flag = contaContato.ICMS_flag__c ? 'true' : 'false';
        this.visualizarCamposWrapper.Imposto_flag = contaContato.Imposto_flag__c ? 'true' : 'false';
        this.visualizarCamposWrapper.Premio_flag = contaContato.Premio_flag__c ? 'true' : 'false';
        this.visualizarCamposWrapper.QP_flag = contaContato.QP_flag__c ? 'true' : 'false';
        this.visualizarCamposWrapper.Taxa_flag = contaContato.Taxa_flag__c ? 'true' : 'false';
        this.visualizarCamposWrapper.Taxa_Financeira_flag = contaContato.Taxa_Financeira_flag__c ? 'true' : 'false';
    }

    private void controlarEstadosCamposComposicaoPreco(Account contaContato) {
        this.visualizarCamposWrapper.Condicao_Pagamento = contaContato.Condicao_de_Pagamento__c;
        this.visualizarCamposWrapper.Dolar = contaContato.Dolar__c;
        this.visualizarCamposWrapper.ICMS = contaContato.ICMS__c;
        this.visualizarCamposWrapper.Imposto = contaContato.Imposto__c;
        this.visualizarCamposWrapper.Premio = contaContato.Premio__c;
    }

    private void formatarProdutoPreco(List<PricebookEntry> produtosPrecos) {
		this.produtosPrecosWrapper = new List<ProdutoPrecoWrapper>();
		for(PricebookEntry p : produtosPrecos) {
			this.produtosPrecosWrapper.add(new ProdutoPrecoWrapper(p, mapRegrasVolumeCIF, this.condicoesPagamentosAtualizada));
		}
	}

	private List<Pricebook2> buscarCatalogosPrecos() {
        return [select Id, Name, Description, IsStandard, IsActive from Pricebook2 where IsActive = true];
    }
    
    private List<Regras_de_Volume_CIF__c> buscarRegrasVolumesCIFs() 
	{
        try{
            return [select Id, Fabrica__c,Codigo_do_Material_SAP__c  from Regras_de_Volume_CIF__c  ];
        } catch(QueryException e) {
            System.debug('buscarRegrasVolumesCIFsERROR.......: ' + e.getMessage());
            return null;
        }
    }

    private List<Pricebook2> buscarCatalogosPrecos(Id codigoCliente) {
        try {
            return [select Id, Name, Description, IsStandard, IsActive, Conta__c from Pricebook2 where IsActive = true  AND Conta__c = :codigoCliente];
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
            return null;
        }
    }

    private List<PricebookEntry> buscarProdutosPrecos(Id idListaPreco) {
        return [select Id, Name, ProductCode, Pricebook2Id, Product2.Description, Product2.Product_Image__c, UnitPrice, 
                Planta_selecionada__c, Opcao_Planta_selecionada__c, IsActive,
                LME__c, QP__c, PremioUSD__c, ValorICMSBruto__c, Imposto__c,
                Taxa_de_cambio_TCURR_UKURS__c, 
                TaxaFinanceiraTresMarias__c, TaxaFinanceiraJuizDeFora__c,
                Taxa_impostos_Juiz_de_Fora_PA0045_EFFIN__c, Taxa_impostos_3_Marias_PA0045_EFFIN__c,
                Valor_Frete_Juiz_de_Fora_EKBZ_KBETR__c, Valor_Frete_Tres_Marias_EKBZ_KBETR__c
        		from PricebookEntry where Pricebook2Id = :idListaPreco and BlackList__c = false];
    }

    private User contatoUsuario(Id idUsuario) {
        return [select Id, ContactId from User where id = :idUsuario];
    }

    private Account buscarConta(Id idConta) {
        try{
            return [select Id, Name, Codigo_do_Cliente_KNA1_KUNNR__c, Limite_de_credito__c, 
                    Disponibilidade_de_cr_dito__c, Industry, Phone, 
                    ShippingStreet, ShippingCity, ShippingState, ShippingPostalCode, ShippingCountry,
                    Condicao_Pagamento_flag__c, Dolar_flag__c, Frete_flag__c, ICMS_flag__c, Imposto_flag__c, 
                    LME_flag__c, Premio_flag__c, QP_flag__c, Taxa_flag__c, Taxa_Financeira_flag__c, 
                    Condicao_de_Pagamento__c, Dolar__c, Frete__c, ICMS__c, Imposto__c, LME__c, Premio__c,
                    Organizacao_de_vendas_VBAK_VKORG__c, Canal_de_distribuicao_VBAK_VTWEG__c, 
                    Grupo_de_Vendedores_KNVV_VKGRP__c, Mostrar_opcoes_de_Credito_flag__c
                    from Account where id = :idConta];
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
            return null;
        }
    }

    private Account buscarContaBackoffice(Id idConta) {
        Try{
                return [select Id, Name, Codigo_do_Cliente_KNA1_KUNNR__c, Limite_de_credito__c, 
                                Disponibilidade_de_cr_dito__c, Industry, Phone, 
                                ShippingStreet, ShippingCity, ShippingState, ShippingPostalCode, ShippingCountry,
                                Condicao_Pagamento_flag__c, Dolar_flag__c, Frete_flag__c, ICMS_flag__c, Imposto_flag__c, 
                                LME_flag__c, Premio_flag__c, QP_flag__c, Taxa_flag__c, Taxa_Financeira_flag__c, 
                                Condicao_de_Pagamento__c, Dolar__c, Frete__c, ICMS__c, Imposto__c, LME__c, Premio__c,
                                Organizacao_de_vendas_VBAK_VKORG__c, Canal_de_distribuicao_VBAK_VTWEG__c, 
                                Grupo_de_Vendedores_KNVV_VKGRP__c, Mostrar_opcoes_de_Credito_flag__c
                                from Account where id = :idConta];
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
            return null;
        }
    }

    private Account buscarContaContato(Id idContato) {
        Try{
            Contact contato = [select AccountId, Account.Name, Account.Codigo_do_Cliente_KNA1_KUNNR__c, Account.Limite_de_credito__c, 
                                Account.Disponibilidade_de_cr_dito__c, Account.Industry, Account.Phone, 
                                Account.ShippingStreet, Account.ShippingCity, Account.ShippingState, Account.ShippingPostalCode, Account.ShippingCountry,
                                Account.Condicao_Pagamento_flag__c, Account.Dolar_flag__c, Account.Frete_flag__c, Account.ICMS_flag__c, Account.Imposto_flag__c, 
                                Account.LME_flag__c, Account.Premio_flag__c, Account.QP_flag__c, Account.Taxa_flag__c, Account.Taxa_Financeira_flag__c, 
                                Account.Condicao_de_Pagamento__c, Account.Dolar__c, Account.Frete__c, Account.ICMS__c, Account.Imposto__c, Account.LME__c, Account.Premio__c,
                                Account.Organizacao_de_vendas_VBAK_VKORG__c, Account.Canal_de_distribuicao_VBAK_VTWEG__c, 
                                Account.Grupo_de_Vendedores_KNVV_VKGRP__c, Account.Mostrar_opcoes_de_Credito_flag__c from Contact where id = :idContato];

            System.debug('contato.Account.Mostrar_opcoes_de_Credito_flag__c.......: ' + contato.Account.Mostrar_opcoes_de_Credito_flag__c);
            Account conta = new Account();
            conta.Id = contato.AccountId;
            conta.Name = contato.Account.Name;
            conta.Codigo_do_Cliente_KNA1_KUNNR__c = contato.Account.Codigo_do_Cliente_KNA1_KUNNR__c;
            conta.Limite_de_credito__c = contato.Account.Limite_de_credito__c;
            conta.Disponibilidade_de_cr_dito__c = contato.Account.Disponibilidade_de_cr_dito__c;
            conta.Industry = contato.Account.Industry;
            conta.Phone = contato.Account.Phone;
            conta.ShippingStreet = contato.Account.ShippingStreet;
            conta.ShippingCity = contato.Account.ShippingCity;
            conta.ShippingState = contato.Account.ShippingState;
            conta.ShippingPostalCode = contato.Account.ShippingPostalCode;
            conta.ShippingCountry = contato.Account.ShippingCountry;
            conta.Condicao_Pagamento_flag__c = contato.Account.Condicao_Pagamento_flag__c;
            conta.Dolar_flag__c = contato.Account.Dolar_flag__c;
            conta.Frete_flag__c = contato.Account.Frete_flag__c;
            conta.ICMS_flag__c = contato.Account.ICMS_flag__c;
            conta.Imposto_flag__c = contato.Account.Imposto_flag__c;
            conta.LME_flag__c = contato.Account.LME_flag__c;
            conta.Premio_flag__c = contato.Account.Premio_flag__c;
            conta.QP_flag__c = contato.Account.QP_flag__c;
            conta.Taxa_flag__c = contato.Account.Taxa_flag__c;
            conta.Taxa_Financeira_flag__c = contato.Account.Taxa_Financeira_flag__c;
            conta.Condicao_de_Pagamento__c = contato.Account.Condicao_de_Pagamento__c;
            conta.Dolar__c = contato.Account.Dolar__c;
            conta.Frete__c = contato.Account.Frete__c;
            conta.ICMS__c = contato.Account.ICMS__c;
            conta.Imposto__c = contato.Account.Imposto__c;
            conta.LME__c = contato.Account.LME__c;
            conta.Premio__c = contato.Account.Premio__c;
            conta.Organizacao_de_vendas_VBAK_VKORG__c = contato.Account.Organizacao_de_vendas_VBAK_VKORG__c;
            conta.Canal_de_distribuicao_VBAK_VTWEG__c = contato.Account.Canal_de_distribuicao_VBAK_VTWEG__c;
            conta.Grupo_de_Vendedores_KNVV_VKGRP__c = contato.Account.Grupo_de_Vendedores_KNVV_VKGRP__c;
            conta.Mostrar_opcoes_de_Credito_flag__c = contato.Account.Mostrar_opcoes_de_Credito_flag__c;
            return conta;
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
            return null;
        }
    }

    private Account buscarContaUsuario(Id idUsuario){
        return [select Id, Name, Owner.Name from Account where OwnerId = :idUsuario];
    }

    private List<Account> getContaPai(Id cdConta) {
        try{
            return [SELECT Id, ParentId, Codigo_do_Cliente_KNA1_KUNNR__c FROM Account where Id = :cdConta];
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
            return null;
        }
    }

    private List<Account> getContasFilhas(Id cdPai) {
        try{
            return [SELECT Id, Name, Codigo_do_Cliente_KNA1_KUNNR__c, ShippingStreet, 
                        ShippingCity, ShippingState, ShippingPostalCode, ShippingCountry 
                    FROM Account where ParentId = :cdPai];
        } catch(QueryException e) {
            System.debug('contaContatoERROR.......: ' + e.getMessage());
            return null;
        }
    }

    private void persistirCondicoesPagamentos(List<Condicoes_de_pagamento__c> condicoesPags) {
        List<Database.UpsertResult> results = Database.upsert(condicoesPags, false);
        //executeUpsertQuery(results);
    }

    private void executeUpsertQuery(List<Database.UpsertResult> results){
        for (Database.UpsertResult result : results){
            if (result.isSuccess()) {
                System.debug('Registro persistido com sucesso: ' + result.getId());
            }else{
                for(Database.Error err : result.getErrors()) {
                    System.debug('Ocorreu o seguinte erro.');                   
                    System.debug(err.getStatusCode() + ': ' + err.getMessage());
                    System.debug('Campos que afetados por este erro: ' + err.getFields());
                }
            }
        }
    }

    public static void TestClass() {
        Integer i = 0;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
        i++;
    }
}