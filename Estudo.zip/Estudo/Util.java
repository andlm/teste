package com.nexxera.pds.webservice.server;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.PixelGrabber;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.Key;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;

import multivalent.Behavior;
import multivalent.Context;
import multivalent.Document;
import multivalent.Node;
import multivalent.std.adaptor.pdf.PDF;

import org.imgscalr.Scalr;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
import com.nexxera.pds.utility.ImageSignature;
import com.nexxera.pds.utility.ImageSignatureExtractor;

public class Util 
{
	public static String criptografiaBase64(byte[] binario) throws IOException {
		return new sun.misc.BASE64Encoder().encode(binario);
	}
	
	public static String[] criptografiaBase64(X509Certificate[] x509CertificateChain) throws Exception {
		List<String> certificatesAliasList = new ArrayList<String>();
		
		for (int i = 0; i < x509CertificateChain.length; i++) {
			certificatesAliasList.add(criptografiaBase64(x509CertificateChain[i].getEncoded()));
		}
		
		return certificatesAliasList.toArray(new String[certificatesAliasList.size()]);
	}
	
	public static byte[] decriptografiaBase64(String TextoIni) throws IOException {
		return new sun.misc.BASE64Decoder().decodeBuffer(TextoIni);
	}
	
	public static String uniqueTempFile()
	{
	    return new StringBuilder().append(new Date().getTime()).append(UUID.randomUUID()).append(".").append("upload").toString();
	}

	private static File createTempFile(String file)
    {
        File tempFile = new File(getTempDir(), file.trim());
        return tempFile;
    }

	public static File createTempAnexos(byte[] arquivoAnexoContrato) throws IOException
	{
	    String pdfNome = "";
	    pdfNome = uniqueTempFile();
	    File confFolder = createTempFile(pdfNome);
	    FileOutputStream fosfileAnexoContrato = new FileOutputStream(confFolder);
	    fosfileAnexoContrato.write(arquivoAnexoContrato);
	    fosfileAnexoContrato.close();
	    return new File(confFolder.getAbsolutePath());
	}
	
	public static File createTempFileIfNotExists(InputStream inputStream, String fileName) throws IOException {
		File tempFile = getTempFile(fileName);
		if (!tempFile.exists()) {
			byte[] byteArray = byteArrayFromInputStream(inputStream).toByteArray();
			FileOutputStream fosTempFile = new FileOutputStream(tempFile);
			fosTempFile.write(byteArray);
			fosTempFile.close();
		}
		return tempFile;
	}
	
	private static File getTempFile(String tempFile) {
		return new File(getTempDir(), tempFile.trim());
	}
	
	
	private static final String MSWORD 				= "Office Word";
	private static boolean 		convertWORD			= false;
	
	public static byte[] convertPaginaPDFtoPaginaPNG(byte[] bnArquivoSign, 
													 int numeroPagina, 
													 double larguraPagina, 
													 double alturaPagina,
													 double zoomPagina) throws Exception
	{
		// Convert byte to File PDF
		byte[] pngFile 				= null;
		byte[] bnArquivoSignOrign	= bnArquivoSign;
		
		bnArquivoSign 				= Util.validarOfficeConversaoPDF(bnArquivoSign);
		File tempFile 				= File.createTempFile("pdf01", null, new File(System.getProperty("java.io.tmpdir")));
		FileOutputStream fosfileAnexoContrato = new FileOutputStream(tempFile);
		fosfileAnexoContrato.write(bnArquivoSign);
		fosfileAnexoContrato.close();
		
		ByteArrayOutputStream baosPDF = new ByteArrayOutputStream(); 
		PDF pdf = (PDF) Behavior.getInstance("AdobePDF", "AdobePDF", null, null, null);
		pdf.setInput(tempFile);
		Document doc = new Document("doc", null, null);
		float zoom 	= 1.6F;
		int largura	= 5;
		pdf.setZoom(zoom);
		doc.clear();

		doc.putAttr(Document.ATTR_PAGE, Integer.toString(numeroPagina));
		pdf.parse(doc);
		Node top = doc.childAt(0);
		doc.formatBeforeAfter((int)larguraPagina+largura, (int)alturaPagina+largura, null);
		
		float w =  (top.bbox.width);
        float h =  (top.bbox.height);
		BufferedImage img 	= new BufferedImage((int)w,(int)h, BufferedImage.TYPE_INT_RGB);
		Graphics2D g 		= img.createGraphics();
		g.setClip(0, 0, (int)w,(int)h);
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		Context cx = doc.getStyleSheet().getContext(g, null);
		top.paintBeforeAfter(g.getClipBounds(), cx);
		
		List<ImageSignature> assinaturas = ImageSignatureExtractor.extract(bnArquivoSignOrign, numeroPagina);
		if (assinaturas != null)
		{
			for (ImageSignature assinatura: assinaturas)
			{
				if (assinatura.getImagem() != null)
					ImageSignature.draw(assinatura, img);
			}
		}
		
		ImageIO.write(img, "png", baosPDF);
		
		doc.removeAllChildren();
		cx.reset();
		g.dispose();
		pngFile = baosPDF.toByteArray();
		/* >>> ESTUDAR A POSSIBILIDADE DE N�O DEIXAR IMPORTAR O PDF QUE FOI GERADO PELO WORD
		   Se o PDF foi criado com a convers�o do Microsoft Word 2007's 'publish to PDF', 
		   o mesmo ger� um erro : java.lang.ArrayIndexOutOfBoundsException error.429 na convers�o
		   da imagem
		 */
		pdf.getReader().close();
		doc = null;
		pngFile 									= Util.validarOfficeConversaoPDFtoPNG(pngFile);
		BufferedImage assinaturaImagemFinal 		= Util.getBufferedImageFromBytes(pngFile);
		BufferedImage pngFileFinal 					= org.imgscalr.Scalr.resize(assinaturaImagemFinal, Scalr.Method.ULTRA_QUALITY,(int) w,(int) h);
		pngFile										= Util.getBytesFromBufferedImage(pngFileFinal, "jpg");
		
		tempFile.delete();
		return pngFile;
	}
	
	public static byte[] validarOfficeConversaoPDF(byte[] bnArquivoSign) throws IOException, DocumentException
	{
		// erro 429 convers�o para PNG, � rescrito o PDF na memoria com Itext e enviado
		// para processamento, caso o word n�o tenha criado, continua a informa��o que vem do banco
		convertWORD =false;
		PdfReader reader = new PdfReader(bnArquivoSign);
		HashMap<String, String> pdfinfo = reader.getInfo();
		if (!reader.isEncrypted())
		{
			if (pdfinfo.get("Producer")!=null)
			{
				if (pdfinfo.get("Producer").toUpperCase().contains(MSWORD.toUpperCase()))
    			{
					convertWORD =true;
					return doMerge(bnArquivoSign);
    			}
			}
		}
		return bnArquivoSign;
	}
	
	private static byte[] doMerge(byte[] bnArquivoSign) throws DocumentException, IOException 
	{
		com.itextpdf.text.Document contratoPDF = new com.itextpdf.text.Document();
		ByteArrayOutputStream baosPDF = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(contratoPDF, baosPDF);
		contratoPDF.open();
		PdfContentByte cb = writer.getDirectContent();
		PdfReader reader = new PdfReader(bnArquivoSign);
		for (int i = 1; i <= reader.getNumberOfPages(); i++) 
		{
			contratoPDF.newPage();
			PdfImportedPage page = writer.getImportedPage(reader, i);
			cb.addTemplate(page, 0, 0);
		}
		contratoPDF.close();
		return  baosPDF.toByteArray();
	}
	
	public static byte[] validarOfficeConversaoPDFtoPNG(byte[] pngFile) throws Exception
	{
		// erro 429 convers�o para PNG, � rescrito o PDF na memoria com Itext e enviado
		// para processamento, caso o word n�o tenha criado, continua a informa��o que vem do banco
		if (isConvertWORD())
		{
			return validarOfficeConversaoPNG(pngFile);
		}
		return pngFile;
	}
	
	private static byte[] validarOfficeConversaoPNG(byte[] pngFile) throws Exception
	{
		Image imagem = null;  
        imagem 				= ImageIO.read(new ByteArrayInputStream(pngFile));  
        int new_w 			= imagem.getWidth(null);
        int new_h 			= imagem.getHeight(null);
        Image thumbs 		= imagem.getScaledInstance(new_w, new_h,BufferedImage.SCALE_SMOOTH);
        BufferedImage new_img = null;
        if (hasAlpha(imagem)) 
        	new_img 		= new BufferedImage(new_w, new_h, BufferedImage.TYPE_INT_ARGB);
        else
        	new_img 		= new BufferedImage(new_w, new_h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = new_img.createGraphics();
        if (hasAlpha(imagem))
        {
        	g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER));
        	g.drawImage(thumbs, 0, 0, Color.WHITE, null);
        }
        else
        	g.drawImage(thumbs, 0, 0, null);
        g.dispose();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(new_img, "png", baos);
		new_img.flush();
        return baos.toByteArray();
	}
	
	public static boolean hasAlpha(Image image) 
	{
	    if (image instanceof BufferedImage) 
	    {
	        BufferedImage bimage = (BufferedImage)image;
	        return bimage.getColorModel().hasAlpha();
	    }
	    PixelGrabber pg = new PixelGrabber(image, 0, 0, 1, 1, false);
	    try 
	    {
	        pg.grabPixels();
	    } 
	    catch (InterruptedException e) 
	    {
	    	e.printStackTrace();
	    }
	    ColorModel cm = pg.getColorModel();
	    return cm.hasAlpha();
	}
	
	public static boolean isConvertWORD() {
		return Util.convertWORD;
	}

	public static void setConvertWORD(boolean p_convertWORD) {
		Util.convertWORD = p_convertWORD;
	}

	
	public static ByteArrayOutputStream byteArrayFromInputStream(InputStream inputStream) throws IOException 
	{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		int aByte = inputStream.read();
		while (aByte != -1) {
			baos.write(aByte);
			aByte = inputStream.read();
		}
		return baos;
	}
	
	public static byte[] getBytesFromFile(File file) 
	{
		InputStream is;
		byte[] bytes = null;
		try {
			int offset = 0;
			int numRead = 0;

			is = new FileInputStream(file);
			bytes = new byte[(int) file.length()];
			
			while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
				offset += numRead;
			}

			if (offset < bytes.length) {
				throw new IOException("Could not completely read file "	+ file.getName());
			}

			is.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bytes;
	}
	
	public static int retornaNumeroPaginasDocumentoPDF(byte[] arquivoPDF)
	{
		int tmpResult 			= 0;
		PdfReader reader 		= null;
		try 
		{
			try 
			{
				reader = new PdfReader(arquivoPDF);
			} 
			catch (Exception e) 
			{
				try 
				{
					reader = new PdfReader(arquivoPDF, new byte[0]);
				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();
				}
			}
			tmpResult = reader.getNumberOfPages();
		} 
		catch (Exception e) 
		{
			tmpResult = -1;
		} 
		finally 
		{
			if (reader != null) 
			{
				try 
				{
					reader.close();
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		}
		return tmpResult;
	}
	
	private static String getTempDir()
	{
	    return System.getProperty("java.io.tmpdir");
	}
	
	/**
	 * Carrega o KeyStore de um File
	 */
	public static KeyStore getKeyStoreFromFile(File keystoreFile, String storeType, String storePass) throws Exception {
		KeyStore keyStore = KeyStore.getInstance(storeType);
		InputStream is = new FileInputStream(keystoreFile);
		keyStore.load(is, storePass.toCharArray());
		is.close();
		
		return keyStore;
	}
	
	
	/**
	 * Carrega o keyStore de um InputStream
	 */
	public static KeyStore getKeyStoreFromBytes(InputStream keystoreFile, String storeType, String storePass) throws Exception {
		KeyStore keyStore = KeyStore.getInstance(storeType);
		InputStream is = keystoreFile;
		keyStore.load(is, storePass.toCharArray());
		is.close();

		return keyStore;
	}
	
	/**
	 * Extrai a chave privada do arquivo de KeyStore.
	 */
	public static PrivateKey getPrivateKey(KeyStore keyStore, String alias, String keyPass) throws Exception {
		Key key = keyStore.getKey(alias, keyPass.toCharArray());
		if (key instanceof PrivateKey) {
			return (PrivateKey) key;
		}
		return null;
	}
	
	/**
	 * Extrai a chave publica do arquivo de KeyStore.
	 */
	public static PublicKey getPublicKey(KeyStore keyStore, String alias) throws Exception {
		Certificate c = keyStore.getCertificate(alias);
		PublicKey p = c.getPublicKey();
		return p;
	}
	
	/**
	 * Extrai a chave publica do arquivo de KeyStore.
	 */
	public static Certificate[] getCertificateChain(KeyStore keyStore, String alias) throws Exception {
		return keyStore.getCertificateChain(alias);
	}
	
	/**
	 * Extrai a chave p�blica do arquivo de KeyStore.
	 */
	public static Certificate getCertificate(KeyStore keyStore, String alias) throws Exception {
		return keyStore.getCertificate(alias);
	}
	
	public static String genHashSha1(String entrada) throws Exception
	{
		MessageDigest md = MessageDigest.getInstance("SHA1");
        byte[] messageDigest = md.digest(entrada.getBytes());
        BigInteger number = new BigInteger(1, messageDigest);
        String hashtext = number.toString(16);
        while (hashtext.length() < 32) {
            hashtext = "0" + hashtext;
        }
		return hashtext;
	}
	
	public static BufferedImage getBufferedImageFromBytes(byte[] bytes) throws IOException
	{
		InputStream in = new ByteArrayInputStream(bytes);
		BufferedImage bImageFromConvert = ImageIO.read(in);
		in.close();
		return bImageFromConvert;
	}
	
	public static byte[] getBytesFromBufferedImage(BufferedImage bufferedImage, String extensao) throws IOException
	{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(bufferedImage, extensao, baos);
		baos.flush();
		byte[] imageInByte = baos.toByteArray();
		baos.close();
		
		return imageInByte;
	}
	
}