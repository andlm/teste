/*  1:   */ package br.com.virtuoso.prosaude.utils;
/*  2:   */ 
/*  3:   */ import java.util.Locale;
/*  4:   */ 
/*  5:   */ public class UtilLocale
/*  6:   */ {
/*  7:11 */   private static Locale localePadrao = new Locale("pt", "BR");
/*  8:   */   
/*  9:   */   public static Locale getLocale()
/* 10:   */   {
/* 11:14 */     return localePadrao;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static void setLocale(Locale locale)
/* 15:   */   {
/* 16:18 */     localePadrao = locale;
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilLocale
 * JD-Core Version:    0.7.0.1
 */