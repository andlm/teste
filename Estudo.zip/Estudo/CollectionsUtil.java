package com.nexxera.pds.utility;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Classe com utilitarios para colecoes de dados.
 * 
 * @author isaac.souza
 *
 */
public class CollectionsUtil
{

	/**
	 * Verifica se a colecao e nula e inicializa ela caso seja. Se nao for nula retorna a colecao original.
	 * @param list Colecao a ser verifica e inicializada se necessario
	 * @return retorna colecao original ou a inicializada se a original for nula
	 */
	public static List getInitializeIfNull(List list)
	{
		if (list == null)
		{
			return new ArrayList();
		}
		return list;
	}

	/**
	 * Faz a juncao de varias listas em uma unica lista
	 * @param <T> Tipo de classe existente da lista
	 * @param listas listas a serem unidas
	 * @return Lista com a juncao de todas as listas recebidas 
	 */
	public static <T> List<T> joinLists(List<T>... lists)
	{
		List<T> listAll = new ArrayList<T>();
		if (lists != null)
		{
			for (List<T> list : lists)
			{
				listAll.addAll(getInitializeIfNull(list));
			}
		}

		return listAll;
	}

	/**
	 * Verifica se a colecao e nula ou vazia
	 * @param collection colecao a ser verificada se esta nula ou vazia
	 * @return True se colecao vazia ou nula e false se colecao conter dados.
	 */
	public static boolean isEmpty(Collection collection)
	{
		return (collection == null || collection.isEmpty());
	}
	
	/**
	 * Limpa a colecao, verificando antes se esta noa e nula
	 * @param collection colecao a ser limpa
	 */
	public static void clear(Collection collection)
    {	
    	if (!isEmpty(collection)){
    		collection.clear();
    	}
    }

}
