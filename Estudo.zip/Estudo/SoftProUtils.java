package com.nexxera.pds.utility;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.itextpdf.text.pdf.PdfAnnotation;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.nexxera.pds.entity.Contratoarquivo;
import com.nexxera.pds.entity.Contratoassinatura;
import com.nexxera.pds.entity.Contratoassinaturaservico;
import com.nexxera.pds.service.ContratoArquivoService;
import com.nexxera.pds.service.ContratoServiceAspose;
import com.nexxera.pds.webservice.movel.entity.Variavel;
import com.nexxera.pds.webservice.server.RegiaoCaixaAssinatura;
import com.nexxera.pds.webservice.server.Util;

import de.softpro.doc.Rect;
import de.softpro.doc.SignDocDocument;
import de.softpro.doc.SignDocDocumentLoader;
import de.softpro.doc.SignDocException;
import de.softpro.doc.SignDocField;
import de.softpro.doc.SignDocFieldExistsException;
import de.softpro.doc.SignDocFindTextPosition;
import de.softpro.doc.SignDocRGBColor;
import de.softpro.doc.SignDocRenderOutput;
import de.softpro.doc.SignDocRenderParameters;
import de.softpro.doc.SignDocSignatureParameters;
import de.softpro.doc.SignDocUnexpectedErrorException;
import de.softpro.doc.SignDocVerificationResult;


@Name("softProUtils")
@Scope(ScopeType.APPLICATION)
//TODO:Classe somenRte de Estudo da SOFTPRO (Foi removida do Servidor)
public class SoftProUtils 
{
	private SignDocDocumentLoader signDocDocumentLoader 	= null;
	private SignDocDocument signDocDocument 				= null;
	
	public SoftProUtils() throws SignDocException 
	{
		signDocDocumentLoader = new SignDocDocumentLoader ();
		SignDocDocumentLoader.initLicenseManager(423343885, 1494518706);
	}
	
	public com.nexxera.pds.webservice.server.RegiaoCaixaAssinatura carregaContratoBaseCaixaAssinatura(Contratoassinatura contratoassinatura, String assinatura) throws Exception
	{
		File tempFile 			= null;
		try
		{
			tempFile 			= File.createTempFile("pdf", null, new File(System.getProperty("java.io.tmpdir")));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new Exception("Error ao criar/acessar arquivo PDF/SoftPro:"+ e.getMessage());
		}
		try
		{
			// TODO: necessita gravar na base quando tiver OK, o processo com a SoftPro, devera receber o c�digo do contrato
			// pesquisar usando a fun��o abaixo
			Contratoarquivo contratoArquivo = 
					SeamUtils.getComponent(ContratoArquivoService.class).
							consultaContratoArquivoPorContrato(contratoassinatura.getCdContrato());
			if (contratoArquivo==null)
				throw new Exception("Contrato n�o encontrado");
			
			FileOutputStream contratoArquivoTemp = new FileOutputStream(tempFile);
			contratoArquivoTemp.write(contratoArquivo.getBnArquivoSign());
			contratoArquivoTemp.close();
			
			System.out.println("user path="+System.getProperty("java.io.tmpdir"));
			System.out.println("pdf tmp(System.getProperty(java.io.tmpdir))="+tempFile.getAbsolutePath());
			signDocDocument = signDocDocumentLoader.loadFromFile (tempFile.getAbsolutePath(), true);
			if (signDocDocument == null)
				throw new Exception("Contrato n�o encontrado");
			tempFile.delete();
			
			com.nexxera.pds.webservice.server.RegiaoCaixaAssinatura regiaoCaixaAssinatura=null;
			
			if (assinatura !=null && contratoassinatura.getCdContrato().getCdTipooperacao().isFgAssinaturasfixa())
				regiaoCaixaAssinatura = adicionarCampoAssinaturaPorString(assinatura);
			else
				regiaoCaixaAssinatura = adicionarCampoAssinaturaPorCoordenadas(contratoassinatura);
			
			if (regiaoCaixaAssinatura!=null)
				contratoArquivo.setNumeroPaginaAtual(regiaoCaixaAssinatura.getNumeroPagina());
			
			return regiaoCaixaAssinatura;
		}
		catch (Exception e)
		{
			tempFile.delete();
			e.printStackTrace();
			throw new Exception("Error:"+ e.getMessage());
		}
	}
	
	
	public List<Variavel> carregaContratoBase(byte[] contratoPDFForm) throws Exception
	{
		File tempFile 			= null;
		try
		{
			tempFile 			= File.createTempFile("pdf", null, new File(System.getProperty("java.io.tmpdir")));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new Exception("Error ao criar/acessar arquivo PDF/SoftPro:"+ e.getMessage());
		}
		try
		{
			// TODO: necessita gravar na base quando tiver OK, o processo com a SoftPro, devera receber o c�digo do contrato
			// pesquisar usando a fun��o abaixo
			FileOutputStream contratoArquivoTemp = new FileOutputStream(tempFile);
			contratoArquivoTemp.write(contratoPDFForm);
			contratoArquivoTemp.close();
			
			System.out.println("user path="+System.getProperty("java.io.tmpdir"));
			System.out.println("pdf tmp(System.getProperty(java.io.tmpdir))="+tempFile.getAbsolutePath());
			signDocDocument = signDocDocumentLoader.loadFromFile (tempFile.getAbsolutePath(), true);
			if (signDocDocument == null)
				throw new Exception("Contrato n�o encontrado");
			tempFile.delete();
			
			SignDocField[] fields 			= signDocDocument.getFields(0); 
			List<Variavel> listaVariaveis 	= new ArrayList<Variavel>();
			for (SignDocField signDocField : fields) 
			{
				Variavel variavel = new Variavel();
				switch (signDocField.getType()) 
				{
					case SignDocField.t_text:
					{
						variavel.setNomeVariavel(
									signDocField.getName().replace("\\","").trim().toUpperCase());
						variavel.setNomeCampoOriginal(signDocField.getName());
						variavel.setTipoVariavel(String.valueOf(signDocField.getType()));
					} break;
					case SignDocField.t_signature_digsig:
					{
						variavel.setNomeVariavel(signDocField.getName());
						variavel.setNomeCampoOriginal(signDocField.getName());
						variavel.setTipoVariavel(String.valueOf(signDocField.getType()));
					} break;
				}
				if (variavel.getNomeVariavel()!=null)
				{
					variavel.setValorVariavel("");
					listaVariaveis.add(variavel);
				}
			}
			
			List<Variavel> listaOrdenada = new ArrayList<Variavel>(listaVariaveis);
			Collections.sort(listaOrdenada, new Comparator<Variavel>()
			{
				public int compare(Variavel o1, Variavel o2) 
				{
					return o1.getTipoVariavel().compareTo(o2.getTipoVariavel());
				}
			});
			return listaVariaveis;
		}
		catch (Exception e)
		{
			tempFile.delete();
			e.printStackTrace();
			throw new Exception("Error:"+ e.getMessage());
		}
	}
	
	
	public Contratoarquivo carregaContratoBase(Contratoassinatura contratoassinatura, String assinatura) throws Exception
	{
		File tempFile 			= null;
		try
		{
			tempFile 			= File.createTempFile("pdf", null, new File(System.getProperty("java.io.tmpdir")));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new Exception("Error ao criar/acessar arquivo PDF/SoftPro:"+ e.getMessage());
		}
		try
		{
			// TODO: necessita gravar na base quando tiver OK, o processo com a SoftPro, devera receber o c�digo do contrato
			// pesquisar usando a fun��o abaixo
			Contratoarquivo contratoArquivo = 
					SeamUtils.getComponent(ContratoArquivoService.class).
							consultaContratoArquivoPorContrato(contratoassinatura.getCdContrato());
			if (contratoArquivo==null)
				throw new Exception("Contrato n�o encontrado");
			
			FileOutputStream contratoArquivoTemp = new FileOutputStream(tempFile);
			contratoArquivoTemp.write(contratoArquivo.getBnArquivoSign());
			contratoArquivoTemp.close();
			
			System.out.println("user path="+System.getProperty("java.io.tmpdir"));
			System.out.println("pdf tmp(System.getProperty(java.io.tmpdir))="+tempFile.getAbsolutePath());
			signDocDocument = signDocDocumentLoader.loadFromFile (tempFile.getAbsolutePath(), true);
			if (signDocDocument == null)
				throw new Exception("Contrato n�o encontrado");
			tempFile.delete();
			
			com.nexxera.pds.webservice.server.RegiaoCaixaAssinatura regiaoCaixaAssinatura=null;
			
			if (assinatura !=null && contratoassinatura.getCdContrato().getCdTipooperacao().isFgAssinaturasfixa())
				regiaoCaixaAssinatura = adicionarCampoAssinaturaPorString(assinatura);
			else
				regiaoCaixaAssinatura = adicionarCampoAssinaturaPorCoordenadas(contratoassinatura);
			
			if (regiaoCaixaAssinatura!=null)
			{
				contratoArquivo.setAlturaPagina(signDocDocument.getPageHeight(regiaoCaixaAssinatura.getNumeroPagina()));
				contratoArquivo.setLarguraPagina(signDocDocument.getPageWidth(regiaoCaixaAssinatura.getNumeroPagina()));
				contratoArquivo.setNumeroPaginaAtual(regiaoCaixaAssinatura.getNumeroPagina());
				contratoArquivo.setRegiaoCaixaAssinatura(regiaoCaixaAssinatura);
			}
			regiaoCaixaAssinatura =null;
			return contratoArquivo;
		}
		catch (Exception e)
		{
			tempFile.delete();
			e.printStackTrace();
			throw new Exception("Error:"+ e.getMessage());
		}
	}
	
	
	public int assinarPdfMovelComFotoTSAComCertificadoNexxera(boolean assinaturaBiometricaMovelSoftpro, 
															  byte[] bytesImagemAssinatura, String assinatura, 
															  Contratoassinatura contratoassinatura,
															  com.nexxera.pds.webservice.movel.entity.Contratoassinatura contratoAssinaturaCadastro) throws Exception
	{
			
		File tempFile 			= null;
		try
		{
			tempFile 			= File.createTempFile("pdf", null, new File(System.getProperty("java.io.tmpdir")));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new Exception("Error ao criar/acessar arquivo PDF/SoftPro:"+ e.getMessage());
		}
		try
		{
			com.nexxera.pds.webservice.server.RegiaoCaixaAssinatura regiaoCaixaAssinatura=null;
			// TODO: necessita gravar na base quando tiver OK, o processo com a SoftPro, devera receber o c�digo do contrato
			// pesquisar usando a fun��o abaixo
			Contratoarquivo contratoArquivo = 
					SeamUtils.getComponent(ContratoArquivoService.class).
							consultaContratoArquivoPorContrato(contratoassinatura.getCdContrato());
			if (contratoArquivo==null)
				throw new Exception("Contrato n�o encontrado");
			
			FileOutputStream contratoArquivoTemp = new FileOutputStream(tempFile);
			contratoArquivoTemp.write(contratoArquivo.getBnArquivoSign());
			contratoArquivoTemp.close();
			
			System.out.println("user path="+System.getProperty("java.io.tmpdir"));
			System.out.println("pdf tmp(System.getProperty(java.io.tmpdir))="+tempFile.getAbsolutePath());
			SignDocDocument doc = signDocDocumentLoader.loadFromFile (tempFile.getAbsolutePath(), true);
			if (signDocDocument != null)
				signDocDocument.close ();
			signDocDocument 	= doc;
			
			if (signDocDocument == null)
				throw new Exception("Contrato n�o encontrado");
			else
			{
				byte[] contratoArquivoPDFAssinado = contratoArquivo.getBnArquivoSign();
				
				
				if (assinatura!=null && contratoassinatura.getCdContrato().getCdTipooperacao().isFgAssinaturasfixa())
				{
					if (assinaturaBiometricaMovelSoftpro)
						regiaoCaixaAssinatura =adicionarCampoAssinaturaPorString(assinatura);
					else	
						regiaoCaixaAssinatura =adicionarCampoFotoAssinaturaPorString(assinatura);
				}
				else
					regiaoCaixaAssinatura = adicionarCampoAssinaturaPorCoordenadas(contratoassinatura);
				
				byte[] bytesImagemOriginal = bytesImagemAssinatura; 
				contratoArquivoPDFAssinado = SeamUtils.getComponent(ContratoServiceAspose.class).
							validarUtilizacaoCarimboTempoMovelSoftPro(
									regiaoCaixaAssinatura, contratoArquivoPDFAssinado, bytesImagemOriginal,contratoAssinaturaCadastro);
		  	
				contratoArquivo.setBnArquivo(contratoArquivoPDFAssinado);
				contratoArquivo.setBnArquivoSign(contratoArquivoPDFAssinado);
				contratoArquivo.setTamanhoArquivo(contratoArquivoPDFAssinado.length/1024);
				SeamUtils.getComponent(ContratoArquivoService.class).editar(contratoArquivo);
		    	
		    	System.out.println("Document signed");
			}
			
			if (signDocDocument != null)
				signDocDocument.close ();
			if (doc != null)
				doc.close ();
			tempFile.delete();
			
			return regiaoCaixaAssinatura.getNumeroPagina();
		}
		catch (Exception e)
		{
			tempFile.delete();
			e.printStackTrace();
			throw new Exception("Error:"+ e.getMessage());
		}
	}
	
	public void assinarPdfComFotoTSAComCertificadoNexxera(boolean assinaturaBiometricaMovelSoftpro, 
														  byte[] contratoArquivoPDFSemAssinar,
														  byte[] bytesImagemAssinatura, String assinatura, 
														  Contratoassinatura contratoassinatura,
														  com.nexxera.pds.webservice.movel.entity.Contratoassinatura 
														  		contratoassinaturaWS) throws Exception
	{
		File tempFile 			= null;
		try
		{
			tempFile 			= File.createTempFile("pdf", null, new File(System.getProperty("java.io.tmpdir")));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new Exception("Error ao criar/acessar arquivo PDF/SoftPro:"+ e.getMessage());
		}
		try
		{
			FileOutputStream contratoArquivoTemp = new FileOutputStream(tempFile);
			contratoArquivoTemp.write(contratoArquivoPDFSemAssinar);
			contratoArquivoTemp.close();
			
			System.out.println("user path="+System.getProperty("java.io.tmpdir"));
			System.out.println("pdf tmp(System.getProperty(java.io.tmpdir))="+tempFile.getAbsolutePath());
			SignDocDocument doc = signDocDocumentLoader.loadFromFile (tempFile.getAbsolutePath(), true);
			if (signDocDocument != null)
				signDocDocument.close ();
			signDocDocument 	= doc;
			
			if (signDocDocument == null)
				throw new Exception("Contrato n�o encontrado");
			else
			{
				byte[] contratoArquivoPDFAssinado = contratoArquivoPDFSemAssinar;
				com.nexxera.pds.webservice.server.RegiaoCaixaAssinatura regiaoCaixaAssinatura=null;
				
				if (assinatura!=null && contratoassinatura.getCdContrato().getCdTipooperacao().isFgAssinaturasfixa())
				{
					if (assinaturaBiometricaMovelSoftpro)
						regiaoCaixaAssinatura =adicionarCampoAssinaturaPorString(assinatura);
					else	
						regiaoCaixaAssinatura =adicionarCampoFotoAssinaturaPorString(assinatura);
				}
				else
					regiaoCaixaAssinatura = adicionarCampoAssinaturaPorCoordenadas(contratoassinatura);
				
				byte[] bytesImagemOriginal 	= bytesImagemAssinatura; 
				SignDocField field 			= new SignDocField ();
				field.setEmptyFieldColor(new SignDocRGBColor(255, 0, 0));
				field.setType(SignDocField.t_signature_digsig);
				if (assinatura!=null)
					field.setName(assinatura);
				else
				{
					String nomeCampo=null;
					String caixaAssinaturaCPFSelecionado=null;
					Contratoassinaturaservico contratoassinaturaservico=new Contratoassinaturaservico();
					contratoassinaturaservico.setCdContratoassinatura(contratoassinatura);
					caixaAssinaturaCPFSelecionado=SeamUtils.getComponent(ContratoServiceAspose.class).formataCaixaAssinatura(contratoassinaturaservico);
					if (caixaAssinaturaCPFSelecionado!=null)
						nomeCampo = caixaAssinaturaCPFSelecionado;
					else
					{
						nomeCampo= StringUtils.uniqueTempFile();
						nomeCampo= nomeCampo.substring(0, nomeCampo.length()-7);
					}
					field.setName(nomeCampo);
					assinatura=nomeCampo;
				}
	        	field.setPage(regiaoCaixaAssinatura.getNumeroPagina());
	 	        field.setLeft(regiaoCaixaAssinatura.getXEsquerda().doubleValue());
	 	        field.setBottom(regiaoCaixaAssinatura.getYBase().doubleValue());
	 	        field.setRight(regiaoCaixaAssinatura.getXDireita().doubleValue());
	 	        field.setTop(regiaoCaixaAssinatura.getYTopo().doubleValue());
		    	try
		        {
		        	int state = 5;
		        	try 
		        	{
		        		state = signDocDocument.verifySignature(field.getName()).getState();
					} 
		        	catch (Exception e) 
					{
		        		System.out.println("n�o foi assinado ainda");
					}
		        	switch (state) 
		        	{
						case SignDocVerificationResult.ss_empty:
							signDocDocument.addField(field, SignDocDocument.sff_font_fail);
							break;
						case SignDocVerificationResult.ss_unmodified:
							break;
						default:
							System.out.println("Status :"+state);
							break;
					}
		        }
		        catch (SignDocFieldExistsException e)
		        {
		        	System.out.println("Usu�rio j� assinou este contrato");
		        }
				assinarPdfSemTSASemCertificadoNexxera(assinatura, bytesImagemOriginal);

				signDocDocument.saveToFile(null, SignDocDocument.sf_incremental);
				if (signDocDocument != null)
					signDocDocument.close ();
				if (doc != null)
					doc.close ();
				
				contratoArquivoPDFAssinado = Util.getBytesFromFile(new File(tempFile.getAbsolutePath()));
								
				if (contratoassinaturaWS!=null)
				{
					if (regiaoCaixaAssinatura.getNumeroPagina() != null)
						contratoassinaturaWS.setNumeroPagina(regiaoCaixaAssinatura.getNumeroPagina().longValue());

					if (contratoassinaturaWS.getLatitudeGPS()!=null && contratoassinaturaWS.getLongitudeGPS()!=null)
					{
						StringBuffer buffer = new StringBuffer();
						buffer.append("Latitude    :"+StringUtils.getGeoPosicionamento(contratoassinaturaWS.getLatitudeGPS()));
						buffer.append("\n");
						buffer.append("Longitude   :"+StringUtils.getGeoPosicionamento(contratoassinaturaWS.getLongitudeGPS()));
						buffer.append("\n");
						String endereco 	= contratoassinaturaWS.toStringEndereco();
						if (endereco != null) 
						{
							buffer.append("Endere�o    :"+endereco);
							buffer.append("\n");
						}
						
						PdfReader reader = new PdfReader(tempFile.getAbsolutePath());
						ByteArrayOutputStream baos =new ByteArrayOutputStream();
						boolean appendPDF =true;
						PdfStamper stamper = new PdfStamper(reader, baos ,reader.getPdfVersion(),appendPDF);
						PdfAnnotation pdfAnnotation = PdfAnnotation.createText(stamper.getWriter(), 
								regiaoCaixaAssinatura.getItextRectangle(),
				                	"GPS Informa\u00E7\u00E3o", buffer.toString(), false,  "Note");
						String nomeAnotacao=StringUtils.uniqueTempFile();
						nomeAnotacao= nomeAnotacao.substring(0, nomeAnotacao.length()-7);
						pdfAnnotation.setName(nomeAnotacao);
						stamper.addAnnotation(pdfAnnotation, regiaoCaixaAssinatura.getNumeroPagina());
						stamper.close();
				        reader.close();
				        
				        contratoArquivoPDFAssinado = baos.toByteArray();
//						Point pontoInferiorEsquerdo = new Point(x1, y1);
//						Point pontoSuperiorDireito 	= new Point(x2, y2);
//						
//						SignDocAnnotation SignDocAnnotation = signDocDocument.createFreeTextAnnotation(
//								pontoInferiorEsquerdo, pontoSuperiorDireito);
//						String nomeAnotacao=StringUtils.uniqueTempFile();
//						nomeAnotacao= nomeAnotacao.substring(0, nomeAnotacao.length()-7);
//						SignDocAnnotation.setName(nomeAnotacao);
//						SignDocAnnotation.setColor(new SignDocRGBColor(0,0,0));
//						SignDocAnnotation.setLineWidthInPoints(1);
//						SignDocAnnotation.setOpacity(0.5);
//						SignDocAnnotation.addPoint(pontoInferiorEsquerdo);
//						SignDocAnnotation.addPoint(pontoSuperiorDireito);
//
//						String aFont = "Helvetica";
//						double aFontSize = 10;
//						int aHAlignment = de.softpro.doc.SignDocAnnotation.ha_center ;
//						SignDocAnnotation.setPlainText(buffer.toString(), aFont, aFontSize, aHAlignment);
//						
//						signDocDocument.addAnnotation(field.getPage(), SignDocAnnotation);
					}
				}
								
				Contratoarquivo contratoArquivo = 
						SeamUtils.getComponent(ContratoArquivoService.class).
								consultaContratoArquivoPorContrato(contratoassinatura.getCdContrato());
				if (contratoArquivo==null)
					throw new Exception("Contrato n�o encontrado");
				contratoArquivo.setBnArquivo(contratoArquivoPDFAssinado);
				contratoArquivo.setBnArquivoSign(contratoArquivoPDFAssinado);
				contratoArquivo.setTamanhoArquivo(contratoArquivoPDFAssinado.length/1024);
				SeamUtils.getComponent(ContratoArquivoService.class).editar(contratoArquivo);
		    	System.out.println("Document signed");
			}
			tempFile.delete();
		}
		catch (Exception e)
		{
			tempFile.delete();
			e.printStackTrace();
			throw new Exception("Error:"+ e.getMessage());
		}
	}
	
	private boolean assinarPdfSemTSASemCertificadoNexxera(String field_name, byte[] assinaturaUsuario) throws Exception
	{
		try
		{
			String profile 							= "";
			int key_size 							= 1024;          

			SignDocSignatureParameters signDocSignatureParametersAssinatura = signDocDocument.createSignatureParameters (field_name, profile);
			int pr = signDocSignatureParametersAssinatura.setInteger ("GenerateKeyPair", key_size);
			check (signDocSignatureParametersAssinatura, pr, "setInteger(GenerateKeyPair)");
			
			pr = signDocSignatureParametersAssinatura.setInteger ("Method", SignDocSignatureParameters.m_digsig_pkcs7_detached);
			check (signDocSignatureParametersAssinatura, pr, "setInteger(Method)");
			
			pr = signDocSignatureParametersAssinatura.setBlob ("BiometricData", assinaturaUsuario);
			clear (assinaturaUsuario);
			check (signDocSignatureParametersAssinatura, pr, "setBlob(BiometricData)");
	        
			Date data = new Date();
			String diaAtual = new SimpleDateFormat("yyyy-MM-dd").format(data);
			String horaAtual = new SimpleDateFormat("HH:mm:ss").format(data);
			String dataAtual = diaAtual + 'T' + horaAtual;
			
//			pr = signDocSignatureParametersAssinatura.setString ("SignTime", dataAtual);
//			check (signDocSignatureParametersAssinatura, pr, "setString(SignTime)");

			pr = signDocSignatureParametersAssinatura.setString ("Timestamp", dataAtual);
			check (signDocSignatureParametersAssinatura, pr, "setString(Timestamp)");
			
//			pr = signDocSignatureParametersAssinatura.setString ("Reason", "Motivo");
//			check (signDocSignatureParametersAssinatura, pr, "setString(Reason)");

//			pr = signDocSignatureParametersAssinatura.setString ("Location", "Location");
//			check (signDocSignatureParametersAssinatura, pr, "setString(Location)");

			//TODO: N�O POR EM PRODU��O ESTE PARAMETRO
	        String contextURL = ResourceProperties.getUrslApp(ResourceProperties.URL_PORTAL_PDS);
			if (com.nexxera.pds.entity.enums.TipoAmbientes.checarUtilizacaoCarimboTempo(contextURL)) 	
			{
//		        pr = signDocSignatureParametersAssinatura.setString ("TimeStampServerURL", "http://ca.signfiles.com/TSAServer.aspx");
				//pr = signDocSignatureParametersAssinatura.setString ("TimeStampServerURL", "https://flnws002dev.nexxera.com/tsa");
//				check (signDocSignatureParametersAssinatura, pr, "setString(TimeStampServerURL)");
			}
            
            pr = signDocSignatureParametersAssinatura.setString ("PKCS#12Password", ResourceProperties.getUrslApp("pass.cert.pds"));
            check (signDocSignatureParametersAssinatura, pr, "setString(PKCS#12Password)");
            
            signDocSignatureParametersAssinatura.setBlob("Certificate", Util.getBytesFromFile(new File(ResourceProperties.getUrslApp("url.cert.pds"))));
            check (signDocSignatureParametersAssinatura, pr, "setBlob(Certificate)");
			
			pr = signDocSignatureParametersAssinatura.setInteger ("RenderSignature", SignDocSignatureParameters.rsf_gray);
			check (signDocSignatureParametersAssinatura, pr, "setInteger(RenderSignature)");
			
			pr = signDocSignatureParametersAssinatura.setInteger ("BiometricEncryption", SignDocSignatureParameters.be_fixed);
			check (signDocSignatureParametersAssinatura, pr, "setInteger(BiometricEncryption)");
			
	        pr = signDocSignatureParametersAssinatura.setInteger ("PenWidth", 500);
	        check (signDocSignatureParametersAssinatura, pr, "setInteger(PenWidth)");

	        pr = signDocSignatureParametersAssinatura.setString ("Filter", "");
	        check (signDocSignatureParametersAssinatura, pr, "setString(Filter)");
	        
//	        pr = params.setString("Location", buffer.toString());
//			check(params, pr, "setString(Location)");
//
//			pr = params.setString("Comment", buffer.toString());
//			check(params, pr, "setString(Comment)");

	        signDocDocument.addSignature (signDocSignatureParametersAssinatura);
			signDocSignatureParametersAssinatura.destroy ();
			return true;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
	}
	
	
	public boolean validaContratoAssinado(byte[] contratoAssinado) throws Exception
	{
		boolean poosuiCampoAssinatura = false;
		File tempFile 			= null;
		try
		{
			tempFile 			= File.createTempFile("pdf", null, new File(System.getProperty("java.io.tmpdir")));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new Exception("Error ao criar/acessar arquivo PDF/SoftPro:"+ e.getMessage());
		}
		try
		{
			// TODO: necessita gravar na base quando tiver OK, o processo com a SoftPro, devera receber o c�digo do contrato
			// pesquisar usando a fun��o abaixo
			FileOutputStream contratoArquivoTemp = new FileOutputStream(tempFile);
			contratoArquivoTemp.write(contratoAssinado);
			contratoArquivoTemp.close();
			
			System.out.println("user path="+System.getProperty("java.io.tmpdir"));
			System.out.println("pdf tmp(System.getProperty(java.io.tmpdir))="+tempFile.getAbsolutePath());
			signDocDocument = signDocDocumentLoader.loadFromFile (tempFile.getAbsolutePath(), true);
			if (signDocDocument == null)
				throw new Exception("Contrato n�o encontrado");
			tempFile.delete();
			
			SignDocField[] fields 			= signDocDocument.getFields(0); 
			for (SignDocField signDocField : fields) 
			{
				switch (signDocField.getType()) 
				{
					case SignDocField.t_signature_signdoc:
					{
						poosuiCampoAssinatura = true; break;
					}
					case SignDocField.t_signature_digsig:
					{
						poosuiCampoAssinatura = true; break;
					} 
				}
			}
			if (signDocDocument != null)
				signDocDocument.close ();
		}
		catch (Exception e)
		{
			tempFile.delete();
			e.printStackTrace();
			throw new Exception("Error:"+ e.getMessage());
		}
		return poosuiCampoAssinatura;
	}
	
	
	public byte[] renderizaPaginaPDFComoImage(int numeroPagina, byte[] documentoPDF) throws Exception
	{
		double alturaPagina 	= 0;
		double larguraPagina 	= 0;
		double zoomPagina 		= 1;
		
		File tempFile 				= null;
		SignDocDocument doc = null;
		try
		{
			byte[] documentoPDFImage=null;
			try
			{
				tempFile 			= File.createTempFile("pdf", null, new File(System.getProperty("java.io.tmpdir")));
			}
			catch (Exception e)
			{
				e.printStackTrace();
				throw new Exception("Error ao criar/acessar arquivo PDF/SoftPro:"+ e.getMessage());
			}
			FileOutputStream contratoArquivoTemp = new FileOutputStream(tempFile);
			contratoArquivoTemp.write(documentoPDF);
			contratoArquivoTemp.close();
			doc = signDocDocumentLoader.loadFromFile (tempFile.getAbsolutePath(), true);
			if (doc == null)
				throw new Exception("Contrato n�o encontrado");
			else
			{
				String[] annotations = doc.getAnnotations(numeroPagina);
		        for (int i = 0; i < annotations.length; i++) 
		            doc.removeAnnotation(numeroPagina, annotations[i]);
		        
				alturaPagina 		= doc.getPageHeight(numeroPagina);
				larguraPagina 		= doc.getPageWidth(numeroPagina);
		        
				SignDocRenderParameters	params = new SignDocRenderParameters();
				params.fitRect ((int)larguraPagina,(int)alturaPagina);
				params.setFormat("png");
				params.setZoom(zoomPagina);
				params.setPage (numeroPagina);
				SignDocRenderOutput aOutput = null;
				Rect aClipRect = null;
				documentoPDFImage = doc.renderPageAsImage(aOutput, params, aClipRect); // render without signature state 
			}
			tempFile.delete();
			if (doc != null)
				doc.close ();
			return documentoPDFImage;
		}
		catch (Exception e)
		{
			tempFile.delete();
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		finally{
			doc = null;
		}
	}
		
	public byte[] renderizaPaginaPDFComoImage(int numeroPagina, double larguraPagina, double alturaPagina,double zoomPagina, byte[] documentoPDF) throws Exception
	{
		File tempFile 				= null;
		SignDocDocument doc = null;
		try
		{
			byte[] documentoPDFImage=null;
			try
			{
				tempFile 			= File.createTempFile("pdf", null, new File(System.getProperty("java.io.tmpdir")));
			}
			catch (Exception e)
			{
				e.printStackTrace();
				throw new Exception("Error ao criar/acessar arquivo PDF/SoftPro:"+ e.getMessage());
			}
			FileOutputStream contratoArquivoTemp = new FileOutputStream(tempFile);
			contratoArquivoTemp.write(documentoPDF);
			contratoArquivoTemp.close();
			doc = signDocDocumentLoader.loadFromFile (tempFile.getAbsolutePath(), true);
			if (doc == null)
				throw new Exception("Contrato n�o encontrado");
			else
			{
				String[] annotations = doc.getAnnotations(numeroPagina);
		        for (int i = 0; i < annotations.length; i++) 
		            doc.removeAnnotation(numeroPagina, annotations[i]);
		        
				SignDocRenderParameters	params = new SignDocRenderParameters();
				params.fitRect ((int)larguraPagina,(int)alturaPagina);
				params.setFormat("png");
				params.setZoom(zoomPagina);
				params.setPage (numeroPagina);
				SignDocRenderOutput aOutput = null;
				Rect aClipRect = null;
				documentoPDFImage = doc.renderPageAsImage(aOutput, params, aClipRect); // render without signature state 
			}
			tempFile.delete();
			if (doc != null)
				doc.close ();
			return documentoPDFImage;
		}
		catch (Exception e)
		{
			tempFile.delete();
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		finally{
			doc = null;
		}
	}
		
	private static void check (SignDocSignatureParameters params, int code,	 String function) throws Exception
	{
		if (code != SignDocSignatureParameters.rc_ok)
			throw new Exception(function + " failed, error code " + code + ": " + params.getErrorMessage ());
	}

	private com.nexxera.pds.webservice.server.RegiaoCaixaAssinatura adicionarCampoAssinaturaPorCoordenadas(Contratoassinatura contratoassinatura) throws SignDocException 
	{
		RegiaoCaixaAssinatura regiaoCaixaAssinatura = new RegiaoCaixaAssinatura();
		
		regiaoCaixaAssinatura.setNumeroPagina(contratoassinatura.getNumeroPagina().intValue());
		regiaoCaixaAssinatura.setXDireita(new Float(contratoassinatura.getNumeroPosicaoXDireita()));
		regiaoCaixaAssinatura.setXEsquerda(new Float(contratoassinatura.getNumeroPosicaoXEsquerda()));
		regiaoCaixaAssinatura.setYBase(new Float(contratoassinatura.getNumeroPosicaoYBase()));
		regiaoCaixaAssinatura.setYTopo(new Float(contratoassinatura.getNumeroPosicaoYTopo()));
		
		return regiaoCaixaAssinatura;
	}
	
	private com.nexxera.pds.webservice.server.RegiaoCaixaAssinatura adicionarCampoFotoAssinaturaPorString(String textoBuscaCampoAssinatura) throws SignDocException 
	{
	    int startPage 			 = 1;
	    int endPage				 = signDocDocument.getPageCount();
	    int flags 				 = SignDocDocument.ftf_ignore_hspace;
	    double heigntDimensionar = 50;
	    double widthDimensionar  = 70;
	    
	    SignDocFindTextPosition[] arrSignDocFindTextPosition = signDocDocument.findText(startPage, endPage, textoBuscaCampoAssinatura, flags);
	    if (arrSignDocFindTextPosition==null || arrSignDocFindTextPosition.length==0) 
	    	throw new SignDocUnexpectedErrorException(
	    				"Palavra chave das assinaturas do contrato n�o encontrada: " + textoBuscaCampoAssinatura);
	    
	    RegiaoCaixaAssinatura regiaoCaixaAssinatura = new RegiaoCaixaAssinatura();
	    
	    for (int i = 0; i < arrSignDocFindTextPosition.length; i++) 
	    {
	    	SignDocFindTextPosition signDocFindTextPosition = arrSignDocFindTextPosition[i]; 
	    	
	    	int diferenca			= 5;
			double xDireita			= signDocFindTextPosition.mLast.mRef.mX;
			double xEsquerda		= signDocFindTextPosition.mFirst.mRef.mX; 
			double larguraCaixa		= (xDireita-xEsquerda);
			double centroCaixa      = xEsquerda + (larguraCaixa/2);
			xEsquerda 				= centroCaixa - (widthDimensionar / 2); 
			xDireita                = centroCaixa + (widthDimensionar / 2);
			double yBase 			= (signDocFindTextPosition.mFirst.mRef.mY)-diferenca;
			double yTopo 			= (yBase+larguraCaixa)-diferenca;
			double alturaCaixa 		= (yTopo - yBase);
			
			regiaoCaixaAssinatura.setNumeroPagina(arrSignDocFindTextPosition[0].mFirst.mPage);
			
			float[] dimensoes = MathUtils.redimensiona((float)alturaCaixa, (float)heigntDimensionar, (float)larguraCaixa, (float)widthDimensionar);
			
			regiaoCaixaAssinatura.setXDireita(new Float(xEsquerda) + dimensoes[0]);
			regiaoCaixaAssinatura.setXEsquerda(new Float(xEsquerda));
			regiaoCaixaAssinatura.setYBase(new Float(yBase));
			regiaoCaixaAssinatura.setYTopo(new Float(yBase) + dimensoes[1]);
			// altura quadrado 
			// largura = regiaoCaixaAssinatura.getXDireita() - regiaoCaixaAssinatura.getXEsquerda()
			// topo = regiaoCaixaAssinatura.getYBase() + largura
			//
		}
		return regiaoCaixaAssinatura;
	}
	
	private com.nexxera.pds.webservice.server.RegiaoCaixaAssinatura adicionarCampoAssinaturaPorString(String textoBuscaCampoAssinatura) throws SignDocException 
	{
	    int startPage 	= 1;
	    int endPage		= signDocDocument.getPageCount();
	    int flags 		= SignDocDocument.ftf_ignore_hspace;
	    SignDocFindTextPosition[] arrSignDocFindTextPosition = signDocDocument.findText(startPage, endPage, textoBuscaCampoAssinatura, flags);
	    if (arrSignDocFindTextPosition==null || arrSignDocFindTextPosition.length==0) 
	    	throw new SignDocUnexpectedErrorException(
	    				"Palavra chave das assinaturas do contrato n�o encontrada: " + textoBuscaCampoAssinatura);
	    
	    RegiaoCaixaAssinatura regiaoCaixaAssinatura = new RegiaoCaixaAssinatura();
	    for (int i = 0; i < arrSignDocFindTextPosition.length; i++) 
	    {
	    	SignDocFindTextPosition signDocFindTextPosition = arrSignDocFindTextPosition[i]; 
			regiaoCaixaAssinatura.setNumeroPagina(arrSignDocFindTextPosition[0].mFirst.mPage);
			regiaoCaixaAssinatura.setXDireita(new Float(signDocFindTextPosition.mLast.mRef.mX));
			regiaoCaixaAssinatura.setXEsquerda(new Float(signDocFindTextPosition.mFirst.mRef.mX));
			regiaoCaixaAssinatura.setYBase(new Float(signDocFindTextPosition.mFirst.mRef.mY));
			regiaoCaixaAssinatura.setYTopo(new Float(signDocFindTextPosition.mLast.mRef.mY + 30));
		}
		return regiaoCaixaAssinatura;
	}
	
	private static void clear (byte[] data)
	{
		for (int i = 0; i < data.length; ++i)
		  data[i] = 0;
	}
	
}
