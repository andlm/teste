package br.medcorp.arquitetura.rest.service;

import java.util.List;

public interface CrudServiceLocal<T> {

	public abstract void save(T entity);

	public abstract void update(T entity);

	public abstract void delete(T entity);

	public abstract Object findById(T entity);
	
	public abstract List<T> list(Class<T> entity);

}