package br.medcorp.arquitetura.rest.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class CrudService<T> implements CrudServiceLocal<T> {
	
	@PersistenceContext(name="JSFCrudDS")
	private EntityManager entityManager;

	public void save(T entity)
	{
		entityManager.persist(entity);
	}
	
	public void update(T entity)
	{
		entityManager.merge(entity);
	}
	
	public void delete(T entity)
	{
		entityManager.remove(entity);
	}
	
	@SuppressWarnings("unchecked")
	public T findById(T entity)
	{
		return (T) entityManager.find(entity.getClass(), entity);
	}
	
	@SuppressWarnings("unchecked")
	public List<T> list(Class<T> entity)
	{
		return entityManager.createQuery("from "+entity.getName()).getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<T> consultar(Class<T> entity)
	{
		return entityManager.createQuery("from "+entity.getName()).setFirstResult(0).setMaxResults(1).getResultList();
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
}
