/*  1:   */ package br.com.virtuoso.prosaude.utils;
/*  2:   */ 
/*  3:   */ import java.util.Iterator;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class UtilLista
/*  7:   */ {
/*  8:   */   public static String toString(List<?> lista, String separador)
/*  9:   */   {
/* 10:13 */     Iterator<?> i = lista.iterator();
/* 11:14 */     if (!i.hasNext()) {
/* 12:15 */       return "";
/* 13:   */     }
/* 14:17 */     StringBuilder sb = new StringBuilder();
/* 15:   */     for (;;)
/* 16:   */     {
/* 17:19 */       Object e = i.next();
/* 18:20 */       sb.append(e);
/* 19:21 */       if (!i.hasNext()) {
/* 20:22 */         return sb.toString();
/* 21:   */       }
/* 22:24 */       sb.append(separador);
/* 23:   */     }
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilLista
 * JD-Core Version:    0.7.0.1
 */