/*   1:    */ package br.com.virtuoso.prosaude.utils;
/*   2:    */ 
/*   3:    */ import br.com.virtuoso.prosaude.exceptions.SenhaMalFormadaException;
/*   4:    */ import java.io.PrintStream;
/*   5:    */ import java.security.MessageDigest;
/*   6:    */ import sun.misc.BASE64Encoder;
/*   7:    */ 
/*   8:    */ public class UtilCripto
/*   9:    */ {
/*  10:    */   public static void main(String... args)
/*  11:    */     throws Exception
/*  12:    */   {
/*  13: 15 */     String texto = "ms3601";
/*  14:    */     
/*  15: 17 */     String valorParaCriptografarMD5 = texto;
/*  16: 18 */     String valorCriptografadoMD5 = criptografaMD5(valorParaCriptografarMD5);
/*  17: 19 */     Boolean isTextoMD5Igual = isTextoMD5Igual(valorParaCriptografarMD5, valorCriptografadoMD5);
/*  18:    */     
/*  19: 21 */     String valorParaCriptografarVS = texto;
/*  20: 22 */     String valorCriptografadoVS = criptografaVS(valorParaCriptografarVS);
/*  21: 23 */     String valorDescriptografadoVS = descriptografaVS(valorCriptografadoVS);
/*  22: 24 */     Boolean isTextoVSIgual = isTextoVSIgual(valorParaCriptografarVS, valorCriptografadoVS);
/*  23:    */     
/*  24: 26 */     System.out.println("######################################################################");
/*  25: 27 */     System.out.println("Conteúdo para CriptografarMD5: " + valorParaCriptografarMD5);
/*  26: 28 */     System.out.println("Conteúdo Criptografado MD5: " + valorCriptografadoMD5);
/*  27: 29 */     System.out.println("Numero de Caracteres: " + valorCriptografadoMD5.length());
/*  28: 30 */     System.out.println("Testando conteúdo (valorParaCriptografarMD5 / valorCriptografadoMD5): é igual? " + isTextoMD5Igual);
/*  29: 31 */     System.out.println("######################################################################");
/*  30: 32 */     System.out.println("");
/*  31: 33 */     System.out.println("Conteúdo para CriptografarVS: " + valorParaCriptografarVS);
/*  32: 34 */     System.out.println("Conteúdo Criptografado VS: " + valorCriptografadoVS);
/*  33: 35 */     System.out.println("Numero de Caracteres: " + valorCriptografadoVS.length());
/*  34: 36 */     System.out.println("Testando conteúdo (valorParaCriptografarVS / valorCriptografadoVS): é igual? " + isTextoVSIgual);
/*  35: 37 */     System.out.println("Conteúdo Descriptografado VS: " + valorDescriptografadoVS);
/*  36: 38 */     System.out.println("######################################################################");
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static String criptografaVS(String texto)
/*  40:    */   {
/*  41: 42 */     int multiplicador = 8;
/*  42: 43 */     int tamanhoTrechos = 5;
/*  43: 44 */     StringBuffer sb = new StringBuffer(texto);
/*  44: 45 */     String retorno = "";
/*  45:    */     try
/*  46:    */     {
/*  47: 49 */       if ((texto == null) || (texto.trim().length() == 0)) {
/*  48: 50 */         throw new SenhaMalFormadaException("Formato incorreto para CRIPTOGRAFAR!");
/*  49:    */       }
/*  50: 53 */       String tamanhoTotal = "" + texto.length() * multiplicador;
/*  51: 54 */       sb = sb.reverse();
/*  52: 55 */       byte[] bytes = sb.toString().getBytes("ASCII");
/*  53: 56 */       String codigo = "";
/*  54: 58 */       for (int i = 0; i < bytes.length; i++)
/*  55:    */       {
/*  56: 59 */         codigo = "" + new Integer(bytes[i]).intValue() * multiplicador;
/*  57: 60 */         int tamanhoSequencia = codigo.length();
/*  58: 61 */         for (int y = 0; y < tamanhoTrechos - tamanhoSequencia; y++) {
/*  59: 62 */           codigo = "0" + codigo;
/*  60:    */         }
/*  61: 64 */         retorno = retorno + codigo;
/*  62:    */       }
/*  63: 66 */       int tamanhoSequenciaFinal = tamanhoTotal.length();
/*  64: 67 */       for (int y = 0; y < tamanhoTrechos - tamanhoSequenciaFinal; y++) {
/*  65: 68 */         tamanhoTotal = "0" + tamanhoTotal;
/*  66:    */       }
/*  67: 70 */       retorno = retorno + tamanhoTotal;
/*  68:    */     }
/*  69:    */     catch (SenhaMalFormadaException se)
/*  70:    */     {
/*  71: 73 */       System.err.println("##############################################################################################");
/*  72: 74 */       System.err.println("UtilCripto.criptografaVS(" + texto + ") ");
/*  73: 75 */       se.printStackTrace();
/*  74:    */     }
/*  75:    */     catch (Exception e)
/*  76:    */     {
/*  77: 78 */       System.err.println("##############################################################################################");
/*  78: 79 */       System.err.println("UtilCripto.criptografaVS(" + texto + ") ");
/*  79: 80 */       e.printStackTrace();
/*  80:    */     }
/*  81: 82 */     return retorno;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static String descriptografaVS(String texto)
/*  85:    */   {
/*  86: 86 */     int multiplicador = 8;
/*  87: 87 */     int tamanhoTrechos = 5;
/*  88: 88 */     StringBuffer sb = new StringBuffer();
/*  89: 89 */     String retorno = "";
/*  90:    */     try
/*  91:    */     {
/*  92: 92 */       if ((texto == null) || (texto.trim().length() == 0) || (texto.length() % tamanhoTrechos != 0)) {
/*  93: 93 */         throw new SenhaMalFormadaException("Formato incorreto para DESCRIPTOGRAFAR!");
/*  94:    */       }
/*  95: 96 */       int tamanhoTotal = new Integer(texto.substring(texto.length() - tamanhoTrechos, texto.length())).intValue() / multiplicador;
/*  96: 97 */       int tamanhoParaNavegar = tamanhoTotal;
/*  97: 98 */       for (int i = 0; i < tamanhoParaNavegar; i++)
/*  98:    */       {
/*  99: 99 */         String trecho = texto.substring(0, tamanhoTrechos);
/* 100:100 */         texto = texto.substring(5, texto.length());
/* 101:101 */         sb.append((char)(new Integer(trecho).intValue() / multiplicador));
/* 102:102 */         tamanhoTotal--;
/* 103:    */       }
/* 104:104 */       retorno = sb.reverse().toString();
/* 105:    */     }
/* 106:    */     catch (SenhaMalFormadaException se)
/* 107:    */     {
/* 108:106 */       System.err.println("##############################################################################################");
/* 109:107 */       System.err.println("UtilCripto.descriptografaVS(" + texto + ") ");
/* 110:108 */       se.printStackTrace();
/* 111:    */     }
/* 112:110 */     return retorno;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public static String criptografaMD5(String texto)
/* 116:    */     throws Exception
/* 117:    */   {
/* 118:114 */     MessageDigest digest = MessageDigest.getInstance("MD5");
/* 119:115 */     digest.update(texto.getBytes());
/* 120:116 */     BASE64Encoder encoder = new BASE64Encoder();
/* 121:117 */     return encoder.encode(digest.digest());
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static Boolean isTextoMD5Igual(String texto, String textoMD5)
/* 125:    */     throws Exception
/* 126:    */   {
/* 127:121 */     if (textoMD5.equals(criptografaMD5(texto))) {
/* 128:122 */       return Boolean.TRUE;
/* 129:    */     }
/* 130:124 */     return Boolean.FALSE;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public static Boolean isTextoVSIgual(String texto, String textoVS)
/* 134:    */     throws Exception
/* 135:    */   {
/* 136:129 */     if (textoVS.equals(criptografaVS(texto))) {
/* 137:130 */       return Boolean.TRUE;
/* 138:    */     }
/* 139:132 */     return Boolean.FALSE;
/* 140:    */   }
/* 141:    */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilCripto
 * JD-Core Version:    0.7.0.1
 */