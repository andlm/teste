/*   1:    */ package br.com.virtuoso.prosaude.utils;
/*   2:    */ 
/*   3:    */ import java.text.DateFormat;
/*   4:    */ import java.text.DecimalFormat;
/*   5:    */ import java.text.SimpleDateFormat;
/*   6:    */ import java.util.Calendar;
/*   7:    */ import java.util.Date;
/*   8:    */ import java.util.GregorianCalendar;
/*   9:    */ import java.util.HashMap;
/*  10:    */ import java.util.Map;
/*  11:    */ 
/*  12:    */ public class UtilData
/*  13:    */ {
/*  14:    */   public static final String FORMATO_DATA_POR_EXTENSO = "d 'de' MMMM 'de' yyyy";
/*  15:    */   public static final String FORMATO_DATA_PADRAO = "dd/MM/yyyy";
/*  16:    */   public static final String FORMATO_DATA_PADRAO_SEM_BARRA = "ddMMyyyy";
/*  17:    */   public static final String FORMATO_DATA_REF_PADRAO = "MM/yyyy";
/*  18:    */   public static final String FORMATO_DATA_PADRAO_AA = "dd/MM/yy";
/*  19:    */   public static final String FORMATO_DATA_PADRAO_AAAA = "dd/MM/yyyy";
/*  20:    */   public static final String FORMATO_DATA_YYYY = "yyyy";
/*  21:    */   public static final String FORMATO_DATA_AAAAMMDD = "yyyyMMdd";
/*  22:    */   public static final String FORMATO_DATA_AAAAMMDD_SQL = "yyyy-MM-dd";
/*  23:    */   public static final String FORMATO_DATA_AAAAMMDD_HHmmss_ARQUIVO = "yyyy-MM-dd_HH-mm-ss";
/*  24:    */   public static final String FORMATO_DATA_AAMM = "yyMM";
/*  25:    */   public static final String FORMATO_DATA_AAAAMM = "yyyyMM";
/*  26:    */   public static final String FORMATO_HORA_PADRAO = "HH:mm:ss";
/*  27:    */   public static final String FORMATO_HORA_MINUTO = "HH:mm";
/*  28:    */   public static final String FORMATO_12HORA_MINUTO = "h:mm a";
/*  29:    */   public static final String FORMATO_24HORA_MINUTO = "k:mm a";
/*  30:    */   public static final String FORMATO_DATA_HORA_SEM_SEG = "dd/MM/yyyy HH:mm";
/*  31:    */   public static final String FORMATO_HORA_COM_MILIS_PADRAO = "HH:mm:ss.SSS";
/*  32:    */   public static final String FORMATO_DATA_HORA_PADRAO = "dd/MM/yyyy HH:mm:ss";
/*  33:    */   public static final String FORMATO_DATA_HORA_COM_MILIS_PADRAO = "dd/MM/yyyy HH:mm:ss.SSS";
/*  34:    */   public static final String FORMATO_DATA_HORA_COM_MILIS_SQL = "yyyy-MM-dd HH:mm:ss.SSS";
/*  35:    */   public static final int DOMINGO = 1;
/*  36:    */   public static final int SEGUNDA_FEIRA = 2;
/*  37:    */   public static final int TERCA_FEIRA = 3;
/*  38:    */   public static final int QUARTA_FEIRA = 4;
/*  39:    */   public static final int QUINTA_FEIRA = 5;
/*  40:    */   public static final int SEXTA_FEIRA = 6;
/*  41:    */   public static final int SABADO = 7;
/*  42:    */   public static final String DIAS = "DIAS";
/*  43:    */   public static final String HORAS = "HORAS";
/*  44:    */   public static final String MINUTOS = "MINUTOS";
/*  45:    */   public static final String SEGUNDOS = "SEGUNDOS";
/*  46:    */   public static final String TIME = "TIME";
/*  47:    */   
/*  48:    */   public static Date adicionar(Date dataInicial, int campo, int valor)
/*  49:    */   {
/*  50: 54 */     Calendar calendar = Calendar.getInstance();
/*  51: 55 */     calendar.setTime(dataInicial);
/*  52: 56 */     calendar.add(campo, valor);
/*  53: 57 */     return calendar.getTime();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static Date getDataAtualSemHora()
/*  57:    */   {
/*  58: 61 */     return zerarHora(getDataAtual());
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static Date getDataAtual()
/*  62:    */   {
/*  63: 65 */     return new Date();
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static Calendar getDataAtualCalendar()
/*  67:    */   {
/*  68: 69 */     Date d = new Date();
/*  69: 70 */     Calendar cal = new GregorianCalendar();
/*  70: 71 */     cal.setTime(d);
/*  71: 72 */     return cal;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static Date adicionarMes(Date data, int mes)
/*  75:    */   {
/*  76: 76 */     Calendar calendar = Calendar.getInstance();
/*  77: 77 */     calendar.setTime(data);
/*  78: 78 */     calendar.add(2, mes);
/*  79: 79 */     return calendar.getTime();
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static Date adicionarDia(Date data, int dias)
/*  83:    */   {
/*  84: 83 */     return adicionar(data, 5, dias);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static Date adicionarHora(Date data, int horas)
/*  88:    */   {
/*  89: 87 */     return adicionar(data, 10, horas);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static Date adicionarMinuto(Date data, int minutos)
/*  93:    */   {
/*  94: 91 */     return adicionar(data, 12, minutos);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static Date zerarHora(Date data)
/*  98:    */   {
/*  99: 95 */     if (data == null) {
/* 100: 96 */       return null;
/* 101:    */     }
/* 102: 98 */     Calendar calendar = Calendar.getInstance();
/* 103: 99 */     calendar.setTime(data);
/* 104:100 */     calendar.set(11, 0);
/* 105:101 */     calendar.set(12, 0);
/* 106:102 */     calendar.set(13, 0);
/* 107:103 */     calendar.set(14, 0);
/* 108:104 */     return calendar.getTime();
/* 109:    */   }
/* 110:    */   
/* 111:    */   public static Date setUltimaHora(Date data)
/* 112:    */   {
/* 113:108 */     if (data == null) {
/* 114:109 */       return null;
/* 115:    */     }
/* 116:111 */     Calendar calendar = Calendar.getInstance();
/* 117:112 */     calendar.setTime(data);
/* 118:113 */     calendar.set(11, 23);
/* 119:114 */     calendar.set(12, 59);
/* 120:115 */     calendar.set(13, 59);
/* 121:116 */     calendar.set(14, 59);
/* 122:117 */     return calendar.getTime();
/* 123:    */   }
/* 124:    */   
/* 125:    */   public static Date setSegundo(Date data, int segundo)
/* 126:    */   {
/* 127:121 */     if (data == null) {
/* 128:122 */       return null;
/* 129:    */     }
/* 130:124 */     Calendar calendar = Calendar.getInstance();
/* 131:125 */     calendar.setTime(data);
/* 132:126 */     calendar.set(13, segundo);
/* 133:127 */     return calendar.getTime();
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static Date setMes(Date data, int mes)
/* 137:    */   {
/* 138:131 */     if (data == null) {
/* 139:132 */       return null;
/* 140:    */     }
/* 141:134 */     Calendar calendar = Calendar.getInstance();
/* 142:135 */     calendar.setTime(data);
/* 143:136 */     calendar.set(2, mes);
/* 144:137 */     return calendar.getTime();
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static Date setAno(Date data, int ano)
/* 148:    */   {
/* 149:141 */     if (data == null) {
/* 150:142 */       return null;
/* 151:    */     }
/* 152:144 */     Calendar calendar = Calendar.getInstance();
/* 153:145 */     calendar.setTime(data);
/* 154:146 */     calendar.set(1, ano);
/* 155:147 */     return calendar.getTime();
/* 156:    */   }
/* 157:    */   
/* 158:    */   public static Date setDiaDoMes(Date data, int dia)
/* 159:    */   {
/* 160:151 */     if (data == null) {
/* 161:152 */       return null;
/* 162:    */     }
/* 163:154 */     Calendar calendar = Calendar.getInstance();
/* 164:155 */     calendar.setTime(data);
/* 165:156 */     int mesAnterior = calendar.get(2);
/* 166:157 */     calendar.set(5, dia);
/* 167:158 */     if (mesAnterior != calendar.get(2)) {
/* 168:159 */       calendar.set(5, 1);
/* 169:    */     }
/* 170:161 */     return calendar.getTime();
/* 171:    */   }
/* 172:    */   
/* 173:    */   public static Date setUltimoDiaDoMes(Date data)
/* 174:    */   {
/* 175:165 */     if (data == null) {
/* 176:166 */       return null;
/* 177:    */     }
/* 178:168 */     Calendar calendar = Calendar.getInstance();
/* 179:169 */     calendar.setTime(data);
/* 180:170 */     calendar.set(5, 1);
/* 181:171 */     calendar.add(2, 1);
/* 182:172 */     calendar.set(5, 1);
/* 183:173 */     calendar.add(5, -1);
/* 184:174 */     return calendar.getTime();
/* 185:    */   }
/* 186:    */   
/* 187:    */   public static int calculaDiferencaEmMeses(Date dataMaior, Date dataMenor)
/* 188:    */   {
/* 189:178 */     return calculaDiferencaEmMeses(dataMaior, dataMenor, 0);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public static long calculaDiferencaEmSegundos(Date dataMaior, Date dataMenor)
/* 193:    */   {
/* 194:182 */     return (dataMaior.getTime() - dataMenor.getTime()) / 1000L;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static int calculaDiferencaEmDias(Date dataMaior, Date dataMenor)
/* 198:    */   {
/* 199:186 */     long d1 = dataMaior.getTime();
/* 200:187 */     long d2 = dataMenor.getTime();
/* 201:188 */     return (int)((d1 - d2) / 86400000L);
/* 202:    */   }
/* 203:    */   
/* 204:    */   public static int calculaDiferencaEmHoras(Date dataMaior, Date dataMenor)
/* 205:    */   {
/* 206:192 */     long d1 = dataMaior.getTime();
/* 207:193 */     long d2 = dataMenor.getTime();
/* 208:194 */     return (int)((d1 - d2) / 3600000L);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public static int calculaDiferencaEmMinutos(Date dataMaior, Date dataMenor)
/* 212:    */   {
/* 213:198 */     long d1 = dataMaior.getTime();
/* 214:199 */     long d2 = dataMenor.getTime();
/* 215:200 */     return (int)((d1 - d2) / 60000L);
/* 216:    */   }
/* 217:    */   
/* 218:    */   public static Map<String, Object> calculaDiferencaDatas(Date dataMaior, Date dataMenor)
/* 219:    */   {
/* 220:204 */     Map<String, Object> retorno = new HashMap();
/* 221:205 */     long tempoInicial = dataMenor.getTime();
/* 222:206 */     long tempoFinal = dataMaior.getTime();
/* 223:207 */     long tempoProcesso = tempoFinal - tempoInicial;
/* 224:208 */     long segundos = tempoProcesso / 1000L;
/* 225:209 */     long minutos = segundos / 60L;
/* 226:210 */     long horas = minutos / 60L;
/* 227:211 */     long dias = horas / 24L;
/* 228:    */     
/* 229:213 */     DecimalFormat format = new DecimalFormat("00");
/* 230:214 */     retorno.put("DIAS", format.format(dias));
/* 231:215 */     retorno.put("HORAS", format.format(horas - dias * 24L));
/* 232:216 */     retorno.put("MINUTOS", format.format(minutos - horas * 60L));
/* 233:217 */     retorno.put("SEGUNDOS", format.format(segundos - minutos * 60L));
/* 234:218 */     retorno.put("TIME", Long.valueOf(tempoProcesso));
/* 235:219 */     return retorno;
/* 236:    */   }
/* 237:    */   
/* 238:    */   public static Map<String, Object> retornarDataVO(Long tempoProcesso)
/* 239:    */   {
/* 240:223 */     Map<String, Object> retorno = new HashMap();
/* 241:224 */     DecimalFormat format = new DecimalFormat("00");
/* 242:225 */     long segundos = tempoProcesso.longValue() / 1000L;
/* 243:226 */     long minutos = segundos / 60L;
/* 244:227 */     long horas = minutos / 60L;
/* 245:228 */     long dias = horas / 24L;
/* 246:    */     
/* 247:230 */     retorno.put("DIAS", format.format(dias));
/* 248:231 */     retorno.put("HORAS", format.format(horas - dias * 24L));
/* 249:232 */     retorno.put("MINUTOS", format.format(minutos - horas * 60L));
/* 250:233 */     retorno.put("SEGUNDOS", format.format(segundos - minutos * 60L));
/* 251:234 */     retorno.put("TIME", tempoProcesso);
/* 252:235 */     return retorno;
/* 253:    */   }
/* 254:    */   
/* 255:    */   public static Date retornarData(String data)
/* 256:    */   {
/* 257:239 */     return retornarData(data, null);
/* 258:    */   }
/* 259:    */   
/* 260:    */   public static Date retornarData(String data, String formato)
/* 261:    */   {
/* 262:243 */     if (UtilString.isNuloOuBranco(data)) {
/* 263:244 */       return null;
/* 264:    */     }
/* 265:246 */     data = data.trim();
/* 266:247 */     if (((data.length() == 10) || (data.length() == 9) || ((data.length() == 8) && (data.indexOf("/") == 1))) && (data.indexOf("/") != -1))
/* 267:    */     {
/* 268:248 */       if (UtilString.isNuloOuBranco(formato)) {
/* 269:249 */         return parseData(data, "dd/MM/yyyy");
/* 270:    */       }
/* 271:251 */       return parseData(data, formato);
/* 272:    */     }
/* 273:252 */     if ((data.length() == 10) && (data.indexOf("-") != -1))
/* 274:    */     {
/* 275:253 */       if (UtilString.isNuloOuBranco(formato)) {
/* 276:254 */         return parseData(data, "yyyy-MM-dd");
/* 277:    */       }
/* 278:256 */       return parseData(data, formato);
/* 279:    */     }
/* 280:257 */     if ((data.length() == 8) && (data.indexOf("/") != -1))
/* 281:    */     {
/* 282:258 */       if (UtilString.isNuloOuBranco(formato)) {
/* 283:259 */         return parseData(data, "dd/MM/yy");
/* 284:    */       }
/* 285:261 */       return parseData(data, formato);
/* 286:    */     }
/* 287:262 */     if ((data.length() == 8) && (data.indexOf("/") == -1) && (data.indexOf(":") == -1))
/* 288:    */     {
/* 289:263 */       if (UtilString.isNuloOuBranco(formato)) {
/* 290:264 */         return parseData(data, "yyyyMMdd");
/* 291:    */       }
/* 292:266 */       return parseData(data, formato);
/* 293:    */     }
/* 294:267 */     if ((data.length() == 6) && (data.indexOf("/") == -1) && (data.indexOf(":") == -1))
/* 295:    */     {
/* 296:268 */       if (UtilString.isNuloOuBranco(formato)) {
/* 297:269 */         return parseData(data, "yyyyMM");
/* 298:    */       }
/* 299:271 */       return parseData(data, formato);
/* 300:    */     }
/* 301:272 */     if (data.length() == 4) {
/* 302:273 */       return parseData(data, formato);
/* 303:    */     }
/* 304:274 */     if (data.length() == 8) {
/* 305:275 */       return retornarHora(data);
/* 306:    */     }
/* 307:276 */     if (data.length() == 5) {
/* 308:277 */       return parseData(data, "HH:mm");
/* 309:    */     }
/* 310:278 */     if (data.length() == 16) {
/* 311:279 */       return retornarDataHora(data + ":00");
/* 312:    */     }
/* 313:280 */     if ((data.length() == 18) || (data.length() == 19)) {
/* 314:281 */       return retornarDataHora(data);
/* 315:    */     }
/* 316:282 */     if ((data.length() == 21) && (data.indexOf("-") > -1)) {
/* 317:283 */       return retornarDataHoraComMilisSql(data);
/* 318:    */     }
/* 319:284 */     if ((data.length() == 7) && (data.indexOf("/") != -1)) {
/* 320:285 */       return retornarDataMA(data);
/* 321:    */     }
/* 322:287 */     return null;
/* 323:    */   }
/* 324:    */   
/* 325:    */   public static Date retornarDataMA(String dataMA)
/* 326:    */   {
/* 327:291 */     return parseData("01/" + dataMA, "dd/MM/yyyy");
/* 328:    */   }
/* 329:    */   
/* 330:    */   public static Date retornarDataMMAA(String dataMA)
/* 331:    */   {
/* 332:295 */     return parseData("01" + dataMA, "ddMMyy");
/* 333:    */   }
/* 334:    */   
/* 335:    */   public static Date retornarDataHora(String dataHora)
/* 336:    */   {
/* 337:299 */     return parseData(dataHora, "dd/MM/yyyy HH:mm:ss");
/* 338:    */   }
/* 339:    */   
/* 340:    */   public static Date retornarDataHoraComMilisSql(String dataHora)
/* 341:    */   {
/* 342:303 */     return parseData(dataHora, "yyyy-MM-dd HH:mm:ss.SSS");
/* 343:    */   }
/* 344:    */   
/* 345:    */   public static Date retornarHora(String hora)
/* 346:    */   {
/* 347:307 */     return parseData(hora, "HH:mm:ss");
/* 348:    */   }
/* 349:    */   
/* 350:    */   public static Date parseData(String data, String formato)
/* 351:    */   {
/* 352:311 */     Date dataRetorno = null;
/* 353:312 */     DateFormat dateFormat = new SimpleDateFormat(formato);
/* 354:313 */     dateFormat.setLenient(false);
/* 355:    */     try
/* 356:    */     {
/* 357:315 */       dataRetorno = dateFormat.parse(data);
/* 358:    */     }
/* 359:    */     catch (Exception e)
/* 360:    */     {
/* 361:317 */       e.printStackTrace();
/* 362:    */     }
/* 363:319 */     return dataRetorno;
/* 364:    */   }
/* 365:    */   
/* 366:    */   private static int calculaDiferencaEmMeses(Date dataMaior, Date dataMenor, int difParcial)
/* 367:    */   {
/* 368:323 */     if (dataMaior.after(dataMenor))
/* 369:    */     {
/* 370:324 */       dataMaior = adicionarMes(dataMaior, -1);
/* 371:325 */       difParcial = calculaDiferencaEmMeses(dataMaior, dataMenor, ++difParcial);
/* 372:    */     }
/* 373:327 */     return difParcial;
/* 374:    */   }
/* 375:    */   
/* 376:    */   public static Date setTime(Date data, int hora, int min, int seg)
/* 377:    */   {
/* 378:331 */     Calendar calendar = Calendar.getInstance();
/* 379:332 */     calendar.setTime(data);
/* 380:333 */     calendar.set(11, hora);
/* 381:334 */     calendar.set(12, min);
/* 382:335 */     calendar.set(13, seg);
/* 383:336 */     return calendar.getTime();
/* 384:    */   }
/* 385:    */   
/* 386:    */   public static String obterHHMMSS(long segundos)
/* 387:    */   {
/* 388:340 */     DecimalFormat format = new DecimalFormat("00");
/* 389:341 */     int hora = (int)segundos / 3600;
/* 390:342 */     int minuto = (int)(segundos - hora * 3600) / 60;
/* 391:343 */     int seg = (int)(segundos - hora * 3600 - minuto * 60);
/* 392:344 */     return format.format(hora) + ":" + format.format(minuto) + ":" + format.format(seg);
/* 393:    */   }
/* 394:    */   
/* 395:    */   public static String obterHHMM(long segundos)
/* 396:    */   {
/* 397:348 */     DecimalFormat format = new DecimalFormat("00");
/* 398:349 */     int hora = (int)segundos / 3600;
/* 399:350 */     int minuto = (int)(segundos - hora * 3600) / 60;
/* 400:351 */     return format.format(hora) + ":" + format.format(minuto);
/* 401:    */   }
/* 402:    */   
/* 403:    */   public static String formatarDataDMA(Date data)
/* 404:    */   {
/* 405:355 */     return formatarData(data, "dd/MM/yyyy");
/* 406:    */   }
/* 407:    */   
/* 408:    */   public static String formatarDataDMASemBarra(Date data)
/* 409:    */   {
/* 410:359 */     return formatarData(data, "ddMMyyyy");
/* 411:    */   }
/* 412:    */   
/* 413:    */   public static String formatarDataDMA_HM(Date data)
/* 414:    */   {
/* 415:363 */     return formatarData(data, "dd/MM/yyyy HH:mm");
/* 416:    */   }
/* 417:    */   
/* 418:    */   public static String formatarDataDMA_HMS(Date data)
/* 419:    */   {
/* 420:366 */     return formatarData(data, "dd/MM/yyyy HH:mm:ss");
/* 421:    */   }
/* 422:    */   
/* 423:    */   public static String formatarHoraMinSeg(Date data)
/* 424:    */   {
/* 425:370 */     return formatarData(data, "HH:mm:ss");
/* 426:    */   }
/* 427:    */   
/* 428:    */   public static String formatarHoraMin(Date data)
/* 429:    */   {
/* 430:374 */     return formatarData(data, "k:mm a");
/* 431:    */   }
/* 432:    */   
/* 433:    */   public static String formatarDataMA(Date data)
/* 434:    */   {
/* 435:378 */     String formato = "MM/yyyy";
/* 436:379 */     return formatarData(data, formato);
/* 437:    */   }
/* 438:    */   
/* 439:    */   public static String formatarDataAAAAMMsemBarra(Date data)
/* 440:    */   {
/* 441:383 */     return formatarData(data, "yyyyMM");
/* 442:    */   }
/* 443:    */   
/* 444:    */   public static String formatarDataAAAA(Date data)
/* 445:    */   {
/* 446:387 */     return formatarData(data, "yyyy");
/* 447:    */   }
/* 448:    */   
/* 449:    */   public static String formatarDataAAMMsemBarra(Date data)
/* 450:    */   {
/* 451:391 */     return formatarData(data, "yyMM");
/* 452:    */   }
/* 453:    */   
/* 454:    */   public static String formatarDataAAAAMMDDsemBarra(Date data)
/* 455:    */   {
/* 456:395 */     return formatarData(data, "yyyyMMdd");
/* 457:    */   }
/* 458:    */   
/* 459:    */   public static String formatarDataPorExtenso(Date data)
/* 460:    */   {
/* 461:399 */     return formatarData(data, "d 'de' MMMM 'de' yyyy");
/* 462:    */   }
/* 463:    */   
/* 464:    */   public static String formatarData(Date data, String formato)
/* 465:    */   {
/* 466:403 */     if (data == null) {
/* 467:404 */       return "";
/* 468:    */     }
/* 469:406 */     SimpleDateFormat formatador = new SimpleDateFormat(formato, UtilLocale.getLocale());
/* 470:407 */     return formatador.format(data);
/* 471:    */   }
/* 472:    */   
/* 473:    */   public static int getDiaMes(Date data)
/* 474:    */   {
/* 475:411 */     return getElementoData(data, 5);
/* 476:    */   }
/* 477:    */   
/* 478:    */   public static int getUltimoDiaDoMes(Date data)
/* 479:    */   {
/* 480:415 */     Calendar calendar = Calendar.getInstance();
/* 481:416 */     calendar.setTime(data);
/* 482:417 */     return calendar.getMaximum(5);
/* 483:    */   }
/* 484:    */   
/* 485:    */   public static Date getUltimoDataDoMes(Date data)
/* 486:    */   {
/* 487:421 */     int ultimoDia = getUltimoDiaDoMes(data);
/* 488:422 */     Date retorno = setDiaDoMes(data, ultimoDia);
/* 489:423 */     return setUltimaHora(retorno);
/* 490:    */   }
/* 491:    */   
/* 492:    */   public static int getMes(Date data)
/* 493:    */   {
/* 494:427 */     return getElementoData(data, 2) + 1;
/* 495:    */   }
/* 496:    */   
/* 497:    */   public static int getAno(Date data)
/* 498:    */   {
/* 499:431 */     return getElementoData(data, 1);
/* 500:    */   }
/* 501:    */   
/* 502:    */   public static int getHora(Date data)
/* 503:    */   {
/* 504:435 */     return getElementoData(data, 11);
/* 505:    */   }
/* 506:    */   
/* 507:    */   public static int getMinuto(Date data)
/* 508:    */   {
/* 509:439 */     return getElementoData(data, 12);
/* 510:    */   }
/* 511:    */   
/* 512:    */   public static int getDiaSemana(Date data)
/* 513:    */   {
/* 514:443 */     Calendar c = Calendar.getInstance();
/* 515:444 */     c.setTime(data);
/* 516:445 */     return c.get(7);
/* 517:    */   }
/* 518:    */   
/* 519:    */   public static boolean isFinalSemana(Date data)
/* 520:    */   {
/* 521:449 */     Calendar c = Calendar.getInstance();
/* 522:450 */     c.setTime(data);
/* 523:451 */     int dia = c.get(7);
/* 524:453 */     if ((7 == dia) || (1 == dia)) {
/* 525:454 */       return true;
/* 526:    */     }
/* 527:457 */     return false;
/* 528:    */   }
/* 529:    */   
/* 530:    */   public static Date getDiaUtil(Date data)
/* 531:    */   {
/* 532:461 */     Calendar c = Calendar.getInstance();
/* 533:462 */     c.setTime(data);
/* 534:463 */     int dia = c.get(7);
/* 535:465 */     if (7 == dia) {
/* 536:466 */       return adicionarDia(data, 2);
/* 537:    */     }
/* 538:469 */     if (1 == dia) {
/* 539:470 */       return adicionarDia(data, 1);
/* 540:    */     }
/* 541:472 */     return data;
/* 542:    */   }
/* 543:    */   
/* 544:    */   public static Boolean verificarDiaUtil(Date vencimento)
/* 545:    */   {
/* 546:477 */     if (isFinalSemana(vencimento)) {
/* 547:478 */       return Boolean.valueOf(false);
/* 548:    */     }
/* 549:480 */     return Boolean.valueOf(true);
/* 550:    */   }
/* 551:    */   
/* 552:    */   public static int getSegundo(Date data)
/* 553:    */   {
/* 554:484 */     return getElementoData(data, 13);
/* 555:    */   }
/* 556:    */   
/* 557:    */   public static int getMiliSegundo(Date data)
/* 558:    */   {
/* 559:488 */     return getElementoData(data, 14);
/* 560:    */   }
/* 561:    */   
/* 562:    */   public static int getElementoData(Date data, int elemento)
/* 563:    */   {
/* 564:492 */     Calendar c = Calendar.getInstance();
/* 565:493 */     c.setTime(data);
/* 566:494 */     return c.get(elemento);
/* 567:    */   }
/* 568:    */   
/* 569:    */   public static long getLongDate(Date data)
/* 570:    */   {
/* 571:498 */     Calendar c = Calendar.getInstance();
/* 572:499 */     c.setTime(data);
/* 573:500 */     return c.getTimeInMillis();
/* 574:    */   }
/* 575:    */   
/* 576:    */   public static Date setTime(Date data, Date hora)
/* 577:    */   {
/* 578:504 */     return setTime(data, getHora(hora), getMinuto(hora), getSegundo(hora));
/* 579:    */   }
/* 580:    */   
/* 581:    */   public static Integer getUltimoDiaMesBrasil(Date dtMesAno)
/* 582:    */   {
/* 583:508 */     dtMesAno = setDiaDoMes(dtMesAno, 1);
/* 584:509 */     dtMesAno = adicionarMes(dtMesAno, 1);
/* 585:510 */     dtMesAno = adicionarDia(dtMesAno, -1);
/* 586:511 */     return Integer.valueOf(getDiaMes(dtMesAno));
/* 587:    */   }
/* 588:    */   
/* 589:    */   public static Date subtrairDia(Date data, Integer dia)
/* 590:    */   {
/* 591:515 */     return subtrair(data, Integer.valueOf(6), dia);
/* 592:    */   }
/* 593:    */   
/* 594:    */   public static Date subtrair(Date dataInicial, Integer campo, Integer valor)
/* 595:    */   {
/* 596:519 */     return adicionar(dataInicial, campo.intValue(), valor.intValue() * -1);
/* 597:    */   }
/* 598:    */   
/* 599:    */   public static Date getReferencia(Date data)
/* 600:    */   {
/* 601:523 */     if (data == null) {
/* 602:524 */       return null;
/* 603:    */     }
/* 604:526 */     return zerarHora(setDiaDoMes(data, 1));
/* 605:    */   }
/* 606:    */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilData
 * JD-Core Version:    0.7.0.1
 */