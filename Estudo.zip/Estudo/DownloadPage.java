package com.nexxera.pds.utility;

import java.io.Serializable;

import org.jboss.seam.Component;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

/**
 * Centraliza todos os servi�os de download.
 */
@Name("downloadPage")
@Scope(ScopeType.CONVERSATION)
public class DownloadPage implements Serializable{

	private static final long serialVersionUID = 1L;
	private String contentType;
	private String fileName;
	private byte[] data;

	public static String goTo(byte[] data, String fileName, String contentType){
		DownloadPage downloadPage = ((DownloadPage) Component.getInstance("downloadPage"));
		downloadPage.setData(data);
		downloadPage.setFileName(fileName);
		downloadPage.setContentType(contentType);
		
		return "/download/download.xhtml";
	}
	
	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}
	
}