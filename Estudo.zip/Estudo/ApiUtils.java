package com.prosaude.sistema.util;

public class ApiUtils {

  //  public static final String BASE_URL_EMPRESA = "http://10.0.2.2:8080/portalMedcorpRestService/rest/agendamento/pesquisarLogin";
  //  public static final String BASE_URL_AGENDA = "http://10.0.2.2:8080/portalMedcorpRestService/rest/agendamento/adicionarFormularioAgenda";

    public static final String BASE_URL_EMPRESA = "http://34.237.77.6:8080/portalMedcorpRestService/rest/agendamento/pesquisarLogin";
    public static final String BASE_URL_AGENDA = "http://34.237.77.6:8080/portalMedcorpRestService/rest/agendamento/adicionarFormularioAgenda";


    public static final String USUARIO_OBJETO = "USUARIO";

    public static final String PROTOCOLO_OBJETO = "PROTOCOLO";

    public static final int REQUEST_CODE_FORMCAMERADIALOG = 5;
    public static final int REQUEST_CODE_FORMDOCUMENTODIALOG = 4;
    public static final int REQUEST_CODE_SELECTEDITEMDIALOG = 3;
    public static final int REQUEST_CODE_FORMUSUARIODIALOG = 2;
    public static final int REQUEST_CODE_SIGNATURE = 1;

    // 187.65.234.247 ip externo
    //public static final String BASE_URL_EMPRESA = "http://187.65.234.247:8080/portalMedcorpRestService/rest/protolocolo/pesquisarLogin/";
    //public static final String BASE_URL_EMPRESA = "http://192.168.0.18:8081/portalMedcorpRestService/rest/protolocolo/pesquisarLogin";

    private ApiUtils() {
    }
}