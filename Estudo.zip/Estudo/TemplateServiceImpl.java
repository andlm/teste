package com.nexxera.pds.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Name;

import com.nexxera.pds.entity.Arquivotemplate;
import com.nexxera.pds.entity.Template;
import com.nexxera.pds.entity.Variavel;
import com.nexxera.pds.service.exception.ServiceException;
import com.nexxera.pds.utility.ResourceProperties;
import com.nexxera.pds.utility.StringUtil;
import com.nexxera.pds.utility.StringUtils;
import com.nexxera.pds.utility.paginator.PaginatedList;

@Name("templateService")
@AutoCreate
@Stateless
public class TemplateServiceImpl implements TemplateService 
{

	@PersistenceContext
	private EntityManager em;

	@Override
	public void cadastrar(Template template) throws ServiceException 
	{
		StringBuffer hqlQuery = new StringBuffer(
				"select a.cdTemplate from Template a " +
				"where a.cdTemplate is not null "
				+ (!StringUtil.isEmpty(template.getDsTemplate()) ? "and UPPER(dsTemplate) = UPPER(:dsTemplate) " : " ")
			);
		
		Query query = em.createQuery(hqlQuery.toString());
		
		if (!StringUtil.isEmpty(template.getDsTemplate())) query.setParameter("dsTemplate", template.getDsTemplate());
		
		@SuppressWarnings("unchecked")
		List<Object[]> resultado = query.getResultList();
		
		if(resultado.size() > 0)
		{
			throw new ServiceException("#{messages['template.existe']}");
		}
		em.persist(template);
	}

	@Override
	public void deletar(Template template) 
	{
		em.remove(em.merge(template));
	}

	@Override
	public void editar(Template template) 
	{
		em.merge(template);
	}

	@Override
	public PaginatedList<Template> pesquisar(Template template, Integer inicio,
			Integer quantidade) 
	{
		
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Template> listarTodos() 
	{
		return em.createQuery("from Template order by dsTemplate").getResultList();
	}

	@Override
	public Template listar(Template filtro) 
	{
		StringBuffer hqlQuery = new StringBuffer(
				"from Template a " +
				"where a.cdTemplate is not null "
				+ ((filtro.getCdTemplate() != null) ? "and a.cdTemplate = :cdTemplate " : " ")
				+ ((filtro.getCdTipooperacao().getCdTipooperacao() != null) ? "and a.cdTipooperacao.cdTipooperacao = :cdTipooperacao " : " ")
			);
		
		Query query = em.createQuery(hqlQuery.toString());
		
		if (filtro.getCdTemplate() != null) 
				query.setParameter("cdTemplate", filtro.getCdTemplate());
		
		if (filtro.getCdTipooperacao().getCdTipooperacao() != null) 
			query.setParameter("cdTipooperacao", filtro.getCdTipooperacao().getCdTipooperacao());
		
		@SuppressWarnings("unchecked")
		List<Template> resultado = query.getResultList();
		if(resultado.size() > 0)
		{
			return (Template)resultado.get(0);
		}
		return null;
	}
	
	
	
	private String textoConvertido 					= null;
	private Set<Variavel>  	variaveisScreen         = new HashSet<Variavel>();
    private List<String>   	variaveisContratante    = new ArrayList<String>();
    private List<String>   	variaveisContratada     = new ArrayList<String>();
    private List<String>   	variaveisOutras         = new ArrayList<String>();
    public static final String EXTENSAO_ARQUIVOTEMPLATE = ".doc";
	private static String 	pdfNome					= "";
	private static File 	confFolder;
	private static File 	filePDFContrato;
   
    private static String getTempDir() 
	{
		return System.getProperty("java.io.tmpdir");
	}
	
	private static File createTempDir(String diretorio) 
	{ 
		File tempDir = null;
	    final String baseTempPath = getTempDir(); 
	    if (diretorio == null )
		{ 
	    	tempDir = new File(baseTempPath);
	    }
	    else
	    {
	    	tempDir = new File(baseTempPath, diretorio);
	    }
	    if (tempDir.exists() == false) 
		{ 
	        tempDir.mkdir(); 
	    } 
	    return tempDir; 
	}
	
	private static File createTempFile(File dir, String file, String diretorio)
	{
		file = diretorio+""+file;
		File tempFile = new File(dir, file.trim());
		return tempFile;
	}
	
	

	 /**
	 * Faz a leitura do documento passado para iniciar o processo de extra��o 
	 * do texto e das vari�veis
	 *  
	 * @param template contendo as informa��es sobre o template
	 * @param stream documento do upload
	 * 
	 * @return Template com os dados extraidos do documento
	 * @throws BusinessException 
	 */
	@Override
	public Template uploadTemplate(Template template,
			Arquivotemplate arquivotemplate, byte[] arquivoDOCTemp) throws Exception 
	{
		
		
		if (template.getFgComposicao())
    		pdfNome = template.getNomeArquivoTemplate()+EXTENSAO_ARQUIVOTEMPLATE;
    	else
    	{
    		pdfNome=StringUtils.getTimeName()+
    					template.getNomeArquivoTemplate()+EXTENSAO_ARQUIVOTEMPLATE;
    	}
    	confFolder = createTempDir(null);
    	File fileDOCContrato = createTempFile(confFolder, pdfNome,null);
    	FileOutputStream fos = new FileOutputStream(fileDOCContrato);
    	fos.write(arquivoDOCTemp);
    	fos.close(); 
    	arquivotemplate.setFile(filePDFContrato);
		template.getArquivotemplateList().add(arquivotemplate);
		uploadTemplate(template, fileDOCContrato);
    	return template;
	}
  
    
	/**
	 * Faz a leitura do documento passado para iniciar o processo de extra��o 
	 * do texto e das vari�veis
	 *  
	 * @param template contendo as informa��es sobre o template
	 * @param stream documento do upload
	 * 
	 * @return Template com os dados extraidos do documento
	 * @throws BusinessException 
	 */
    @Override
	public Template uploadTemplate(Template template, File file) throws Exception
	{
		textoConvertido	= null;
		textoConvertido = parseTextoTemplateContrato(file);
		Set<Variavel> variaveis = parseVariaveisTemplateContrato(textoConvertido);
		if (variaveis!=null)
		{
			List<Variavel> listaOrdenada = new ArrayList<Variavel>(variaveis);
			Collections.sort(listaOrdenada, new Comparator<Variavel>()
			{
				public int compare(Variavel o1, Variavel o2) 
				{
					return o1.getNomeVariavel().compareTo(o2.getNomeVariavel());
				}
			});
			template.setVariaveis(listaOrdenada);
		}
		if (variaveisScreen!=null)
		{
			for(Variavel variavel1: variaveisScreen)
	        {
	            if (variavel1.getNomeVariavel().indexOf(
	            			ResourceProperties.PARAMTEMPLATE_VARIAVEIS_CONTRATANTE)>-1)
	                variaveisContratante.add(variavel1.getNomeVariavel());
	            if (variavel1.getNomeVariavel().indexOf(
	            			ResourceProperties.PARAMTEMPLATE_VARIAVEIS_CONTRATADA)>-1)
	                variaveisContratada.add(variavel1.getNomeVariavel());
	
	            if (variavel1.getNomeVariavel().indexOf(
	            		ResourceProperties.PARAMTEMPLATE_VARIAVEIS_CONTRATANTE)==-1 && 
	            	variavel1.getNomeVariavel().indexOf(
	            		ResourceProperties.PARAMTEMPLATE_VARIAVEIS_CONTRATADA) ==-1)
	                variaveisOutras.add(variavel1.getNomeVariavel());
	        }
		}
		template.setVariaveisContratada(variaveisContratada);
		template.setVariaveisContratante(variaveisContratante);
		template.setVariaveisOutras(variaveisOutras);
		template.setTextoTemplate(textoConvertido);
		template.setBinarioArquivoTemplate(this.getBytesFromFile(file));
		return template;
	}
	
	
	 /**
	* Metodo que extrai o texto do documento
	* @param template documento binario
	* @return texto do documento
	*/
	private String parseTextoTemplateContrato(File p_iTemplate) throws Exception
	{
	    InputStream iTemplate1      = new FileInputStream(p_iTemplate);
	    POIFSFileSystem filesystem  = new POIFSFileSystem(iTemplate1);
	    HWPFDocument newDoc         = new HWPFDocument(filesystem);
	    WordExtractor extractor     = new WordExtractor(newDoc);
	    return extractor.getText();
	}

	
	/**
    * Metodo que extrai as variaveis definidas no texto do documento
    * @param texto extraido do documento
    * @return Collection com as variaveis extraidas do texto
    */
    private Set<Variavel> parseVariaveisTemplateContrato(String p_strTexto) throws Exception
    {
    	Map<String, String> variaveisMap        = new HashMap<String, String>();
        Map<String, String> variaveisMapScreen  = new HashMap<String, String>();

        List<Integer> posicoesIniciais          = new ArrayList<Integer>();
        List<Integer> posicoesFinais            = new ArrayList<Integer>();
        
        Set<Variavel> variaveis 				= new HashSet<Variavel>();
        if (p_strTexto == null) return null;
        
        //Verifica as posi��es inicial e final para todas as variaveis contidos no texto
        for ( int i = 0; i < p_strTexto.length(); i++ )
        {
            char firstSimbol = p_strTexto.charAt(i);
            if ( firstSimbol == '<'  )
            {
                    char secondSimbol = p_strTexto.charAt(i+1);
                    if ( secondSimbol == '=' || secondSimbol == '#' )
                            posicoesIniciais.add(i+2);
            }
            if (firstSimbol == '>')
                    posicoesFinais.add(i);
        }
        if (posicoesFinais.size() != posicoesIniciais.size())
            throw new Exception(
            		String.valueOf(
            					ResourceProperties.MSG_ERRO_PARAMTEMPLATE_DECLARACAO_VARIAVEIS_SINTAXE));
        else
        {
            //captura o nome e o tipo das variaveis baseado nas posi��es inicial e final de cada variavel
            for ( int i = 0; i < posicoesIniciais.size(); i++ )
            {
                    String subTexto = p_strTexto.substring(posicoesIniciais.get(i), posicoesFinais.get(i));
                    String[] str = subTexto.split(":");
                    if (str.length>1)
                    	variaveisMap.put(str[0], str[1]);
                    else
                        variaveisMapScreen.put(str[0],"");
            }
            //seta as variaveis em uma collection
            for (String key : variaveisMap.keySet())
            {
				Variavel variavel = new Variavel();
				variavel.setNomeVariavel(formatVariavel(key));
				variavel.setTipoVariavel(variaveisMap.get(key).toUpperCase());
				if( variavel.getTipoVariavel().equals("TEXTO")
				|| variavel.getTipoVariavel().equals("NUMERO")
				|| variavel.getTipoVariavel().equals("DATA"))
				  {
				          variaveis.add(variavel);
				  }
				  else
				      throw new Exception(
				      		String.valueOf(
				      				ResourceProperties.MSG_ERRO_PARAMTEMPLATE_DECLARACAO_VARIAVEIS_TIPO));
            }
            for (String key : variaveisMapScreen.keySet())
            {
                Variavel variavel = new Variavel();
                variavel.setNomeVariavel(key.trim());
                variavel.setTipoVariavel("");
                variaveisScreen.add(variavel);
            }
        }
        for (int i = 0; i < posicoesIniciais.size(); i++)
        {
            textoConvertido = textoConvertido.replaceAll(
                        textoConvertido.substring(posicoesIniciais.get(i),
                            posicoesFinais.get(i)),
                                textoConvertido.substring(posicoesIniciais.get(i),
                                    posicoesFinais.get(i)).toUpperCase());
        }
        return variaveis;
    }
	    
	    
    private String formatVariavel(String p_variavel)
    {
        for ( int i = 0; i < p_variavel.length(); i++  )
        {
            if ( p_variavel.charAt(i) == ' '  )
                    p_variavel = p_variavel.replace(' ', '_');
        }
        String temp = java.text.Normalizer.normalize(p_variavel, java.text.Normalizer.Form.NFD);
        return temp.replaceAll("[^\\p{ASCII}]","").toUpperCase();
    }
    
    public byte[] getBytesFromFile(File file) throws FileNotFoundException,IOException
    {
	   	InputStream is = null;
	    is = new FileInputStream(file);
	    long length = file.length();
	   	if (length < Integer.MAX_VALUE) 
	   	{
    		byte[] bytes = new byte[(int)length];
    		int offset = 0;
    		int numRead = 0;
    		try 
    		{
    			while (offset < bytes.length && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
    				offset += numRead;
    			}
    		} catch (IOException e1) {
    			e1.printStackTrace();
    		}
    		if (offset < bytes.length) 
    				throw new IOException("Could not completely read file "+file.getName());
			is.close();
    		byte[] a = new byte[(int)length];
    		for (int i = 0; i < (int)length; i++) 
    		{
    			a[i] = bytes[i];
    		}
    		return a;
    	}
    	return null;
    }

   
}
