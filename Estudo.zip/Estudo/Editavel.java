package com.nexxera.pds.entity.enums;

/**
 * @requisito d3240_RF008
 *
 * @author Francisco Kindermann
 */

public enum Editavel {

	NAO(false),
	SIM(true);
	
	private Boolean editavel;

	private Editavel(Boolean status){
		this.editavel = status;
	}

	public Boolean isEditavel() {
		return editavel;
	}

	public void setEditavel(Boolean editavel) {
		this.editavel = editavel;
	}
}
