public class LeadTimeHandler {
    
	private static Map<Datetime, Holiday> mapaFeriados {get; set;}
	
    public LeadTimeHandler() {}
    
    public static List<Datetime> getDataEntregaAPartirCarregamento(Map<Datetime, Holiday> mapFeriado,Datetime dataInformada, String codigoCliente, string codigoPlanta, string itinerarioPlanta) {
        
        Integer nDIas =1;
		mapaFeriados = mapFeriado;
        List<Datetime> dates = new List<Datetime>();
        Datetime dataCarregamento = proximoDiaUtil(dataInformada);
        
        // Data de entrega
        Integer nLeadTimeDias = getLeadTimeDias(codigoCliente,codigoPlanta,itinerarioPlanta);
        if (nLeadTimeDias==0) return null;
		Datetime dataEntrega = dataCarregamento;
   
        Integer intCount 	= 0;    
        while(intCount < nLeadTimeDias){
            dataEntrega = dataEntrega.addDays(nDIas);
            dataEntrega = IsFeriadoEFinalSemana(dataEntrega, nDIas );
            intCount++;
        }
        
        // 1 - Data do pedido
		Datetime dataPedido =  Datetime.now();
        dates.add(dataPedido);  
        
        // 2 - Data do carregamento
        dates.add(dataCarregamento);
        
        // 3 - Data de entrega
        dataEntrega = proximoDiaUtil(dataEntrega);
        dates.add(dataEntrega); 
        
        return dates;  
    }
    
   	public static List<Datetime> getDataLeatTimedeEntrega(Map<Datetime, Holiday> mapFeriado, Datetime dataInformada, String codigoCliente, string codigoPlanta, string itinerarioPlanta) {
        
        Integer nDIas = - 1;
        mapaFeriados = mapFeriado;
        List<Datetime> dates = new List<Datetime>();
        Datetime dataEntrega = proximoDiaUtil(dataInformada );
        
        Integer nContadorDias = 0;
        if (dataEntrega.hour() >= 12 && dataInformada==dataEntrega ){
            nContadorDias = 3;
        }else{
            nContadorDias = 2;
        }  
        
        Integer nLeadTimeDias = getLeadTimeDias(codigoCliente,codigoPlanta,itinerarioPlanta); 
        if (nLeadTimeDias==0) return null;
        Datetime dataCarregamento = dataEntrega;

        Integer intCount = 0;  
        while(intCount < nLeadTimeDias){
            dataCarregamento = dataCarregamento.addDays(nDIas);
            dataCarregamento = IsFeriadoEFinalSemana(dataCarregamento, nDIas );
            intCount++;
        }
       
        dataCarregamento = diaUtilAnterior(dataCarregamento);  
        
        // Data do dataPedido
        Datetime dataPedido = dataCarregamento;
        intCount = 0;    
        while(intCount < nContadorDias){
            dataPedido = dataPedido.addDays(nDIas);
            dataPedido = IsFeriadoEFinalSemana(dataPedido, nDIas );
            intCount++;
        }
        
        // 1 - Data do pedido
        dataPedido = diaUtilAnterior(dataPedido);  
        dates.add(dataPedido); 
        
        // 2 - Data do dataCarregamento
        dates.add(dataCarregamento); 
        
        // 3 - Data de entrega
        dates.add(dataEntrega);
        
        return dates;  
    }
        
    public static List<Datetime> getDataLeatTimedeDisponibilidade(Map<Datetime, Holiday> mapFeriado, Datetime dataInformada, String codigoCliente, string codigoPlanta, string itinerarioPlanta) {
        
        Integer nDIas =1;
		mapaFeriados = mapFeriado;
        List<Datetime> dates = new List<Datetime>();
        Datetime dataPedido = proximoDiaUtil(dataInformada);
     	
        Integer nContadorDias = 0;
        if (dataPedido.hour() >= 12 && dataInformada==dataPedido){
            nContadorDias = 3;
        }else{
            nContadorDias = 2;
        }
        
        // Data do carregamento recebe a data do pedido
        Datetime dataCarregamento = dataPedido;
        Integer intCount = 0;    
        while(intCount < nContadorDias){
            dataCarregamento = dataCarregamento.addDays(nDIas);
            dataCarregamento = IsFeriadoEFinalSemana(dataCarregamento, nDIas );
            intCount++;
        }
        
        // Data de entrega
        Integer nLeadTimeDias = getLeadTimeDias(codigoCliente,codigoPlanta,itinerarioPlanta);
        if (nLeadTimeDias==0) return null;
        
		dataCarregamento = proximoDiaUtil(dataCarregamento);        
        Datetime dataEntrega = dataCarregamento;
   
        intCount 	= 0;    
        while(intCount < nLeadTimeDias){
            dataEntrega = dataEntrega.addDays(nDIas);
            dataEntrega = IsFeriadoEFinalSemana(dataEntrega, nDIas );
            intCount++;
        }
        
        // 1 - Data do pedido
        dates.add(dataPedido);  
        
        // 2 - Data do carregamento
        dates.add(dataCarregamento);
        
        // 3 - Data de entrega
        dataEntrega = proximoDiaUtil(dataEntrega);
        dates.add(dataEntrega);    
        
        return dates;  
    }
	
	public static Datetime proximoDiaUtil(Datetime dataInformada) {
		try {
            Datetime dataInformadaRetorno = dataInformada;
            
            Datetime dtDataInicioSemana = dataInformada.date().toStartOfWeek();
            Integer nDataEntregaDesejo = dtDataInicioSemana.date().daysBetween(dataInformada.date());
            
            if (nDataEntregaDesejo ==7) { // ÍNICIO DA SEMANA = SABAD0 =7
				dataInformadaRetorno =  dataInformadaRetorno.addDays(2);
            }
            
            if (nDataEntregaDesejo ==1) { // ÍNICIO DA SEMANA = DOMINGO =1
				dataInformadaRetorno =  dataInformadaRetorno.addDays(1);
            }
                        
            if (IsFeriado(dataInformadaRetorno)) {
                dataInformadaRetorno =  dataInformadaRetorno.addDays(1);
                dataInformadaRetorno = proximoDiaUtil(dataInformadaRetorno);
            }
            return dataInformadaRetorno;
            
        } catch(Exception e) {
            System.debug('LeadTimeHandler::proximoDiaUtil........Erro');
            System.debug(e);
            return null;
        }
    }
    
    private static Integer getLeadTimeDias(string codigoCliente, string codigoPlanta, string itinerarioPlanta) {
        Decimal dLeadTimeDias  = 0;
        try  {
            Lead_Time__c oLeadTime = ConsultarLeadTimePorConta(codigoCliente,codigoPlanta, itinerarioPlanta);
            if (oLeadTime!=null){
                dLeadTimeDias = parseToDecimal(String.valueOf(oLeadTime.Lead_Time_Dias__c));
            }
        } catch(Exception e) {
            System.debug('LeadTimeHandler::getLeadTimeDias........Erro');
            System.debug(e);
        }
        return Integer.valueOf(dLeadTimeDias);
    }
        
    private static Datetime IsFeriadoEFinalSemana(Datetime dataInformada,Integer nValor) {
		try  {        
            Datetime dataInformadaRetorno = dataInformada;
            
            Datetime dtDataInicioSemana = dataInformada.date().toStartOfWeek();
            Integer nDataEntregaDesejo = dtDataInicioSemana.date().daysBetween(dataInformada.date());
            
            if (nDataEntregaDesejo ==1) { // ÍNICIO DA SEMANA = DOMINGO =1
				dataInformadaRetorno =  dataInformadaRetorno.addDays(nValor);
            }
                        
            if (IsFeriado(dataInformadaRetorno)) {
                dataInformadaRetorno =  dataInformadaRetorno.addDays(nValor);
                dataInformadaRetorno = IsFeriadoEFinalSemana(dataInformadaRetorno, nValor);
            }
            return dataInformadaRetorno;
            
        } catch(Exception e) {
            System.debug('LeadTimeHandler::IsFeriadoEFinalSemana........Erro');
            System.debug(e);
            return null;
        }
    }

    private static Datetime diaUtilAnterior(Datetime dataInformada) {
		try {
            Datetime dataInformadaRetorno = dataInformada;
            
            Datetime dtDataInicioSemana = dataInformada.date().toStartOfWeek();
            Integer nDataEntregaDesejo = dtDataInicioSemana.date().daysBetween(dataInformada.date());
            
            if (nDataEntregaDesejo ==7) { // ÍNICIO DA SEMANA = SABAD0 =7
				dataInformadaRetorno =  dataInformadaRetorno.addDays(-1);
            }
            
            if (nDataEntregaDesejo ==1) { // ÍNICIO DA SEMANA = DOMINGO =1
				dataInformadaRetorno =  dataInformadaRetorno.addDays(-2);
            }
                        
            if (IsFeriado(dataInformadaRetorno)) {
                dataInformadaRetorno =  dataInformadaRetorno.addDays(-1);
                dataInformadaRetorno = diaUtilAnterior(dataInformadaRetorno);
            }
            return dataInformadaRetorno;
            
        } catch(Exception e) {
            System.debug('LeadTimeHandler::diaUtilAnterior........Erro');
            System.debug(e);
            return null;
        }
    }
    
    private static Decimal parseToDecimal(String value) {
        return String.isBlank(value.trim()) ? 0.00 : Decimal.valueOf(value.trim());
    }
    
    private static Lead_Time__c ConsultarLeadTimePorConta(String codigoCliente, string codigoPlanta, string itinerarioPlanta) {
        try{
        	return [SELECT Id, Name, Descricao_do_itinerario__c, Codigo_do_itinerario__c, Codigo_do_Cliente__c, 
			Codigo_da_origem__c, Lead_Time_Dias__c FROM Lead_Time__c where Codigo_do_Cliente__c = :codigoCliente 
                    and Codigo_da_origem__c = :codigoPlanta and Codigo_do_itinerario__c=:itinerarioPlanta];
        } catch(QueryException e) {
            System.debug('LeadTimeHandler::ConsultarLeadTimePorConta.......: ' + e.getMessage());
            return null;
        }
    }
    
    private static boolean IsFeriado(Datetime dataInformada) {
		if (mapaFeriados != null || !mapaFeriados.isEmpty()) {
            Holiday objFeriado = mapaFeriados.get(dataInformada.date());
			if (objFeriado != null) {
                System.debug('IsFeriado::holiday=' + objFeriado);
				Datetime dtDataInicioSemana = dataInformada.date().toStartOfWeek();
				Integer nDataEntregaDesejo = dtDataInicioSemana.date().daysBetween(dataInformada.date());
				
				if (nDataEntregaDesejo == 7 || nDataEntregaDesejo == 1) { // ÍNICIO DA SEMANA = DOMINGO=1 e SABADO=7
					return false;         
				}
				return true;
			}
			
		}
        return false;
    }
    
    private static Map<Datetime, Holiday> CarregaMapaFeriado(){
        Map<Datetime, Holiday> mapFeriado = new Map<Datetime, Holiday>();
        Datetime dataInicial 	= Datetime.now();
        Datetime dataFinal 		= dataInicial.addMonths(12);
        List<Holiday> listaFeriados = ConsultarFeriadoPorDataDesejoIntervalo(dataInicial, dataFinal);
        
        for(Holiday holiday : listaFeriados) {
            System.debug('CarregaMapaFeriado::holiday=' + holiday);
            mapFeriado.put(holiday.ActivityDate, holiday);
        }
		return mapFeriado;
    }
	    
    private static List<Holiday> ConsultarFeriadoPorDataDesejoIntervalo(Datetime dataEntregaDesejoInicial, Datetime dataEntregaDesejoFinal) {
        try{
        	return [select id, name, ActivityDate, Description From holiday where ActivityDate >=:dataEntregaDesejoInicial.date() and ActivityDate <=:dataEntregaDesejoFinal.date()];
        } catch(QueryException e) {
            System.debug('LeadTimeHandler::ConsultarFeriadoPorDataDesejo.......: ' + e.getMessage());
            return null;
        }
    }
        
    private static Order ConsultarDataPedidoPorPedido(String orderNumber) {
        try{
        	return [select Id, OrderNumber, Data_do_atendimento__c , Data_desejada_da_entrega__c, CreatedDate, LastModifiedDate from Order where OrderNumber =:orderNumber limit 1];
        } catch(QueryException e) {
            System.debug('LeadTimeHandler::ConsultarDataPedidoPorPedido.......: ' + e.getMessage());
            return null;
        }
    }
}