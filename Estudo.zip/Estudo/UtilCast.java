/*  1:   */ package br.com.virtuoso.prosaude.utils;
/*  2:   */ 
/*  3:   */ import java.util.Date;
/*  4:   */ import java.util.Scanner;
/*  5:   */ 
/*  6:   */ public class UtilCast
/*  7:   */ {
/*  8:   */   public static Date toDate(Object objeto)
/*  9:   */   {
/* 10:13 */     if (UtilString.isNuloOuBranco(objeto)) {
/* 11:14 */       return null;
/* 12:   */     }
/* 13:16 */     if ((objeto instanceof Date)) {
/* 14:17 */       return (Date)objeto;
/* 15:   */     }
/* 16:19 */     Date retorno = UtilData.retornarData(objeto.toString().trim());
/* 17:20 */     return retorno;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public static String toString(Object objeto)
/* 21:   */   {
/* 22:24 */     if (UtilString.isNuloOuBranco(objeto)) {
/* 23:25 */       return null;
/* 24:   */     }
/* 25:27 */     if ((objeto instanceof String)) {
/* 26:28 */       return (String)objeto;
/* 27:   */     }
/* 28:30 */     String retorno = new String(objeto.toString().trim());
/* 29:31 */     return retorno;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static Long toLong(Object objeto)
/* 33:   */   {
/* 34:35 */     if (UtilString.isNuloOuBranco(objeto)) {
/* 35:36 */       return null;
/* 36:   */     }
/* 37:38 */     if ((objeto instanceof Long)) {
/* 38:39 */       return (Long)objeto;
/* 39:   */     }
/* 40:41 */     Long retorno = new Long(objeto.toString().trim());
/* 41:42 */     return retorno;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public static Integer toInteger(Object objeto)
/* 45:   */   {
/* 46:46 */     if (UtilString.isNuloOuBranco(objeto)) {
/* 47:47 */       return null;
/* 48:   */     }
/* 49:49 */     if ((objeto instanceof Integer)) {
/* 50:50 */       return (Integer)objeto;
/* 51:   */     }
/* 52:52 */     if ((objeto instanceof Number)) {
/* 53:53 */       return Integer.valueOf(((Number)objeto).intValue());
/* 54:   */     }
/* 55:55 */     Integer retorno = new Integer(objeto.toString().trim());
/* 56:56 */     return retorno;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public static Double toDouble(Object objeto)
/* 60:   */   {
/* 61:60 */     if (UtilString.isNuloOuBranco(objeto)) {
/* 62:61 */       return null;
/* 63:   */     }
/* 64:63 */     if ((objeto instanceof Double)) {
/* 65:64 */       return (Double)objeto;
/* 66:   */     }
/* 67:66 */     if ((objeto instanceof String))
/* 68:   */     {
/* 69:67 */       Scanner scanner = new Scanner(objeto.toString());
/* 70:68 */       scanner.useLocale(UtilLocale.getLocale());
/* 71:69 */       return Double.valueOf(scanner.nextDouble());
/* 72:   */     }
/* 73:71 */     return Double.valueOf(objeto.toString());
/* 74:   */   }
/* 75:   */   
/* 76:   */   public static Double toDoubleZeroSeNull(Object objeto)
/* 77:   */   {
/* 78:75 */     if (UtilString.isNuloOuBranco(objeto)) {
/* 79:76 */       return Double.valueOf(0.0D);
/* 80:   */     }
/* 81:78 */     return toDouble(objeto);
/* 82:   */   }
/* 83:   */ }


/* Location:           C:\Users\Karine\Documents\Cleonice\apache-tomcat-7x (1)\apache-tomcat-7x\webapps\ROOT\WEB-INF\classes\
 * Qualified Name:     br.com.virtuoso.prosaude.utils.UtilCast
 * JD-Core Version:    0.7.0.1
 */