package com.nexxera.pds.webservice.server;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.HashMap;

import org.bouncycastle.asn1.cmp.PKIFailureInfo;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cms.SignerId;
import org.bouncycastle.tsp.TSPAlgorithms;
import org.bouncycastle.tsp.TimeStampRequest;
import org.bouncycastle.tsp.TimeStampRequestGenerator;
import org.bouncycastle.tsp.TimeStampResponse;
import org.bouncycastle.tsp.TimeStampToken;
import org.bouncycastle.tsp.TimeStampTokenInfo;

import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.pdf.PdfDate;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfPKCS7;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfSignature;
import com.itextpdf.text.pdf.PdfSignatureAppearance;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfString;
import com.nexxera.pds.utility.CRLInfo;
import com.nexxera.pds.utility.CriptoUtils;
import com.nexxera.pds.utility.ResourceProperties;

public class TSAClientContrato implements com.itextpdf.text.pdf.TSAClient 
{
	protected int tokSzEstimate;
//	public static final String ocspUrl 					= "https://flnws002dev.nexxera.com/tsa";
	public static final String ocspUrl					= "http://ca.signfiles.com/TSAServer.aspx";
	
	public static final String storeType 				= "PKCS12";
	public static       InputStream certificadoNexxera 	= null;
//	public static final InputStream certificadoNexxera 	= ICPBrasilServer.class.getResourceAsStream("certificadonexxera2012.pfx");
	public static		String certificadoURLNexxera 	= null;
	public static 		String certificateAlias 		= null;
	public static       String storePass 				= null;
	public static       String keyPass   				= null;
	public static char keepTheSamePdfVersion 			= 0;
	public static boolean appendSignatureAndAllContentsNotInvalidatingExistingSignatures = false;
	public static PrivateKey privateKey 				= null;
	public static Certificate[] certificateChain 		= null;
	public static KeyStore keyStore 					= null;
	
	public static boolean carregado;
	
	public TSAClientContrato() 
	{
		this.tokSzEstimate 								= 4096;
	}
	
	public static void carregaConfiguracaoAssinatura() throws Exception
	{
		if (carregado) {
			return;
		}
		carregado = true;
		
		System.out.println("PDS: Carregando dados da classe TSAClientContrato");
		
		certificateChain 								= null;
		privateKey 										= null;
		certificadoURLNexxera 							= ResourceProperties.getUrslApp("url.cert.pds");
		certificateAlias 								= ResourceProperties.getUrslApp("alias.cert.pds");
		certificadoNexxera 								= CriptoUtils.getCertificate();
		storePass 										= ResourceProperties.getUrslApp("pass.cert.pds");
		keyPass   										= ResourceProperties.getUrslApp("pass.cert.pds");
//		InputStream inputStream 						= CriptoUtils.getCertificate();
		keyStore 										= Util.getKeyStoreFromBytes(certificadoNexxera, storeType, storePass);
		privateKey 										= Util.getPrivateKey(keyStore, certificateAlias, keyPass);
		certificateChain 								= Util.getCertificateChain(keyStore, certificateAlias);
		keepTheSamePdfVersion 							= '\0';
		appendSignatureAndAllContentsNotInvalidatingExistingSignatures = true;
		
		System.out.println("PDS: Dados da classe TSAClientContrato carregados com sucesso");
	}
	
	public static byte[] assinarPdf(byte[] pdfAssinar) throws Exception
	{
		carregaConfiguracaoAssinatura();
					
		PdfReader readerFileIn = new PdfReader(pdfAssinar);
		ByteArrayOutputStream bytesPdfAssinado = new ByteArrayOutputStream();

		final PdfStamper stamper = PdfStamper.createSignature(readerFileIn, bytesPdfAssinado, keepTheSamePdfVersion, null, appendSignatureAndAllContentsNotInvalidatingExistingSignatures);

		final PdfSignatureAppearance signatureAppearance = stamper.getSignatureAppearance();
		signatureAppearance.setCrypto(privateKey, certificateChain, null, PdfSignatureAppearance.WINCER_SIGNED);

		stamper.close();
		bytesPdfAssinado.close();

		return bytesPdfAssinado.toByteArray();
	}
	
	public static PdfSignatureAppearance assinarPdf(byte[] pdfAssinar, ByteArrayOutputStream bytesPdfAssinado) throws Exception
	{
		carregaConfiguracaoAssinatura();
		
		PdfReader readerFileIn = new PdfReader(pdfAssinar);

		PdfStamper stamper = PdfStamper.createSignature(readerFileIn, bytesPdfAssinado, keepTheSamePdfVersion, null, appendSignatureAndAllContentsNotInvalidatingExistingSignatures);
		PdfSignatureAppearance signatureAppearance = stamper.getSignatureAppearance();
		signatureAppearance.setCrypto(privateKey, certificateChain, null, PdfSignatureAppearance.WINCER_SIGNED);
		
		return signatureAppearance;
	}

	public byte[] getTimeStamp(InputStream data) throws Exception 
	{
		carregaConfiguracaoAssinatura();
		
		boolean includeCRL_List 			= false;
		long DEFAULT_VALUE_SIGNATURE_SIZE 	= 15000L;

		final CRLInfo crlInfo 				= new CRLInfo(certificateChain, includeCRL_List);
		final int contentEstimated 			= (int) (DEFAULT_VALUE_SIGNATURE_SIZE + 2L * crlInfo.getByteCount());
		PdfPKCS7 pdfPKCS7 					= new PdfPKCS7(privateKey, certificateChain, crlInfo.getCrls(), "SHA1", null, false);
		
		final MessageDigest messageDigest 	= MessageDigest.getInstance("SHA1");
		byte buf[] 							= new byte[8192];
		int n;
		while ((n = data.read(buf)) > 0) 
		{
			messageDigest.update(buf, 0, n);
		}
		byte hash[] 						= messageDigest.digest();
		Calendar cal 						= Calendar.getInstance();
		byte sh[] 							= pdfPKCS7.getAuthenticatedAttributeBytes(hash, cal, null);
		pdfPKCS7.update(sh, 0, sh.length);
		
		byte[] encodedSig 					= null;
		encodedSig 							= pdfPKCS7.getEncodedPKCS7(hash, cal, this, null);
		if (contentEstimated + 2 < encodedSig.length) 
			throw new Exception("Not enough space");
		
		byte[] paddedSig 					= new byte[contentEstimated];
		System.arraycopy(encodedSig, 0, paddedSig, 0, encodedSig.length);
		
		return paddedSig;
	}
	
	public PdfDictionary getTimeStamp(PdfSignatureAppearance signatureAppearance) throws Exception 
	{
		carregaConfiguracaoAssinatura();
		
		final PdfSignature signature = new PdfSignature(PdfName.ADOBE_PPKLITE, new PdfName("adbe.pkcs7.detached"));
		signature.setReason(signatureAppearance.getReason());
		signature.setLocation(signatureAppearance.getLocation());
		signature.setContact(signatureAppearance.getContact());
		signature.setDate(new PdfDate(signatureAppearance.getSignDate()));
		signatureAppearance.setCryptoDictionary(signature);
		
		boolean includeCRL_List 			= false;
		long DEFAULT_VALUE_SIGNATURE_SIZE 	= 15000L;

		final CRLInfo crlInfo 				= new CRLInfo(certificateChain, includeCRL_List);
		final int contentEstimated 			= (int) (DEFAULT_VALUE_SIGNATURE_SIZE + 2L * crlInfo.getByteCount());
		HashMap<PdfName, Integer> exc 		= new HashMap<PdfName, Integer>();
		exc.put(PdfName.CONTENTS, new Integer(contentEstimated * 2 + 2));
		signatureAppearance.preClose(exc);
		
		PdfPKCS7 pdfPKCS7 					= new PdfPKCS7(privateKey, certificateChain, crlInfo.getCrls(), "SHA1", null, false);
		
		InputStream data 					= signatureAppearance.getRangeStream();
		final MessageDigest messageDigest 	= MessageDigest.getInstance("SHA1");
		byte buf[] 							= new byte[8192];
		int n;
		while ((n = data.read(buf)) > 0) 
		{
			messageDigest.update(buf, 0, n);
		}
		byte hash[] 						= messageDigest.digest();
		Calendar cal 						= Calendar.getInstance();
		byte sh[] 							= pdfPKCS7.getAuthenticatedAttributeBytes(hash, cal, null);
		pdfPKCS7.update(sh, 0, sh.length);
		
		byte[] encodedSig 					= null;
		encodedSig 							= pdfPKCS7.getEncodedPKCS7(hash, cal, this, null);
		if (contentEstimated + 2 < encodedSig.length) 
			throw new Exception("Not enough space");
				
		
		byte[] paddedSig 					= new byte[contentEstimated];
		System.arraycopy(encodedSig, 0, paddedSig, 0, encodedSig.length);
		
		PdfDictionary dictinary 			= new PdfDictionary();
		dictinary.put(PdfName.CONTENTS, new PdfString(paddedSig).setHexWriting(true));
		
		return dictinary;
	}
		
	@Override
	public byte[] getTimeStampToken(PdfPKCS7 pdfPKCS7, byte[] assinatura) throws Exception 
	{
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		return getTimeStamp(assinatura);
	}

	@SuppressWarnings("unused")
	protected byte[] getTimeStamp(byte[] assinatura) throws Exception 
	{
		OutputStream out 					= null;
		byte[] encoded 						= null; 
		
		TimeStampRequestGenerator reqgen	= new TimeStampRequestGenerator();
		reqgen.setCertReq(true);

		SecureRandom randomGenerator 		= SecureRandom.getInstance("SHA1PRNG");
		long nonce = randomGenerator.nextLong();

		TimeStampRequest timeRequest		= reqgen.generate(TSPAlgorithms.SHA1,	assinatura, BigInteger.valueOf(nonce));
		byte request[] 						= timeRequest.getEncoded();

		URL url 							= new URL(ocspUrl);
		HttpURLConnection con 				= (HttpURLConnection) url.openConnection();

		con.setDoOutput(true);
		con.setDoInput(true);
		con.setRequestMethod("POST");
		con.setRequestProperty("Content-type", "application/timestamp-query");
		con.setRequestProperty("Content-length", String.valueOf(request.length));
		out = con.getOutputStream();
		out.write(request);
		out.flush();

		if (con.getResponseCode() != HttpURLConnection.HTTP_OK) 
			throw new IOException("Received HTTP error: "+ con.getResponseCode() + " - "+ con.getResponseMessage());

		InputStream in 						= con.getInputStream();
		TimeStampResponse response 			= new TimeStampResponse(in);
		response.validate(timeRequest);
		PKIFailureInfo failure 				= response.getFailInfo();
		int value = (failure == null) ? 0 : failure.intValue();
		if (value != 0) 
			throw new Exception(MessageLocalization.getComposedMessage(	"invalid.tsa.1.response.code.2", ocspUrl,String.valueOf(value)));

		TimeStampToken token 				= response.getTimeStampToken();
		SignerId signer_id 					= token.getSID();
		BigInteger cert_serial_number 		= signer_id.getSerialNumber();

		X509Certificate certificate 		= null;
		JcaX509CertificateConverter convert = new JcaX509CertificateConverter().setProvider("BC");
		for (Object x509CertificateLocal : token.getCertificates().getMatches(null)) 
		{
			X509Certificate cert = convert.getCertificate((X509CertificateHolder) x509CertificateLocal);
			if (cert_serial_number != null) 
				if (cert.getSerialNumber().equals(cert_serial_number)) 
					certificate = cert;
			else 
				if (certificate == null) 
					certificate = cert;
		}
		TimeStampToken tsToken 				= response.getTimeStampToken();
		if (tsToken == null) 
			throw new Exception(MessageLocalization.getComposedMessage("tsa.1.failed.to.return.time.stamp.token.2",	ocspUrl,response.getStatusString()));
		TimeStampTokenInfo info 			= tsToken.getTimeStampInfo(); 
		encoded 							= tsToken.getEncoded();
		tokSzEstimate 						= encoded.length + 32;
		return encoded;
	}

	@Override
	public int getTokenSizeEstimate() {
		return tokSzEstimate;
	}
}
