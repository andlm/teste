trigger PBS_Proposta on WBC_ETRM__Proposta__c (before insert) {
    if(Trigger.isBefore){
        PBS_PropostaUtil.autoNumeracao(Trigger.new);
    }
}