package com.nexxera.pds.webservice.movel.entity;

import java.text.SimpleDateFormat;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.nexxera.pds.entity.enums.TipoLigacaoCampo;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "variavel")
public class Variavel extends Parseable<com.nexxera.pds.entity.Variavel>   
{
	private static final long serialVersionUID = 5293468636007268800L;
	
	@XmlElement(name = "nomeVariavel")
	private String nomeVariavel;
	
	@XmlElement(name = "nomeCampoOriginal")
	private String nomeCampoOriginal;
	
	@XmlElement(name = "tipoLigacaoCampo")
	private TipoLigacaoCampo tipoLigacaoCampo;
	
	@XmlElement(name = "tipoVariavel")
	private String tipoVariavel;
	
	@XmlElement(name = "valorVariavel")
	private String valorVariavel;
	
	public Variavel() {}

	public Variavel(com.nexxera.pds.entity.Variavel variavel) {
		this();
		nomeVariavel = variavel.getNomeVariavel();
		nomeCampoOriginal = variavel.getNomeCampoOriginal();
		tipoLigacaoCampo = variavel.getTipoLigacaoCampo();
		tipoVariavel = variavel.getTipoVariavel();
	}



	@Override
	public com.nexxera.pds.entity.Variavel parse() {

		com.nexxera.pds.entity.Variavel variavel = new com.nexxera.pds.entity.Variavel();
		variavel.setNomeVariavel(nomeVariavel);
		variavel.setNomeCampoOriginal(nomeCampoOriginal);
		variavel.setTipoLigacaoCampo(tipoLigacaoCampo);
		variavel.setTipoVariavel(tipoVariavel);
		if(variavel.getTipoVariavel().equalsIgnoreCase("DATA"))
			valorVariavel = new SimpleDateFormat("dd/MM/yyyy").format(variavel.getValorVariavel());
		else
			valorVariavel = variavel.getValorVariavel().toString();
		return null;
	}
	
	public String getNomeVariavel() {
		return nomeVariavel;
	}

	public void setNomeVariavel(String nomeVariavel) {
		this.nomeVariavel = nomeVariavel;
	}
	
	public TipoLigacaoCampo getTipoLigacaoCampo() {
		return tipoLigacaoCampo;
	}

	public void setTipoLigacaoCampo(TipoLigacaoCampo tipoLigacaoCampo) {
		this.tipoLigacaoCampo = tipoLigacaoCampo;
	}

	public String getTipoVariavel() {
		return tipoVariavel;
	}

	public void setTipoVariavel(String tipoVariavel) {
		this.tipoVariavel = tipoVariavel;
	}

	public String getValorVariavel() {
		return valorVariavel;
	}

	public void setValorVariavel(String valorVariavel) {
		this.valorVariavel = valorVariavel;
	}

	public String getNomeCampoOriginal() {
		return nomeCampoOriginal;
	}

	public void setNomeCampoOriginal(String nomeCampoOriginal) {
		this.nomeCampoOriginal = nomeCampoOriginal;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Variavel other = (Variavel) obj;
		if (nomeVariavel == null) {
			if (other.nomeVariavel != null)
				return false;
		} else if (!nomeVariavel.equals(other.nomeVariavel))
			return false;
		if (tipoVariavel == null) {
			if (other.tipoVariavel != null)
				return false;
		} else if (!tipoVariavel.equals(other.tipoVariavel))
			return false;
		if (valorVariavel == null) {
			if (other.valorVariavel != null)
				return false;
		} else if (!valorVariavel.equals(other.valorVariavel))
			return false;
		return true;
	}

}
