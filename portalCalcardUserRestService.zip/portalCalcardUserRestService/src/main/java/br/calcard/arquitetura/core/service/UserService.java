package br.calcard.arquitetura.core.service;

import java.util.List;

import br.calcard.arquitetura.core.model.User;

public interface UserService {

    User create(User user);

    User delete(Long id);

    List<User> findAll();

    User findById(Long id);

    User update(User user);
}
